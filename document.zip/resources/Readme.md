# ext-theme-neptune-d7cce7f6-81b5-4ef1-8f30-b6e6e6e349a0/resources

This folder contains static resources (typically an `"images"` folder as well).
