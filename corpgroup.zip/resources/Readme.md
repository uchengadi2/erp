# ext-theme-neptune-15f9aeb7-14a2-46ee-95ef-8af71fae035d/resources

This folder contains static resources (typically an `"images"` folder as well).
