# ext-theme-neptune-555661a0-bf1b-49c4-acf6-ff7e8b2448df/resources

This folder contains static resources (typically an `"images"` folder as well).
