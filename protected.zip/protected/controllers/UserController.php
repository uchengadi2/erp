<?php

class UserController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','Login'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','Logout','confirmtheauthenticityofthisuser'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	public function actionLogin()
	{
		
             $model = new User('login');
            
                                             
               
                              
                $model->username = $_POST['username'];
                $model->password = $_POST['password'];
                
                //determine the users id
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='username=:name';
                $criteria->params = array(':name'=>$_POST['username']);
                $user = User::model()->find($criteria);   
                
               $name = $user['name'];
              //validate the users logon credentials
              
         if($this->validatePassword($model, $user->id,$model->password) && $model->login()) {
           // if($model->login()) {
                      header('Content-Type: application/json');
                      $msg = "$name";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg,
                          // "firstname"=>$id['name'],
                           "user"=>$user
                            )
                           
                       );
          // }  

        }else {
                     header('Content-Type: application/json');
                      $msg= 'Incorrect username or password.';
                     echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                         "firstname"=>$id['name']
                             )
                       );
                       
                }
                
            
                
		
		
	}
        
        
         /**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
		Yii::app()->user->logout();
		//$this->redirect(Yii::app()->homeUrl);
                header('Content-Type: application/json');
                      $msg= "You just logged out. Please come again";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg,
                           
                            )
                           
                       );
	}
        
        
                /*
         * validate the password during authorisation
         */
        public function validatePassword($model, $id, $password){
         
            //determine the existing password
            
           $criteria = new CDbCriteria();
           $criteria->select = 'id, password';
           $criteria->condition='id=:id';
           $criteria->params = array(':id'=>$id);
           $existing_password = User::model()->find($criteria);   
        
           return $model->hashPassword($password)=== $existing_password->password;
           
            
        }
        
        
        /**
         * This is the function that confirms if a user's logged in authenticity
         */
        public function actionconfirmtheauthenticityofthisuser(){
            
            $userid = $_REQUEST['userid'];
            
            $logged_in_user = Yii::app()->user->id;
            
            if((int)$userid == (int)$logged_in_user){
                $is_authentic = true;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$userid);
                $user = User::model()->find($criteria);   
                
            }else{
               $is_authentic = false;
               $user=null;
            }
            
             header('Content-Type: application/json');
                      $msg= "You just logged out. Please come again";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "is_authentic" => $is_authentic,
                            "user"=>$user
                            
                            )
                           
                       );
            
        }
        
        
}
