<?php

class OrganizationController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','listAllOrganizationsInAGroupGivenGroupCode'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllOrganizationsInAGroup','addaneworganization','modifyorganization','deleteoneorganization',
                                    'listAllOrganizationsInAGroupGivenGroupCode'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
         * This is the function that list all organizations in a group
         */
        public function actionlistAllOrganizationsInAGroup(){
            
            $group_id = $_REQUEST['group_id'];
            
            $data = [];
            $q = "select a.*, b.name as group_name from organization a
                    JOIN corp_group b ON a.group_id=b.id
                     where a.group_id =$group_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "organization"=>$data,
                                  
                            ));
        }
        
        
        /**
         * This is the function that adds a new organization
         */
        public function actionaddaneworganization(){
            
            $model = new Organization;
            
             $model->group_id = $_POST['group_id'];
             $group_name = $_POST['group_name'];
            
               $model->name = $_POST['name']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                    //add both the crm and the accountng module to this organization
                    //get the accounting module id
                    $account_module_id = $this->getAccountingModuleId();
                    $crm_module_id = $this->getCrmModuleId();
                    
                    //assign this modules to this new organization
                    $this->assignAccountModuleToThisOrganization($model->id,$account_module_id);
                    $this->assignCrmModuleToThisOrganization($model->id,$crm_module_id);
                         // $result['success'] = 'true';
                          $msg = "Successfully added  '$model->name' organization to the '$group_name' group";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this organization to the '$group_name' was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
            
        }
        
        
         /**
         * This is the function that gets the module id of a crm
         * 
         */
        public function getCrmModuleId(){
            $model  = new Modules;
            return $model->getCrmModuleId();
        }
        
        
        /**
         * This is the function that gets the accouting module id
         * 
         */
        public function getAccountingModuleId(){
            $model  = new Modules;
            return $model->getAccountingModuleId();
        }
        
        
        
         /**
         * This is the function that assigns accounting module to an organization
         */
        public function assignAccountModuleToThisOrganization($organization_id,$module_id){
            $model = new OrganizationHasModule;
            return $model->assignAccountModuleToThisOrganization($organization_id,$module_id);
        }
        
        
         /**
         * This is the function that assigns crm module to an organization
         */
        public function assignCrmModuleToThisOrganization($organization_id,$module_id){
            $model = new OrganizationHasModule;
            return $model->assignCrmModuleToThisOrganization($organization_id,$module_id);
        }
        
        
         /**
         * This is the function that modifies an organization
         */
        public function actionmodifyorganization(){
            
            $_id = $_POST['id'];
            
            $model= Organization::model()->findByPk($_id);
            $model->name = $_POST['name'];
            $model->group_id = $_POST['group_id'];
              if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated this organization';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The update of this organization was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
            
        }
        
        
        
         /**
         * This is the function that deletes an organization
         */
        public function actiondeleteoneorganization(){
            
            $_id = $_POST['id'];
            $model= Organization::model()->findByPk($_id);
            
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' organization is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
            
        }
        
        
        /**
         * This is the function that list all organizations in a group given a group code
         */
        public function actionlistAllOrganizationsInAGroupGivenGroupCode(){
            
            $model = new CorpGroup;
            $code = $_REQUEST['group_code'];
            
            //get the group id
            $group_id = $model->getTheCorporateGroupIdOfThisCode($code);
            
            if($group_id !=null){
                           
            $data = [];
            $q = "select a.*, b.name as group_name from organization a
                    JOIN corp_group b ON a.group_id=b.id
                     where a.group_id =$group_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "organization"=>$data,
                                  
                            ));
                
            }else{
                $data = "";
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "organization"=>$data,
                                  
                            ));
                
            }
            
            
        }
}
