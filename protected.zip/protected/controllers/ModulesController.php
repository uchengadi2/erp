<?php

class ModulesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addnewmodule','listallmodules','modifymodule','deletethismodule','listthisgroupallmodules',
                                    'addmoduletogroup','removemodulefromgroup','changemodulestatusingroup'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	 /**
         * This is the function that list all modules 
         */
        public function actionlistallmodules(){
            $modules = Modules::model()->findAll();
                if($modules===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "module" => $modules)
                           );
                       
                }
        }
        
        
        /**
         * This is the function that adds new city to a state
         */
        public function actionaddnewmodule(){
            
            $model = new Modules;
            $model->name = $_POST['name'];
                $model->code = $_POST['code'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully added a new module';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The addition of this new module was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
         /**
         * This is the function that adds new city to a state
         */
        public function actionmodifymodule(){
            
             $_id = $_POST['id'];
            
            $model=  Modules::model()->findByPk($_id);
            $model->name = $_POST['name'];
                $model->code = $_POST['code'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated this module';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The update of this module was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
        /**
	 * Deletes a particular model instance
	 * 
         **/
	public function actiondeletethismodule()
	{
            
            $_id = $_POST['id'];
            $model=  Modules::model()->findByPk($_id);
            
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' module is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
        
        
        /**
         * This is the function that list all modules in a group
         */
        public function actionlistthisgroupallmodules(){
            
          
            $group_id = $_REQUEST['group_id'];
            
            $data = [];
            $q = "select a.*, b.* from modules a
                    JOIN group_has_module b ON a.id=b.module_id
                     where b.group_id =$group_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "module"=>$data,
                                  
                            ));
            
        }
        
        
        /**
         * This is the function that adds a module to a group
         */
        public function actionaddmoduletogroup(){
            
            $model = new GroupHasModule;
            
            $model->module_id = $_POST['module_id'];
                $model->group_id = $_POST['group_id'];
             if($model->isThisModuleAlreadyInTheGroup($model->group_id,$model->module_id) == false){
               $model->status = $_POST['status']; 
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully added  this module to the group';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to add this module to the group was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            }else{
                    $msg = 'This module is already assigned to this group';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );    
                        
                        
                    }
            
        }
        
        
        /**
         * This is the function that changes the status of a module in a group
         */
        public function actionchangemodulestatusingroup(){
            
            $group_id = $_POST['group_id'];
            $module_id = $_POST['module_id'];
            
                      
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='group_id=:groupid and module_id=:moduleid';
                $criteria->params = array(':groupid'=>$group_id,':moduleid'=>$module_id);
                $model= GroupHasModule::model()->find($criteria);
                
              
                  $model->module_id = $_POST['module_id'];
                $model->group_id = $_POST['group_id'];
               $model->status = $_POST['status']; 
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully changed the status of this module in the group';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to change module status in the group was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                  
             
            
            
        }
        
        
        /**
         * This is the function that removes a module from a group
         */
        public function actionremovemodulefromgroup(){
            
            $group_id = $_REQUEST['group_id'];
            $module_id = $_REQUEST['module_id'];
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='group_id=:groupid and module_id=:moduleid';
                $criteria->params = array(':groupid'=>$group_id,':moduleid'=>$module_id);
                $model= GroupHasModule::model()->find($criteria);
            
            $name = $this->getThisModuleName($module_id);
            $group = $this->getTheNameOfTheGroup($group_id);
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$name' module is successfully removed from the '$group' group";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        /**
         * This is the function that gets the name of a module
         */
        public function getThisModuleName($module_id){
            $model = new Modules;
            return $model->getThisModuleName($module_id);
        }
        
        
        /**
         * This is the function that gets the name of a group
         */
        public function getTheNameOfTheGroup($group_id){
            $model = new CorpGroup;
            return $model->getTheNameOfTheGroup($group_id);
        }
}
