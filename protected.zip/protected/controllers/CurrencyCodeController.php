<?php

class CurrencyCodeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listGroupAllCurrencyCode','deletethisCurrencyCode','addnewCurrencyCode','modifyCurrencyCode'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all corporate group currency code
         */
        public function actionlistGroupAllCurrencyCode(){
            
            $group_id = $_REQUEST['group_id'];
            
            $data = [];
            $q = "select a.id as currency_id, a.name as currency_name, b.*, c.name as group_name from currency a
                    JOIN currency_code b ON a.id=b.currency_id
                    JOIN corp_group c ON b.group_id=c.id
                     where c.id =$group_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "currency"=>$data,
                                  
                            ));
            
        }
        
        
        
        /**
         * This is the function that adds a new currency code
         */
        public function actionaddnewCurrencyCode(){
            
            $model = new CurrencyCode;
            
            $group_name = $_POST['group_name'];
            $currency_name = $_POST['currency_name'];
            $model->code = $_POST['code'];
            $model->currency_id = $_POST['currency_id']; 
             $model->group_id = $_POST['group_id']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
             if($model->isCurrencyCodeExist($model->code,$model->group_id,$model->currency_id)== false){
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  the '$model->code' currency code  to the '$group_name' group";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this '$model->code'  currency code to the '$group_name' group was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                }else{
                    $msg = "This currency code is already created for this currency and group and cannot be duplicated";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    
                    
                }  
              
            
        }
        
        
        /**
         * This is the function that modifies a new currency code
         */
        public function actionmodifyCurrencyCode(){
            
            $_id = $_POST['id'];
            
            $model= CurrencyCode::model()->findByPk($_id);
            $group_name = $_POST['group_name'];
            $currency_name = $_POST['currency_name'];
            $model->code = $_POST['code'];
            $model->currency_id = $_POST['currency_id']; 
             $model->group_id = $_POST['group_id']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully updated the '$model->code' currency code  for  '$group_name' group";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update this '$model->code'  currency code for '$group_name' group was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                    
             
            
        }
        
        
        /**
         * This is the function that deletes a Currency Code
         */
        public function actiondeletethisCurrencyCode(){
            
             $_id = $_POST['id'];
            
            $model= CurrencyCode::model()->findByPk($_id);
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->code' Currency Code is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
            
        }
}
