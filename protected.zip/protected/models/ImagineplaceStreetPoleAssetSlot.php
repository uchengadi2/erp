<?php

/**
 * This is the model class for table "imagineplace_street_pole_asset_slot".
 *
 * The followings are the available columns in table 'imagineplace_street_pole_asset_slot':
 * @property string $id
 * @property string $street_pole_batch_id
 * @property integer $street_pole_slot_unique_number
 * @property integer $number_of_poles
 * @property string $name
 * @property string $short_description
 * @property string $description
 * @property integer $average_pole_to_next_pole_distance
 * @property integer $is_pole_of_same_type
 * @property integer $is_pole_of_equal_height
 *
 * The followings are the available model relations:
 * @property ImagineplaceBatchedStreetPoleAsset $streetPoleBatch
 */
class ImagineplaceStreetPoleAssetSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'imagineplace_street_pole_asset_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('street_pole_batch_id, street_pole_slot_unique_number', 'required'),
			array('number_of_poles, average_pole_to_next_pole_distance, is_pole_of_same_type, is_pole_of_equal_height', 'numerical', 'integerOnly'=>true),
			array('street_pole_batch_id', 'length', 'max'=>10),
			array('name, short_description,street_pole_slot_unique_number', 'length', 'max'=>250),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, street_pole_batch_id, street_pole_slot_unique_number, number_of_poles, name, short_description, description, average_pole_to_next_pole_distance, is_pole_of_same_type, is_pole_of_equal_height', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'streetPoleBatch' => array(self::BELONGS_TO, 'ImagineplaceBatchedStreetPoleAsset', 'street_pole_batch_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'street_pole_batch_id' => 'Street Pole Batch',
			'street_pole_slot_unique_number' => 'Street Pole Slot Unique Number',
			'number_of_poles' => 'Number Of Poles',
			'name' => 'Name',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'average_pole_to_next_pole_distance' => 'Average Pole To Next Pole Distance',
			'is_pole_of_same_type' => 'Is Pole Of Same Type',
			'is_pole_of_equal_height' => 'Is Pole Of Equal Height',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('street_pole_batch_id',$this->street_pole_batch_id,true);
		$criteria->compare('street_pole_slot_unique_number',$this->street_pole_slot_unique_number);
		$criteria->compare('number_of_poles',$this->number_of_poles);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('average_pole_to_next_pole_distance',$this->average_pole_to_next_pole_distance);
		$criteria->compare('is_pole_of_same_type',$this->is_pole_of_same_type);
		$criteria->compare('is_pole_of_equal_height',$this->is_pole_of_equal_height);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ImagineplaceStreetPoleAssetSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
         /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($street_pole_batch_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('imagineplace_street_pole_asset_slot')
                    ->where("street_pole_batch_id=$street_pole_batch_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_street_pole_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_street_pole_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_street_pole_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= ImagineplaceStreetPoleAssetSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
