<?php

/**
 * This is the model class for table "production_assets".
 *
 * The followings are the available columns in table 'production_assets':
 * @property string $id
 * @property string $name
 * @property string $asset_subtype_id
 * @property string $organization_id
 * @property string $description
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property AssetSubtype $assetSubtype
 * @property Organization $organization
 */
class ProductionAssets extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'production_assets';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, asset_subtype_id, organization_id', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('name', 'length', 'max'=>250),
			array('asset_subtype_id, organization_id', 'length', 'max'=>10),
			array('description, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, asset_subtype_id, organization_id, description, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'assetSubtype' => array(self::BELONGS_TO, 'AssetSubtype', 'asset_subtype_id'),
			'organization' => array(self::BELONGS_TO, 'Organization', 'organization_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'asset_subtype_id' => 'Asset Subtype',
			'organization_id' => 'Organization',
			'description' => 'Description',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('asset_subtype_id',$this->asset_subtype_id,true);
		$criteria->compare('organization_id',$this->organization_id,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ProductionAssets the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that updates the production assets slot
         */
        public function updateItemsInThisSlot($series_id,$slot_id,$asset_subtype_code,$slot_updated_item){
             if($asset_subtype_code == 'billboard'){
                 $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('imagineplace_billboard_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and billboard_batch_id=$series_id"));
                
                return $result;
             }else if($asset_subtype_code == 'streetpoles'){
                  $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('imagineplace_street_pole_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and street_pole_batch_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'advertproperty'){
                 
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('imagineplace_advert_property_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and batch_property_asset_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'walldrips'){
                 $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('imagineplace_walldrop_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and batch_walldrop_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'streetdirectionalsign'){
                  $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('imagineplace_sds_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and batch_sds_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'charcoal'){
                 
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('agrant_charcoal_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and charcoal_batch_id=$series_id"));
                
                return $result;
             }else if($asset_subtype_code == 'inventory_livestock'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('agrant_inventory_livestock_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and inventory_livestock_batch_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'livestock'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('agrant_livestock_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and livestock_batch_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'commodity'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('agrant_commodity_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and commodity_batch_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'plantation'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('agrant_property_plantation_asset_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and plantation_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'building'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('fm_building_asset_series_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and asset_series_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'entertainment_park'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('fm_entertainment_park_asset_series_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and asset_series_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'car_park'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('fm_car_park_asset_series_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and asset_series_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'airport'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('fm_airport_asset_series_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and asset_series_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'machinery'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('fm_machinery_asset_series_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and asset_series_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'shopping_mall'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('fm_shoppingmail_asset_series_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and asset_series_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'transport_station'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('fm_transport_station_asset_series_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and asset_series_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'complex'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('fm_complex_asset_series_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and asset_series_id=$series_id"));
                
                return $result;
                 
             }else if($asset_subtype_code == 'construction'){
                   $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('fm_construction_asset_series_slot',
                                  array(
                                    'quantity_of_assets_in_place_or_warehouse'=>$slot_updated_item
                                   
                               
		
                            ),
                     ("id=$slot_id and asset_series_id=$series_id"));
                
                return $result;
                 
             }
             
            
        }
        
        
        
          /**
         * This is the function that updates the production assets slot
         */
        public function modifyItemsInThisSlot($series_id,$slot_id,$asset_subtype_code,$slot_updated_item){
            $model = new ProductionAssets;
            return true;
        }
        
        
}
