<?php

/**
 * This is the model class for table "user".
 *
 * The followings are the available columns in table 'user':
 * @property string $id
 * @property string $username
 * @property string $email
 * @property string $password
 * @property string $picture
 * @property string $status
 * @property string $name
 * @property string $role
 * @property string $group_id
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Authitem[] $authitems
 * @property Organization[] $organizations
 * @property CorpGroup $group
 * @property Authitem $role0
 */
class User extends CActiveRecord
{
        private $_identity;
        public $password_repeat;
        public $current_pass;
 
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('username, email, password, status, name, role', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('username, email', 'length', 'max'=>100),
			array('password, picture', 'length', 'max'=>60),
			array('status', 'length', 'max'=>8),
			array('name', 'length', 'max'=>250),
			array('role', 'length', 'max'=>64),
			array('group_id', 'length', 'max'=>10),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, username, email, password, picture, status, name, role, group_id, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'authitems' => array(self::MANY_MANY, 'Authitem', 'authassignment(userid, itemname)'),
			'organizations' => array(self::MANY_MANY, 'Organization', 'organization_has_user(user_id, organization_id)'),
			'group' => array(self::BELONGS_TO, 'CorpGroup', 'group_id'),
			'role0' => array(self::BELONGS_TO, 'Authitem', 'role'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'username' => 'Username',
			'email' => 'Email',
			'password' => 'Password',
			'picture' => 'Picture',
			'status' => 'Status',
			'name' => 'Name',
			'role' => 'Role',
			'group_id' => 'Group',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('username',$this->username,true);
		$criteria->compare('email',$this->email,true);
		$criteria->compare('password',$this->password,true);
		$criteria->compare('picture',$this->picture,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('role',$this->role,true);
		$criteria->compare('group_id',$this->group_id,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return User the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        //public function authenticate($attribute,$params)
       public function authenticate($attribute,$params)
	{
		if(!$this->hasErrors())
		{
			$this->_identity=new UserIdentity($this->username,$this->password);
			if(!$this->_identity->authenticate())
				$this->addError('password','Incorrect username or password.');
		}
	}
        
        
        /**
	 * Logs in the user using the given username and password in the model.
	 * @return boolean whether login is successful
	 */
	public function login()
	{
		if($this->_identity===null)
		{
			
                        $this->_identity=new UserIdentity($this->username,$this->password);
			$this->_identity->authenticate();
		}
		if($this->_identity->errorCode===UserIdentity::ERROR_NONE)
		{
			//$duration=$this->rememberMe ? 3600*24*30 : 0; // 30 days
			Yii::app()->user->login($this->_identity);
			return true;
		}
		else
			return false;
	}
        
        /*
         * Hash the password for security reasons
         */
        public function hashPassword($password){
            
            //return md5($password);
           /**
            if (CRYPT_STD_DES == 1) {
                return crypt($password, Yii::app()->params['encryptionKey_1']);
            }
            if (CRYPT_EXT_DES == 1) {
                 return crypt($password, Yii::app()->params['encryptionKey_2']);
            }
            if (CRYPT_MD5 == 1) {
                return crypt($password, Yii::app()->params['encryptionKey_3']);
            }
            if (CRYPT_BLOWFISH == 1) {
                return crypt($password, Yii::app()->params['encryptionKey_4']);
            }
            if (CRYPT_SHA256 == 1) {
                 return crypt($password, Yii::app()->params['encryptionKey_5']);
            }
            if (CRYPT_SHA512 == 1) {
                 return crypt($password, Yii::app()->params['encryptionKey_6']);
            }
            * 
            */
          $options = [
                
                'cost' => 11,
                'salt' => Yii::app()->params['encryptionKey_6']
            ];
            return password_hash($password,PASSWORD_BCRYPT, $options );
         
         
            
            
        }
        
        
        /**
         * Obtain the password validation for maximum length rules
         */
        
        public function getPasswordMaxLengthRule($password){
            
            foreach ($this->getValidators('password') as $validator) {
            if ($validator instanceof CStringValidator && $validator->max !== null) {
                 //echo 'this is the max length ' . $validator->max;
             
                if(is_string($password)){
                   
                        return(strlen($password)<=$validator->max);
                        
                    
                }
                
            }
            }
            
    }
    
    
      /**
         * Obtain the password validation for minimum length rules
         */
        
        public function getPasswordMinLengthRule($password){
            
            foreach ($this->getValidators('password') as $validator) {
            if ($validator instanceof CStringValidator && $validator->min !== null) {
                 //echo 'this is the max length ' . $validator->max;
             
                if(is_string($password)){
                   
                        return(strlen($password)>= $validator->min);
                        
                    
                }
                
            }
            }
            
    }
    
    
    /**
         * overwrite the beforeSave() function
         */
      
        public function beforeSave(){
            
            
                if(parent::beforeSave()){
                  if($this->password !== ''){
                      $pass = $this->hashPassword($this->password);
                      //$pass = md5($this->password);
                     $this->password = $pass;
                    return true;
                      
                  }elseif($this->password === ''){
                      
                      $this->password = $this->current_pass;
                      
                      return true;
                  }
                
                
            } else{
                
                return false;
            }
                
           
            
              
          
            
            
            
    }
       
       
    
    
    /**
         * Obtain the password validation for pattern rules
         */
        
        public function getPasswordCharacterPatternRule($password){
            
            foreach ($this->getValidators('password') as $validator) {
            if ($validator instanceof CRegularExpressionValidator && $validator->pattern !== null) {
                 //echo 'this is the max length ' . $validator->max;
             
                return(preg_match($validator->pattern,$password));
                   
                       
            }
            }
        } 
}
