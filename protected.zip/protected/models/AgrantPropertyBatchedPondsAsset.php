<?php

/**
 * This is the model class for table "agrant_property_batched_ponds_asset".
 *
 * The followings are the available columns in table 'agrant_property_batched_ponds_asset':
 * @property string $id
 * @property string $production_asset_id
 * @property string $sol_id
 * @property integer $pond_batch_unique_number
 * @property integer $number_of_ponds_in_batch
 * @property string $short_description
 * @property string $description
 * @property string $accounting_preference
 * @property string $method_of_acquisition
 * @property string $other_acquisition_method
 * @property string $acquired_from
 * @property integer $property_pond_gl_id
 * @property integer $number_to_split_batch
 * @property string $parameter_to_base_batch_split
 * @property string $other_batch_split_parameter
 * @property double $total_acquisition_cost
 * @property double $average_cost_per_pond
 * @property double $total_construction_cost
 * @property integer $primary_source_document_number_id
 * @property integer $is_acquisition_approved
 * @property string $date_acquired
 * @property string $acquisition_approved_date
 * @property string $update_time
 * @property integer $acquisition_approved_id
 * @property integer $acquisition_enterred_by_id
 * @property integer $transaction_type_id
 * @property integer $update_user_id
 * @property string $create_time
 *
 * The followings are the available model relations:
 * @property AgrantPropertyAssetSlot[] $agrantPropertyAssetSlots
 * @property ServiceOutlet $sol
 * @property ProductionAssets $productionAsset
 */
class AgrantPropertyBatchedPondsAsset extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'agrant_property_batched_ponds_asset';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('production_asset_id, sol_id, pond_batch_unique_number, accounting_preference, method_of_acquisition', 'required'),
			array('pond_batch_unique_number, number_of_ponds_in_batch, property_pond_gl_id, number_to_split_batch, primary_source_document_number_id, is_acquisition_approved, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('total_acquisition_cost, average_cost_per_pond, total_construction_cost', 'numerical'),
			array('production_asset_id, sol_id, parameter_to_base_batch_split', 'length', 'max'=>10),
			array('short_description, other_acquisition_method, acquired_from, other_batch_split_parameter', 'length', 'max'=>250),
			array('accounting_preference', 'length', 'max'=>11),
			array('method_of_acquisition', 'length', 'max'=>9),
			array('description, date_acquired, acquisition_approved_date, update_time, create_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, production_asset_id, sol_id, pond_batch_unique_number, number_of_ponds_in_batch, short_description, description, accounting_preference, method_of_acquisition, other_acquisition_method, acquired_from, property_pond_gl_id, number_to_split_batch, parameter_to_base_batch_split, other_batch_split_parameter, total_acquisition_cost, average_cost_per_pond, total_construction_cost, primary_source_document_number_id, is_acquisition_approved, date_acquired, acquisition_approved_date, update_time, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id, update_user_id, create_time', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'agrantPropertyAssetSlots' => array(self::HAS_MANY, 'AgrantPropertyAssetSlot', 'pond_batch_id'),
			'sol' => array(self::BELONGS_TO, 'ServiceOutlet', 'sol_id'),
			'productionAsset' => array(self::BELONGS_TO, 'ProductionAssets', 'production_asset_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'production_asset_id' => 'Production Asset',
			'sol_id' => 'Sol',
			'pond_batch_unique_number' => 'Pond Batch Unique Number',
			'number_of_ponds_in_batch' => 'Number Of Ponds In Batch',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'accounting_preference' => 'Accounting Preference',
			'method_of_acquisition' => 'Method Of Acquisition',
			'other_acquisition_method' => 'Other Acquisition Method',
			'acquired_from' => 'Acquired From',
			'property_pond_gl_id' => 'Property Pond Gl',
			'number_to_split_batch' => 'Number To Split Batch',
			'parameter_to_base_batch_split' => 'Parameter To Base Batch Split',
			'other_batch_split_parameter' => 'Other Batch Split Parameter',
			'total_acquisition_cost' => 'Total Acquisition Cost',
			'average_cost_per_pond' => 'Average Cost Per Pond',
			'total_construction_cost' => 'Total Construction Cost',
			'primary_source_document_number_id' => 'Primary Source Document Number',
			'is_acquisition_approved' => 'Is Acquisition Approved',
			'date_acquired' => 'Date Acquired',
			'acquisition_approved_date' => 'Acquisition Approved Date',
			'update_time' => 'Update Time',
			'acquisition_approved_id' => 'Acquisition Approved',
			'acquisition_enterred_by_id' => 'Acquisition Enterred By',
			'transaction_type_id' => 'Transaction Type',
			'update_user_id' => 'Update User',
			'create_time' => 'Create Time',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('production_asset_id',$this->production_asset_id,true);
		$criteria->compare('sol_id',$this->sol_id,true);
		$criteria->compare('pond_batch_unique_number',$this->pond_batch_unique_number);
		$criteria->compare('number_of_ponds_in_batch',$this->number_of_ponds_in_batch);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('accounting_preference',$this->accounting_preference,true);
		$criteria->compare('method_of_acquisition',$this->method_of_acquisition,true);
		$criteria->compare('other_acquisition_method',$this->other_acquisition_method,true);
		$criteria->compare('acquired_from',$this->acquired_from,true);
		$criteria->compare('property_pond_gl_id',$this->property_pond_gl_id);
		$criteria->compare('number_to_split_batch',$this->number_to_split_batch);
		$criteria->compare('parameter_to_base_batch_split',$this->parameter_to_base_batch_split,true);
		$criteria->compare('other_batch_split_parameter',$this->other_batch_split_parameter,true);
		$criteria->compare('total_acquisition_cost',$this->total_acquisition_cost);
		$criteria->compare('average_cost_per_pond',$this->average_cost_per_pond);
		$criteria->compare('total_construction_cost',$this->total_construction_cost);
		$criteria->compare('primary_source_document_number_id',$this->primary_source_document_number_id);
		$criteria->compare('is_acquisition_approved',$this->is_acquisition_approved);
		$criteria->compare('date_acquired',$this->date_acquired,true);
		$criteria->compare('acquisition_approved_date',$this->acquisition_approved_date,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('acquisition_approved_id',$this->acquisition_approved_id);
		$criteria->compare('acquisition_enterred_by_id',$this->acquisition_enterred_by_id);
		$criteria->compare('transaction_type_id',$this->transaction_type_id);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('create_time',$this->create_time,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AgrantPropertyBatchedPondsAsset the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
