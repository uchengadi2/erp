<?php

/**
 * This is the model class for table "imagineplace_sds_asset_slot".
 *
 * The followings are the available columns in table 'imagineplace_sds_asset_slot':
 * @property string $id
 * @property string $batch_sds_id
 * @property string $sds_unique_number
 * @property string $series_slot_name
 * @property integer $number_of_sds
 * @property string $sds_type
 * @property string $short_description
 * @property string $description
 * @property integer $dimension_height
 * @property integer $dimension_width
 *
 * The followings are the available model relations:
 * @property ImagineplaceBatchedSdsAsset $batchSds
 */
class ImagineplaceSdsAssetSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'imagineplace_sds_asset_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('batch_sds_id', 'required'),
			array('number_of_sds', 'numerical', 'integerOnly'=>true),
                        array('dimension_height, dimension_width', 'numerical'),
			array('batch_sds_id', 'length', 'max'=>10),
			array('sds_unique_number, series_slot_name, short_description', 'length', 'max'=>250),
			array('sds_type', 'length', 'max'=>12),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, batch_sds_id, sds_unique_number, series_slot_name, number_of_sds, sds_type, short_description, description, dimension_height, dimension_width', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'batchSds' => array(self::BELONGS_TO, 'ImagineplaceBatchedSdsAsset', 'batch_sds_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'batch_sds_id' => 'Batch Sds',
			'sds_unique_number' => 'Sds Unique Number',
			'series_slot_name' => 'Series Slot Name',
			'number_of_sds' => 'Number Of Sds',
			'sds_type' => 'Sds Type',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'dimension_height' => 'Dimension Height',
			'dimension_width' => 'Dimension Width',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('batch_sds_id',$this->batch_sds_id,true);
		$criteria->compare('sds_unique_number',$this->sds_unique_number,true);
		$criteria->compare('series_slot_name',$this->series_slot_name,true);
		$criteria->compare('number_of_sds',$this->number_of_sds);
		$criteria->compare('sds_type',$this->sds_type,true);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('dimension_height',$this->dimension_height);
		$criteria->compare('dimension_width',$this->dimension_width);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ImagineplaceSdsAssetSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
         /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($asset_series_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('imagineplace_sds_asset_slot')
                    ->where("batch_sds_id=$asset_series_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= ImagineplaceSdsAssetSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
