<?php

/**
 * This is the model class for table "agrant_property_plantation_asset_slot".
 *
 * The followings are the available columns in table 'agrant_property_plantation_asset_slot':
 * @property string $id
 * @property string $plantation_id
 * @property string $slot_unique_number
 * @property integer $number_of_plants
 * @property string $short_description
 * @property double $average_dimension_height_in_meters
 * @property string $description
 * @property string $slot_name
 * @property string $plantation_type
 * @property integer $slot_gl_id
 * @property integer $duration_of_acquisition_in_months
 * @property string $plant_specie
 * @property string $plant_fertilization_status
 * @property string $plant_variant
 * @property double $total_slots_cost
 * @property double $average_cost_per_plant
 * @property double $cultivation_cost
 * @property string $location
 * @property integer $series_slot_incrementer
 *
 * The followings are the available model relations:
 * @property AgrantPropertyPlantationAsset $plantation
 */
class AgrantPropertyPlantationAssetSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'agrant_property_plantation_asset_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('plantation_id, plantation_type', 'required'),
			array('number_of_plants, slot_gl_id, duration_of_acquisition_in_months, series_slot_incrementer', 'numerical', 'integerOnly'=>true),
			array('average_dimension_height_in_meters, total_slots_cost, average_cost_per_plant, cultivation_cost', 'numerical'),
			array('plantation_id', 'length', 'max'=>10),
			array('slot_unique_number, short_description, plant_specie, plant_variant, location', 'length', 'max'=>250),
			array('slot_name', 'length', 'max'=>150),
			array('plantation_type', 'length', 'max'=>13),
			array('plant_fertilization_status', 'length', 'max'=>14),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, plantation_id, slot_unique_number, number_of_plants, short_description, average_dimension_height_in_meters, description, slot_name, plantation_type, slot_gl_id, duration_of_acquisition_in_months, plant_specie, plant_fertilization_status, plant_variant, total_slots_cost, average_cost_per_plant, cultivation_cost, location, series_slot_incrementer', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'plantation' => array(self::BELONGS_TO, 'AgrantPropertyPlantationAsset', 'plantation_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'plantation_id' => 'Plantation',
			'slot_unique_number' => 'Slot Unique Number',
			'number_of_plants' => 'Number Of Plants',
			'short_description' => 'Short Description',
			'average_dimension_height_in_meters' => 'Average Dimension Height In Meters',
			'description' => 'Description',
			'slot_name' => 'Slot Name',
			'plantation_type' => 'Plantation Type',
			'slot_gl_id' => 'Slot Gl',
			'duration_of_acquisition_in_months' => 'Duration Of Acquisition In Months',
			'plant_specie' => 'Plant Specie',
			'plant_fertilization_status' => 'Plant Fertilization Status',
			'plant_variant' => 'Plant Variant',
			'total_slots_cost' => 'Total Slots Cost',
			'average_cost_per_plant' => 'Average Cost Per Plant',
			'cultivation_cost' => 'Cultivation Cost',
			'location' => 'Location',
			'series_slot_incrementer' => 'Series Slot Incrementer',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('plantation_id',$this->plantation_id,true);
		$criteria->compare('slot_unique_number',$this->slot_unique_number,true);
		$criteria->compare('number_of_plants',$this->number_of_plants);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('average_dimension_height_in_meters',$this->average_dimension_height_in_meters);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('slot_name',$this->slot_name,true);
		$criteria->compare('plantation_type',$this->plantation_type,true);
		$criteria->compare('slot_gl_id',$this->slot_gl_id);
		$criteria->compare('duration_of_acquisition_in_months',$this->duration_of_acquisition_in_months);
		$criteria->compare('plant_specie',$this->plant_specie,true);
		$criteria->compare('plant_fertilization_status',$this->plant_fertilization_status,true);
		$criteria->compare('plant_variant',$this->plant_variant,true);
		$criteria->compare('total_slots_cost',$this->total_slots_cost);
		$criteria->compare('average_cost_per_plant',$this->average_cost_per_plant);
		$criteria->compare('cultivation_cost',$this->cultivation_cost);
		$criteria->compare('location',$this->location,true);
		$criteria->compare('series_slot_incrementer',$this->series_slot_incrementer);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AgrantPropertyPlantationAssetSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($asset_series_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('agrant_property_plantation_asset_slot')
                    ->where("plantation_id=$asset_series_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= AgrantPropertyPlantationAssetSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
