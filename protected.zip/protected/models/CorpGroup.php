<?php

/**
 * This is the model class for table "corp_group".
 *
 * The followings are the available columns in table 'corp_group':
 * @property string $id
 * @property string $name
 * @property string $description
 * @property string $code
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Authitem[] $authitems
 * @property Modules[] $modules
 * @property Organization[] $organizations
 * @property User[] $users
 */
class CorpGroup extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'corp_group';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, code', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('name, code', 'length', 'max'=>250),
			array('description, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, description, code, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'authitems' => array(self::HAS_MANY, 'Authitem', 'group_id'),
			'modules' => array(self::MANY_MANY, 'Modules', 'group_has_module(group_id, module_id)'),
			'organizations' => array(self::HAS_MANY, 'Organization', 'group_id'),
			'users' => array(self::HAS_MANY, 'User', 'group_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'code' => 'Code',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CorpGroup the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that generates a groups code
         */
        public function generateThisCorporateGroupCode(){
            if($this->isThisTheFirstGroup()){
                $code = "000000";
                return $code;
            }else{
                $current_code_number = $this->getTheCodeMaximumGroupCodeNumber();
                $new_current_code_number = (int)$current_code_number + 1;
                if(strlen($current_code_number) == 1){
                    $code = str_pad($new_current_code_number,6,0,STR_PAD_LEFT);
                }else if(strlen($current_code_number) == 2){
                    $code = str_pad($new_current_code_number,6,0,STR_PAD_LEFT);
                }else if(strlen($current_code_number) == 3){
                    $code = str_pad($new_current_code_number,6,0,STR_PAD_LEFT);
                }else if(strlen($current_code_number) == 4){
                    $code = str_pad($new_current_code_number,6,0,STR_PAD_LEFT);
                }else if(strlen($current_code_number) == 5){
                    $code = str_pad($new_current_code_number,6,0,STR_PAD_LEFT);
                }else if(strlen($current_code_number) == 6){
                    $code = str_pad($new_current_code_number,6,0,STR_PAD_LEFT);
                }else{
                    $code =$new_current_code_number;
                }
                return $code;
            }
        }
        
        
        
        /**
         * is this first the group
         */
        public function isThisTheFirstGroup(){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('corp_group');
                    //->where("id>0");
                $result = $cmd->queryScalar();
                
                if($result==0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
       /**
        * This is the function that retrieves the current code numbering status
        */
        public function getTheCodeMaximumGroupCodeNumber(){
            
            if($this->isThisTheFirstGroup() == false){
                $target = [];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $numberings = CorpGroup::model()->findAll($criteria); 
           foreach($numberings as $num){
               $target[] = $num['code_numbering'];
           }
           return max($target);
            }else{
                return 0;
            }
           
          
        }
        
         /**
         * This is the function that gets the name of a group
         */
        public function getTheNameOfTheGroup($id){
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $name= CorpGroup::model()->find($criteria);
                
                return $name['name'];
        }
}
