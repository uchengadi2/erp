<?php

/**
 * This is the model class for table "agrant_livestock_asset_slot".
 *
 * The followings are the available columns in table 'agrant_livestock_asset_slot':
 * @property string $id
 * @property string $livestock_batch_id
 * @property integer $livestock_unique_number
 * @property integer $number_of_livestock
 * @property string $short_description
 * @property string $slot_name
 * @property string $livestock
 * @property string $description
 * @property integer $slot_gl_id
 * @property double $total_slots_cost
 * @property double $delivery_cost
 * @property double $loading_cost
 * @property double $average_livestock_weight_in_kg
 * @property string $livestock_type
 * @property string $livestock_breed
 * @property string $livestock_colour
 * @property string $livestock_gender
 * @property string $livestock_variant
 * @property integer $average_livestock_age_in_months
 *
 * The followings are the available model relations:
 * @property AgrantBatchedLivestockAsset $livestockBatch
 */
class AgrantLivestockAssetSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'agrant_livestock_asset_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('livestock_batch_id, livestock_unique_number', 'required'),
			array('number_of_livestock, slot_gl_id, average_livestock_age_in_months', 'numerical', 'integerOnly'=>true),
			array('total_slots_cost, delivery_cost, loading_cost, average_livestock_weight_in_kg', 'numerical'),
			array('livestock_batch_id', 'length', 'max'=>10),
			array('livestock_unique_number,short_description, slot_name, livestock, livestock_type, livestock_breed, livestock_colour, livestock_gender, livestock_variant', 'length', 'max'=>250),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, livestock_batch_id, livestock_unique_number, number_of_livestock, short_description, slot_name, livestock, description, slot_gl_id, total_slots_cost, delivery_cost, loading_cost, average_livestock_weight_in_kg, livestock_type, livestock_breed, livestock_colour, livestock_gender, livestock_variant, average_livestock_age_in_months', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'livestockBatch' => array(self::BELONGS_TO, 'AgrantBatchedLivestockAsset', 'livestock_batch_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'livestock_batch_id' => 'Livestock Batch',
			'livestock_unique_number' => 'Livestock Unique Number',
			'number_of_livestock' => 'Number Of Livestock',
			'short_description' => 'Short Description',
			'slot_name' => 'Slot Name',
			'livestock' => 'Livestock',
			'description' => 'Description',
			'slot_gl_id' => 'Slot Gl',
			'total_slots_cost' => 'Total Slots Cost',
			'delivery_cost' => 'Delivery Cost',
			'loading_cost' => 'Loading Cost',
			'average_livestock_weight_in_kg' => 'Average Livestock Weight In Kg',
			'livestock_type' => 'Livestock Type',
			'livestock_breed' => 'Livestock Breed',
			'livestock_colour' => 'Livestock Colour',
			'livestock_gender' => 'Livestock Gender',
			'livestock_variant' => 'Livestock Variant',
			'average_livestock_age_in_months' => 'Average Livestock Age In Months',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('livestock_batch_id',$this->livestock_batch_id,true);
		$criteria->compare('livestock_unique_number',$this->livestock_unique_number);
		$criteria->compare('number_of_livestock',$this->number_of_livestock);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('slot_name',$this->slot_name,true);
		$criteria->compare('livestock',$this->livestock,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('slot_gl_id',$this->slot_gl_id);
		$criteria->compare('total_slots_cost',$this->total_slots_cost);
		$criteria->compare('delivery_cost',$this->delivery_cost);
		$criteria->compare('loading_cost',$this->loading_cost);
		$criteria->compare('average_livestock_weight_in_kg',$this->average_livestock_weight_in_kg);
		$criteria->compare('livestock_type',$this->livestock_type,true);
		$criteria->compare('livestock_breed',$this->livestock_breed,true);
		$criteria->compare('livestock_colour',$this->livestock_colour,true);
		$criteria->compare('livestock_gender',$this->livestock_gender,true);
		$criteria->compare('livestock_variant',$this->livestock_variant,true);
		$criteria->compare('average_livestock_age_in_months',$this->average_livestock_age_in_months);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AgrantLivestockAssetSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($asset_series_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('agrant_livestock_asset_slot')
                    ->where("livestock_batch_id=$asset_series_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= AgrantLivestockAssetSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
