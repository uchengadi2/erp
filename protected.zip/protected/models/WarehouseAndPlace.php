<?php

/**
 * This is the model class for table "warehouse_and_place".
 *
 * The followings are the available columns in table 'warehouse_and_place':
 * @property string $id
 * @property string $name
 * @property string $address
 * @property string $description
 * @property string $location_id
 * @property string $type
 * @property double $total_space_in_square_feets
 * @property double $total_unusable_space_in_square_feets
 * @property double $warehouse_total_storage_in_square_feets
 * @property double $warehouse_height_in_feet
 * @property double $warehouse_storage_capacity_in_cubic_feet
 * @property double $remaining_storage_capacity_in_cubic_feet
 * @property double $location_latitude
 * @property integer $is_for_storage
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 * @property integer $service_outlet_owner_id
 * @property integer $is_deleted
 * @property integer $is_approved
 * @property string $date_approved
 * @property integer $approved_by_id
 * @property integer $is_modification_approved
 * @property double $location_longtitude
 * @property double $warehouse_length_in_feet
 * @property double $warehouse_breadth_in_feet
 *
 * The followings are the available model relations:
 * @property AllocateWarehouseStorageSpace[] $allocateWarehouseStorageSpaces
 * @property AssetInWarehouseAndPlace[] $assetInWarehouseAndPlaces
 * @property MaintenanceForWarehouseAndPlace[] $maintenanceForWarehouseAndPlaces
 * @property Location $location
 */
class WarehouseAndPlace extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'warehouse_and_place';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, address, location_id, type', 'required'),
			array('is_for_storage, create_user_id, update_user_id, service_outlet_owner_id, is_deleted, is_approved, approved_by_id, is_modification_approved', 'numerical', 'integerOnly'=>true),
			array('location_id,total_space_in_square_feets, total_unusable_space_in_square_feets, warehouse_total_storage_in_square_feets, warehouse_height_in_feet, warehouse_storage_capacity_in_cubic_feet, remaining_storage_capacity_in_cubic_feet, location_latitude, location_longtitude, warehouse_length_in_feet, warehouse_breadth_in_feet', 'numerical'),
			array('name, address', 'length', 'max'=>250),
			array('location_id', 'length', 'max'=>10),
			array('type', 'length', 'max'=>9),
			array('description, create_time, update_time, date_approved', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, address, description, location_id, type, total_space_in_square_feets, total_unusable_space_in_square_feets, warehouse_total_storage_in_square_feets, warehouse_height_in_feet, warehouse_storage_capacity_in_cubic_feet, remaining_storage_capacity_in_cubic_feet, location_latitude, is_for_storage, create_time, update_time, create_user_id, update_user_id, service_outlet_owner_id, is_deleted, is_approved, date_approved, approved_by_id, is_modification_approved, location_longtitude, warehouse_length_in_feet, warehouse_breadth_in_feet', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'allocateWarehouseStorageSpaces' => array(self::HAS_MANY, 'AllocateWarehouseStorageSpace', 'warehouse_id'),
			'assetInWarehouseAndPlaces' => array(self::HAS_MANY, 'AssetInWarehouseAndPlace', 'warehouse_and_place_id'),
			'maintenanceForWarehouseAndPlaces' => array(self::HAS_MANY, 'MaintenanceForWarehouseAndPlace', 'warehouse_and_place_id'),
			'location' => array(self::BELONGS_TO, 'Location', 'location_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'address' => 'Address',
			'description' => 'Description',
			'location_id' => 'Location',
			'type' => 'Type',
			'total_space_in_square_feets' => 'Total Space In Square Feets',
			'total_unusable_space_in_square_feets' => 'Total Unusable Space In Square Feets',
			'warehouse_total_storage_in_square_feets' => 'Warehouse Total Storage In Square Feets',
			'warehouse_height_in_feet' => 'Warehouse Height In Feet',
			'warehouse_storage_capacity_in_cubic_feet' => 'Warehouse Storage Capacity In Cubic Feet',
			'remaining_storage_capacity_in_cubic_feet' => 'Remaining Storage Capacity In Cubic Feet',
			'location_latitude' => 'Location Latitude',
			'is_for_storage' => 'Is For Storage',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
			'service_outlet_owner_id' => 'Service Outlet Owner',
			'is_deleted' => 'Is Deleted',
			'is_approved' => 'Is Approved',
			'date_approved' => 'Date Approved',
			'approved_by_id' => 'Approved By',
			'is_modification_approved' => 'Is Modification Approved',
			'location_longtitude' => 'Location Longtitude',
			'warehouse_length_in_feet' => 'Warehouse Length In Feet',
			'warehouse_breadth_in_feet' => 'Warehouse Breadth In Feet',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('address',$this->address,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('location_id',$this->location_id,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('total_space_in_square_feets',$this->total_space_in_square_feets);
		$criteria->compare('total_unusable_space_in_square_feets',$this->total_unusable_space_in_square_feets);
		$criteria->compare('warehouse_total_storage_in_square_feets',$this->warehouse_total_storage_in_square_feets);
		$criteria->compare('warehouse_height_in_feet',$this->warehouse_height_in_feet);
		$criteria->compare('warehouse_storage_capacity_in_cubic_feet',$this->warehouse_storage_capacity_in_cubic_feet);
		$criteria->compare('remaining_storage_capacity_in_cubic_feet',$this->remaining_storage_capacity_in_cubic_feet);
		$criteria->compare('location_latitude',$this->location_latitude);
		$criteria->compare('is_for_storage',$this->is_for_storage);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('service_outlet_owner_id',$this->service_outlet_owner_id);
		$criteria->compare('is_deleted',$this->is_deleted);
		$criteria->compare('is_approved',$this->is_approved);
		$criteria->compare('date_approved',$this->date_approved,true);
		$criteria->compare('approved_by_id',$this->approved_by_id);
		$criteria->compare('is_modification_approved',$this->is_modification_approved);
		$criteria->compare('location_longtitude',$this->location_longtitude);
		$criteria->compare('warehouse_length_in_feet',$this->warehouse_length_in_feet);
		$criteria->compare('warehouse_breadth_in_feet',$this->warehouse_breadth_in_feet);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return WarehouseAndPlace the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that recalculates the available space capacity for a warehouse and place
         */
        public function recalculateWarehouseAndPlaceRemainingSpace($id, $new_remaining_space){
            
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('warehouse_and_place',
                                  array(
                                    'remaining_storage_capacity_in_cubic_feet'=>$new_remaining_space
                                   
                               
		
                            ),
                     ("id=$id"));
            
        }
        
        
        
         /**
         * this is the function that gets the name of a warehouse and place
         */
        public function getTheNameOfThisWarehouseAndPlace($warehouse_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$warehouse_id);
                $name= WarehouseAndPlace::model()->find($criteria);
                
                return $name['name'];
            
        }
       
}
