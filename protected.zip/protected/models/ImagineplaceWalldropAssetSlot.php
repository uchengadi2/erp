<?php

/**
 * This is the model class for table "imagineplace_walldrop_asset_slot".
 *
 * The followings are the available columns in table 'imagineplace_walldrop_asset_slot':
 * @property string $id
 * @property string $batch_walldrop_id
 * @property string $walldrop_unique_number
 * @property integer $number_of_walldrop
 * @property string $property_type
 * @property string $short_description
 * @property string $description
 * @property integer $dimension_height
 * @property integer $dimension_width
 * @property string $walldrop_type
 *
 * The followings are the available model relations:
 * @property ImagineplaceBatchedWalldropAssetSeries $batchWalldrop
 */
class ImagineplaceWalldropAssetSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'imagineplace_walldrop_asset_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('batch_walldrop_id', 'required'),
			array('number_of_walldrop', 'numerical', 'integerOnly'=>true),
                        array('dimension_height, dimension_width', 'numerical'),
			array('batch_walldrop_id', 'length', 'max'=>10),
			array('walldrop_unique_number, short_description, walldrop_type', 'length', 'max'=>250),
			array('property_type', 'length', 'max'=>8),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, batch_walldrop_id, walldrop_unique_number, number_of_walldrop, property_type, short_description, description, dimension_height, dimension_width, walldrop_type', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'batchWalldrop' => array(self::BELONGS_TO, 'ImagineplaceBatchedWalldropAssetSeries', 'batch_walldrop_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'batch_walldrop_id' => 'Batch Walldrop',
			'walldrop_unique_number' => 'Walldrop Unique Number',
			'number_of_walldrop' => 'Number Of Walldrop',
			'property_type' => 'Property Type',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'dimension_height' => 'Dimension Height',
			'dimension_width' => 'Dimension Width',
			'walldrop_type' => 'Walldrop Type',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('batch_walldrop_id',$this->batch_walldrop_id,true);
		$criteria->compare('walldrop_unique_number',$this->walldrop_unique_number,true);
		$criteria->compare('number_of_walldrop',$this->number_of_walldrop);
		$criteria->compare('property_type',$this->property_type,true);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('dimension_height',$this->dimension_height);
		$criteria->compare('dimension_width',$this->dimension_width);
		$criteria->compare('walldrop_type',$this->walldrop_type,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ImagineplaceWalldropAssetSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
         /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($wall_drop_batch_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('imagineplace_walldrop_asset_slot')
                    ->where("batch_walldrop_id=$wall_drop_batch_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= ImagineplaceWalldropAssetSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
