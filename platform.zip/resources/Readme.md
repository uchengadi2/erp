# ext-theme-neptune-fb0e91d3-8ef7-4272-99f0-31452e743c09/resources

This folder contains static resources (typically an `"images"` folder as well).
