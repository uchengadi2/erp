<?php

class SbuController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addanewsbu','listOrganizationAllSbus','deleteonesbu','modifysbu','listDivisionsInThisSbu',
                                    'adddivisiontosbu','removedivisionfromsbu'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function that list all sbus of an organization
         */
        public function actionlistOrganizationAllSbus(){
            
            $organization_id = $_REQUEST['organization_id'];
         
                   
            $data = [];
            $q = "select a.*, b.id as organization_id, b.name as organization_name  from sbu a
                    JOIN organization b ON a.organization_id=b.id
                     where a.organization_id =$organization_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "sbu"=>$data,
                                  
                            ));
            
        }
        
        
        
        /**
      * This is the function that add new Sbu for an organization
      */
     public function actionaddanewsbu(){
         
         $model = new Sbu;
            
             $model->organization_id = $_POST['organization_id'];
             $organization_name = $_POST['organization_name'];
            
               $model->name = $_POST['name']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  '$model->name' sbu to the '$organization_name' organization";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this Sbu to the '$organization_name' was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
         
     }
     
     
     
      /**
         * This is the function that modifies a sbu
         */
        public function actionmodifysbu(){
            
            $_id = $_POST['id'];
            
            $model= Sbu::model()->findByPk($_id);
            $model->name = $_POST['name'];
            $model->organization_id = $_POST['organization_id'];
              if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated this Sbu';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The update of this Sbu was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
            
        }
        
        
         /**
         * This is the function that deletes one sbu
         */
        public function actiondeleteonesbu(){
            
            $_id = $_POST['id'];
            $model= Sbu::model()->findByPk($_id);
            
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' Sbu is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
            
        }
        
        
        
        /**
         * This is the function that list all divisions in an sbu of an organization
         */
        public function actionlistDivisionsInThisSbu(){
            
            $sbu_id = $_REQUEST['sbu_id'];
         
                   
            $data = [];
            $q = "select a.*, b.sbu_id as sbu_id, 
                (select name from sbu where id=b.sbu_id) as sbu_name
                from division a
                    JOIN sbu_has_division b ON a.id=b.division_id
                     where b.sbu_id =$sbu_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "division"=>$data,
                                  
                            ));
            
        }
        
        
        /**
         * This is the function that adds a division to an sbu
         */
        public function actionadddivisiontosbu(){
            
            $model = new SbuHasDivision;
            
            $sbu_name = $_REQUEST['sbu_name'];
            $division_name = $_REQUEST['division_name'];
            
            $model->sbu_id = $_POST['sbu_id'];
                $model->division_id = $_POST['division_id'];
             if($model->isThisDivisionAlreadyInTheSbu($model->division_id,$model->sbu_id) == false){
               $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added the '$division_name' Division to the '$sbu_name' Sbu";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add the '$division_name' Division to the '$sbu_name' Sbu was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            }else{
                    $msg = "This '$division_name' Division is already assigned to the '$sbu_name' Sbu";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );    
                        
                        
                    }
        }
        
        
        
        /**
         * This is the function that removes a division from an sbu
         */
        public function actionremovedivisionfromsbu(){
            
            $sbu_id = $_REQUEST['sbu_id'];
            $division_id = $_REQUEST['division_id'];
            $sbu_name = $_REQUEST['sbu_name'];
            $division_name = $_REQUEST['division_name'];
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='sbu_id=:sbuid and division_id=:divisionid';
                $criteria->params = array(':sbuid'=>$sbu_id,':divisionid'=>$division_id);
                $model= SbuHasDivision::model()->find($criteria);
            
                                   
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$division_name' Division is successfully removed from the '$sbu_name' sbu";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
}
