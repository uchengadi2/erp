<?php

class AssetInProjectMaintenanceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listprojectallassetsformaintenance','initiatingProjectResourceMaintenance',
                                    'listprojectallmodifiedassetsformaintenance','ModifyProjectResourceMaintenance','listprojectallunapprovedassetsformaintenance',
                                    'listprojectallunapprovedassetsformaintenance','listprojectallwithdrawnassetsformaintenance','listprojectallapprovedassetsformaintenance',
                                    'rejectProjectResourceMaintenance','approveProjectResourceMaintenance','unwithdrawProjectResourceMaintenance',
                                    'withdrawProjectResourceMaintenance'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all initiated assets in projects for maintenance
         */
        public function actionlistprojectallassetsformaintenance(){
            
            $project_asset_id = $_REQUEST['project_asset_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
           
            
            $data = [];
            $q = "select a.*, a.quantity as maintenance_quantity,b.asset_assignment_id, b.status, b.allocation_ref_code,b.quantity,d.id as allocation_id,e.name as warehouse_and_place,
                c.production_asset_id, d.id as allocation,
                (select name from service_outlet where id = $sol_id) as service_outlet,
                (select name from organization where id =$organization_id) as organization_name,    
                (select name from project where id=b.project_id) as project,
                (select name from production_assets where id=c.production_asset_id) as production_asset
                 from asset_in_project_maintenance a
                    JOIN asset_for_project b ON a.asset_for_project_id=b.id
                    JOIN asset_in_warehouse_and_place c ON b.asset_assignment_id=c.id
                    JOIN allocate_warehouse_storage_space d ON c.warehouse_and_place_allocation_id=d.id
                    JOIN warehouse_and_place e ON d.warehouse_id=e.id
                     where (b.id=$project_asset_id) and (a.is_approved=0 and a.is_deleted=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        
        /**
         * This is the function that list all modified assets in projects for maintenance
         */
        public function actionlistprojectallmodifiedassetsformaintenance(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
           
            
            $data = [];
            $q = "select a.*, a.quantity as maintenance_quantity, a.description as maintenance_description,b.asset_assignment_id, b.status, b.id as asset_for_project_id,
                b.allocation_ref_code,b.quantity,d.id as allocation_id,e.name as warehouse_and_place,c.sku,c.quantity_of_assets_in_capacity as available_quantity,
                c.production_asset_id, d.id as allocation,
                (select name from service_outlet where id = $sol_id) as service_outlet,
                (select name from organization where id =$organization_id) as organization_name,    
                (select name from project where id=b.project_id) as project,
                (select name from production_assets where id=c.production_asset_id) as production_asset
                 from asset_in_project_maintenance a
                    JOIN asset_for_project b ON a.asset_for_project_id=b.id
                    JOIN asset_in_warehouse_and_place c ON b.asset_assignment_id=c.id
                    JOIN allocate_warehouse_storage_space d ON c.warehouse_and_place_allocation_id=d.id
                    JOIN warehouse_and_place e ON d.warehouse_id=e.id
                     where b.project_id=$project_id and a.is_deleted=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        
         /**
         * This is the function that list all unapprove assets in projects maintenances
         */
        public function actionlistprojectallunapprovedassetsformaintenance(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
           
            
            $data = [];
            $q = "select a.*, a.quantity as maintenance_quantity, a.description as maintenance_description,b.asset_assignment_id, b.status, b.id as asset_for_project_id,
                b.allocation_ref_code,b.quantity,d.id as allocation_id,e.name as warehouse_and_place,c.sku,c.quantity_of_assets_in_capacity as available_quantity,
                c.production_asset_id, d.id as allocation,
                (select name from service_outlet where id = $sol_id) as service_outlet,
                (select name from organization where id =$organization_id) as organization_name,    
                (select name from project where id=b.project_id) as project,
                (select name from production_assets where id=c.production_asset_id) as production_asset
                 from asset_in_project_maintenance a
                    JOIN asset_for_project b ON a.asset_for_project_id=b.id
                    JOIN asset_in_warehouse_and_place c ON b.asset_assignment_id=c.id
                    JOIN allocate_warehouse_storage_space d ON c.warehouse_and_place_allocation_id=d.id
                    JOIN warehouse_and_place e ON d.warehouse_id=e.id
                     where b.project_id=$project_id and (a.is_approved=0 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        
        /**
         * This is the function that list all approve assets in projects maintenances
         */
        public function actionlistprojectallapprovedassetsformaintenance(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
           
            
            $data = [];
            $q = "select a.*, a.quantity as maintenance_quantity, a.description as maintenance_description,b.asset_assignment_id, b.status, b.id as asset_for_project_id,
                b.allocation_ref_code,b.quantity,d.id as allocation_id,e.name as warehouse_and_place,c.sku,c.quantity_of_assets_in_capacity as available_quantity,
                c.production_asset_id, d.id as allocation,
                (select name from service_outlet where id = $sol_id) as service_outlet,
                (select name from organization where id =$organization_id) as organization_name,    
                (select name from project where id=b.project_id) as project,
                (select name from production_assets where id=c.production_asset_id) as production_asset
                 from asset_in_project_maintenance a
                    JOIN asset_for_project b ON a.asset_for_project_id=b.id
                    JOIN asset_in_warehouse_and_place c ON b.asset_assignment_id=c.id
                    JOIN allocate_warehouse_storage_space d ON c.warehouse_and_place_allocation_id=d.id
                    JOIN warehouse_and_place e ON d.warehouse_id=e.id
                     where b.project_id=$project_id and (a.is_approved=1 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
         /**
         * This is the function that list all withdrawn assets in projects maintenances
         */
        public function actionlistprojectallwithdrawnassetsformaintenance(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
           
            
            $data = [];
            $q = "select a.*, a.quantity as maintenance_quantity, a.description as maintenance_description,b.asset_assignment_id, b.status, b.id as asset_for_project_id,
                b.allocation_ref_code,b.quantity,d.id as allocation_id,e.name as warehouse_and_place,c.sku,c.quantity_of_assets_in_capacity as available_quantity,
                c.production_asset_id, d.id as allocation,
                (select name from service_outlet where id = $sol_id) as service_outlet,
                (select name from organization where id =$organization_id) as organization_name,    
                (select name from project where id=b.project_id) as project,
                (select name from production_assets where id=c.production_asset_id) as production_asset
                 from asset_in_project_maintenance a
                    JOIN asset_for_project b ON a.asset_for_project_id=b.id
                    JOIN asset_in_warehouse_and_place c ON b.asset_assignment_id=c.id
                    JOIN allocate_warehouse_storage_space d ON c.warehouse_and_place_allocation_id=d.id
                    JOIN warehouse_and_place e ON d.warehouse_id=e.id
                     where b.project_id=$project_id and (a.is_approved=0 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        /**
         * This is the function that initiates Project Resource Maintenance
         */
        public function actioninitiatingProjectResourceMaintenance(){
            
             $model = new AssetInProjectMaintenance;
            
            $project_id = $_REQUEST['project_id'];
             $model->asset_for_project_id = $_POST['id'];
            $sol_id = $_REQUEST['sol_id'];
            $available_quantity = $_REQUEST['available_quantity'];
            $organization_name = $_POST['organization_name'];
             $project_name = $_REQUEST['project_name'];
               $model->maintenance_status = $_POST['maintenance_status']; 
               $model->quantity = $_POST['maintenance_quantity'];
               $model->maintenance_type = $_POST['maintenance_type'];
               $model->maintenance_cost = $_POST['maintenance_cost'];
               if(isset($_POST['maintenance_description'])){
                    $model->description = $_POST['maintenance_description']; 
               }
               if(isset($_POST['reason_for_maintenance'])){
                    $model->reason_for_maintenance = $_POST['reason_for_maintenance']; 
               }
              $model->date_initiated = new CDbExpression('NOW()');
                $model->initiated_by_id = Yii::app()->user->id;
                if($model->save()){
                    
                       
                         // $result['success'] = 'true';
                          $msg = "Successfully initiated this Project Resource for Maintenance. Approval is pending";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to initiate this Resource for Maintenance was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                       )
                           );
                    } 
            
        }
        
        
        /**
         * This is the function that modifies a project resource maintenance request
         */
        public function actionModifyProjectResourceMaintenance(){
            
             $_id = $_POST['id'];
            $model= AssetInProjectMaintenance::model()->findByPk($_id);
            
            $project_id = $_REQUEST['project_id'];
             $model->asset_for_project_id = $_POST['asset_for_project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $available_quantity = $_REQUEST['available_quantity'];
            $organization_name = $_POST['organization_name'];
             $project_name = $_REQUEST['project_name'];
               $model->maintenance_status = $_POST['maintenance_status']; 
               $model->quantity = $_POST['maintenance_quantity'];
               $model->maintenance_type = $_POST['maintenance_type'];
               $model->maintenance_cost = $_POST['maintenance_cost'];
               $model->maintenance_status = "pending";
               if(isset($_POST['maintenance_description'])){
                    $model->description = $_POST['maintenance_description']; 
               }
               if(isset($_POST['reason_for_maintenance'])){
                    $model->reason_for_maintenance = $_POST['reason_for_maintenance']; 
               }
               $model->is_rejected = 0;
               $model->is_approved = 0;
               $model->is_modification_approved = 0;
               $model->date_last_modified = new CDbExpression('NOW()');
               $model->modified_by_id = Yii::app()->user->id;
                if($model->save()){
                    
                       
                         // $result['success'] = 'true';
                          $msg = "Successfully updated this Project Resource for Maintenance. Approval is pending";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update this Resource for Maintenance was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                       )
                           );
                    } 
            
            
        }
        
        
        
        /**
         * This is the function that approves project resource maintenance
         */
        public function actionapproveProjectResourceMaintenance(){
            
            $_id = $_POST['id'];
            
            $model= AssetInProjectMaintenance::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
            $model->is_approved = 1;
            $model->is_modification_approved = 1; 
            $model->is_rejected = 0;
            $model->is_deleted = 0; 
            $model->maintenance_status = "approved"; 
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project resource maintenance is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project resource maintenance approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        /**
         * This is the function that rejects project resource maintenance
         */
        public function actionrejectProjectResourceMaintenance(){
            
            $_id = $_POST['id'];
            
            $model= AssetInProjectMaintenance::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
           $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_rejected = 1;
            //$model->is_deleted = 1; 
            $model->maintenance_status = "rejected"; 
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project resource maintenance is successfully rejected";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project resource maintenance approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        
        /**
         * This is the function that withdraws project resource maintenance
         */
        public function actionwithdrawProjectResourceMaintenance(){
            
            $_id = $_POST['id'];
            
            $model= AssetInProjectMaintenance::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
          $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_deleted = 1; 
             $model->withdrawn_by_id = Yii::app()->user->id;
             $model->date_withdrawn = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project resource maintenance is successfully withdrawn";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project resource maintenance withdrawal request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
         /**
         * This is the function that unwithdraws project resource maintenance
         */
        public function actionunwithdrawProjectResourceMaintenance(){
            
            $_id = $_POST['id'];
            
            $model= AssetInProjectMaintenance::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
         $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_deleted = 0; 
             $model->withdrawn_by_id = Yii::app()->user->id;
             $model->date_withdrawn = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project resource maintenance is successfully unwithdrawn";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project resource maintenance unwithdrawal request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
}
