<?php

class AssetForProjectController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listprojectallallocatedassets','listallallocatedseriesforthisproductionasset',
                                    'listallallocatedseriesslotforthisproductionasset','listallallocatedseriesslotskuforthisproductionasset',
                                    'listallallocatedseriesslotskuforthisproductionasset','addNewlyInitiatedResourcesForProject','listmodifiedprojectallallocatedassets',
                                    'listunapprovedprojectallallocatedassets','listapprovedprojectallallocatedassets','listwithdrawrequestforprojectallallocatedassets',
                                    'modifyresourcesforproject','approveResourcesForProject','rejectResourcesForProject','withdrawassetallocationtoproject',
                                    'unwithdrawassetallocationtoproject'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all allocated assets for projects
         */
        public function actionlistprojectallallocatedassets(){
            
            $sol_id = $_REQUEST['sol_id'];
            $project_id = $_REQUEST['project_id'];
            
            $data = [];
            $q = "select a.*, b.id as assignment_id, c.id as allocation_id,d.name as warehouse_and_place,
                (select name from project where id=a.project_id) as project,
                (select name from production_assets where id=b.production_asset_id) as production_asset
                from asset_for_project a
                    JOIN asset_in_warehouse_and_place b ON a.asset_assignment_id=b.id
                    JOIN allocate_warehouse_storage_space c ON b.warehouse_and_place_allocation_id=c.id
                    JOIN warehouse_and_place d ON c.warehouse_id=d.id
                     where (c.service_outlet_id =$sol_id and a.project_id=$project_id) and (a.is_approved=0 and a.is_deleted=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        
        
        /**
         * This is the function that list all modified allocated assets for projects
         */
        public function actionlistmodifiedprojectallallocatedassets(){
            
            $sol_id = $_REQUEST['sol_id'];
            $project_id = $_REQUEST['project_id'];
            
            $data = [];
            $q = "select a.*, b.id as assignment_id, c.id as allocation,d.name as warehouse_and_place, b.production_asset_id,
                b.sku, b.quantity_of_assets_in_capacity as available_quantity,
                (select name from project where id=a.project_id) as project,
                (select name from production_assets where id=b.production_asset_id) as production_asset
                from asset_for_project a
                    JOIN asset_in_warehouse_and_place b ON a.asset_assignment_id=b.id
                    JOIN allocate_warehouse_storage_space c ON b.warehouse_and_place_allocation_id=c.id
                    JOIN warehouse_and_place d ON c.warehouse_id=d.id
                     where (c.service_outlet_id =$sol_id and a.project_id=$project_id) and a.is_deleted=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
         /**
         * This is the function that list all unapproved allocated assets for projects
         */
        public function actionlistunapprovedprojectallallocatedassets(){
            
            $sol_id = $_REQUEST['sol_id'];
            $project_id = $_REQUEST['project_id'];
            
            $data = [];
            $q = "select a.*, b.id as assignment_id, c.id as allocation,d.name as warehouse_and_place, b.production_asset_id,
                b.sku, b.quantity_of_assets_in_capacity as available_quantity,
                (select name from project where id=a.project_id) as project,
                (select name from production_assets where id=b.production_asset_id) as production_asset
                from asset_for_project a
                    JOIN asset_in_warehouse_and_place b ON a.asset_assignment_id=b.id
                    JOIN allocate_warehouse_storage_space c ON b.warehouse_and_place_allocation_id=c.id
                    JOIN warehouse_and_place d ON c.warehouse_id=d.id
                     where (c.service_outlet_id =$sol_id and a.project_id=$project_id) and (a.is_approved=0 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        /**
         * This is the function that list all approved allocated assets for projects
         */
        public function actionlistapprovedprojectallallocatedassets(){
            
            $sol_id = $_REQUEST['sol_id'];
            $project_id = $_REQUEST['project_id'];
            
            $data = [];
            $q = "select a.*, b.id as assignment_id, c.id as allocation,d.name as warehouse_and_place, b.production_asset_id,
                b.sku, b.quantity_of_assets_in_capacity as available_quantity,
                (select name from project where id=a.project_id) as project,
                (select name from production_assets where id=b.production_asset_id) as production_asset
                from asset_for_project a
                    JOIN asset_in_warehouse_and_place b ON a.asset_assignment_id=b.id
                    JOIN allocate_warehouse_storage_space c ON b.warehouse_and_place_allocation_id=c.id
                    JOIN warehouse_and_place d ON c.warehouse_id=d.id
                     where (c.service_outlet_id =$sol_id and a.project_id=$project_id) and (a.is_approved=1 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        
        /**
         * This is the function that list all approved allocated assets for projects
         */
        public function actionlistwithdrawrequestforprojectallallocatedassets(){
            
            $sol_id = $_REQUEST['sol_id'];
            $project_id = $_REQUEST['project_id'];
            
            $data = [];
            $q = "select a.*, b.id as assignment_id, c.id as allocation,d.name as warehouse_and_place, b.production_asset_id,
                b.sku, b.quantity_of_assets_in_capacity as available_quantity,
                (select name from project where id=a.project_id) as project,
                (select name from production_assets where id=b.production_asset_id) as production_asset
                from asset_for_project a
                    JOIN asset_in_warehouse_and_place b ON a.asset_assignment_id=b.id
                    JOIN allocate_warehouse_storage_space c ON b.warehouse_and_place_allocation_id=c.id
                    JOIN warehouse_and_place d ON c.warehouse_id=d.id
                     where (c.service_outlet_id =$sol_id and a.project_id=$project_id) and (a.is_approved=0 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
       
        
        
         /**
         * This is the function that list all series of an asset type for a service outlet
         **/
        public function actionlistallallocatedseriesforthisproductionasset(){
            
            //$asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
           $allocation_id=$_REQUEST['allocation_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                        a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet, a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                       where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                       where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON c.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,  a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset_slot d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                      a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON c.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                         a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                          a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                       a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where d.sol_id =$sol_id and (b.warehouse_and_place_allocation_id = $allocation_id and b.production_asset_id = $production_asset_id)  and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
        /**
         * This is the function that list all series slots of an asset type for a service outlet
         **/
        public function actionlistallallocatedseriesslotforthisproductionasset(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
           $allocation_id =$_REQUEST['allocation_id'];
           
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                        a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet, a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON c.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,  a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset_slot d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                      a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON c.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                         a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                          a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                       a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where b.warehouse_and_place_allocation_id = $allocation_id and (b.is_approved=1 and b.is_deleted=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
         /**
         * This is the function that retrieve the stock units in a warehouse and place for a production asset type, asset series and slot
         */
        public function actionlistallallocatedseriesslotskuforthisproductionasset(){
            
           $data= [];
           $warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
           $sol_id = $_REQUEST['sol_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
           $series_id = $_REQUEST['series_id'];
           $slot_id = $_REQUEST['slot_id'];
           $allocation_id = $_REQUEST['allocation_id'];
            
            $q = "select  b.*             
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         where (a.service_outlet_id =$sol_id and b.is_approved=1) and a.id=$allocation_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "sku"=>$data,
                                  
                            ));
        }
        
        
        /**
         * This is the function that add newly initiated resoiurces to a project
         */
        
        public function actionaddNewlyInitiatedResourcesForProject(){
            $model = new AssetForProject;
            
            $model->project_id = $_POST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $available_quantity = $_REQUEST['available_quantity'];
           $model->asset_assignment_id = $_POST['assignment_id'];
             $organization_name = $_POST['organization_name'];
             $project_name = $_REQUEST['project_name'];
               $model->status = $_POST['status']; 
               $model->quantity = $_POST['quantity'];
               
               //get the next ptoject incrementer value
               
               $model->incrementer = $model->getTheCurrentIncrementedNumber() + 1;
               $model->allocation_ref_code = $model->getTheResourceAllocationRefForThisProject($model->project_id,$sol_id, $model->incrementer);      
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->date_allocated = new CDbExpression('NOW()');
                $model->allocation_user_id = Yii::app()->user->id;
                if($model->save()){
                    
                        //reduce the number of assets in the warehouse & place
                        $this->updateItemQuantityInWarehouseAndPlace($model->asset_assignment_id,$model->quantity,$available_quantity);
                         // $result['success'] = 'true';
                          $msg = "Successfully added  some asset resources to the '$project_name' project";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add some asset resources to the '$project_name' project was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                       )
                           );
                    } 
            
            
        }
        
        
        
        
         /**
         * This is the function that modifies initiated resoiurces to a project
         */
        
        public function actionModifyResourcesForProject(){
             $_id = $_POST['id'];
            $model= AssetForProject::model()->findByPk($_id);
            
            $model->project_id = $_POST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $available_quantity = $_REQUEST['available_quantity'];
            $adjusted_available_quantity = (double)$available_quantity + (double)$_REQUEST['original_requested_quantity'];
           $model->asset_assignment_id = $_POST['asset_assignment_id'];
             $organization_name = $_POST['organization_name'];
             $project_name = $_REQUEST['project_name'];
               $model->status = $_POST['status']; 
               $model->quantity = $_POST['quantity'];
               $model->is_rejected = 0;
               $model->is_approved = 0;
               $model->is_modification_approved = 0;
               
               //get the next ptoject incrementer value
               
               //$model->incrementer = $model->getTheCurrentIncrementedNumber() + 1;
              // $model->allocation_ref_code = $model->getTheResourceAllocationRefForThisProject($model->project_id,$sol_id, $model->incrementer);      
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->date_allocated = new CDbExpression('NOW()');
                $model->allocation_user_id = Yii::app()->user->id;
                if($model->save()){
                    
                        //reduce the number of assets in the warehouse & place
                        $this->updateItemQuantityInWarehouseAndPlace($model->asset_assignment_id,$model->quantity,$adjusted_available_quantity);
                         // $result['success'] = 'true';
                          $msg = "Successfully updated  some asset resources to the '$project_name' project";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update some asset resources to the '$project_name' project was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                       )
                           );
                    } 
            
            
        }
        
        
        /**
         * This is the function that reduces the quantity of asset slots in a warehouse and place after allocating to a project
         */
        public function updateItemQuantityInWarehouseAndPlace($asset_assignment_id,$quantity,$available_quantity){
            $model = new AssetInWarehouseAndPlace;
            return $model->updateItemQuantityInWarehouseAndPlace($asset_assignment_id,$quantity,$available_quantity);
        }
        
        
        
        
        /**
         * This is the function that approves asset allocation to project
         */
        public function actionapproveResourcesForProject(){
            
            $_id = $_POST['id'];
            
            $model= AssetForProject::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
            $model->is_approved = 1;
            $model->is_modification_approved = 1; 
            $model->is_rejected = 0;
            $model->is_deleted = 0; 
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The allocation of assets to the  '$project' project is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        /**
         * This is the function that rejects asset allocation to project
         */
        public function actionrejectResourcesForProject (){
            
            $_id = $_POST['id'];
            
            $model= AssetForProject::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
            $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_rejected = 1;
            //$model->is_deleted = 1; 
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The allocation of assets to the  '$project' project is rejected";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'rejection request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        
        /**
         * This is the function that withdraws  asset allocation to project request
         */
        public function actionwithdrawassetallocationtoproject(){
            
            $_id = $_POST['id'];
            
            $model= AssetForProject::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
            $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_deleted = 1; 
             $model->withdrawn_by_id = Yii::app()->user->id;
             $model->date_withdrawn = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The allocation of assets to the  '$project' project request is withdrawn";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'withdrawal request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        /**
         * This is the function that unwithdraws  asset allocation to project request
         */
        public function actionunwithdrawassetallocationtoproject(){
            
            $_id = $_POST['id'];
            
            $model= AssetForProject::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
            $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_deleted = 0; 
             $model->withdrawn_by_id = Yii::app()->user->id;
             $model->date_withdrawn = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The allocation of assets to the  '$project' project request is unwithdrawn";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'unwithdrawal request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
}
