<?php

class MaintenanceForWarehouseAndPlaceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','effectmaintenanceonwarehouseandplace','listthissolallocatedwarehousesandplacesmaintainances',
                                    'listthissolallocatedwarehousesandplacesmaintainances','listthissolallocatedwarehousesandplacesapprovedmaintainances',
                                    'approvewarehouseandplacemaintenance'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that effect maintenance on  a warehouse or place
         */
        public function actioneffectmaintenanceonwarehouseandplace(){
            $model = new MaintenanceForWarehouseAndPlace;
            
            $name = $_POST['warehouse_and_place'];
            $service_outlet_id = $_POST['sol_id'];
            $organization_id = $_POST['organization_id'];
            $model->warehouse_and_place_allocation_id = $_POST['allocation_id'];
            
            //get the warehouse and place id of this allocation
            $warehouse_id = $this->getTheWarehouseAndPlaceOfThisAllocation($model->warehouse_and_place_allocation_id);
            
            if($this->isThisWarehouseAndPlaceAllocated($warehouse_id,$service_outlet_id)){
                $model->maintenance_status = "pending";
             if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
               if(isset($_POST['reason_for_maintenance'])){
                    $model->reason_for_maintenance = $_POST['reason_for_maintenance']; 
               }
                $model->maintenance_type = $_POST['maintenance_type'];
                $model->maintenance_cost = $_POST['maintenance_cost'];
                $model->is_approved = 0;
                $model->date_initiated = new CDbExpression('NOW()');
                $model->initiated_by_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully effected maintenance on the  '$name' Warehouse or Place ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to effect maintenance on his warehouse or place  was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                
            }else{
                 $msg = "This maintenance could not be effected as this Warehouse or Place is yet to be allocated to this service unit";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                
            }
            
     
        }
        
        
        
        /**
         * This is the function that gets the warehouse and place id of an allocation
         * 
         */
        public function getTheWarehouseAndPlaceOfThisAllocation($allocation_id){
            $model = new AllocateWarehouseStorageSpace;
            return $model->getTheWarehouseAndPlaceOfThisAllocation($allocation_id);
            
        }
        
        /**
         * This is the function that confirms if a warehouse or place is allocated
         */
        public function isThisWarehouseAndPlaceAllocated($warehouse_and_place_id,$service_outlet_id){
            $model = new MaintenanceForWarehouseAndPlace;
            return $model->isThisWarehouseAndPlaceAllocated($warehouse_and_place_id,$service_outlet_id);
        }
        
        
        /**
         * This is the function that list all unapproved warehouse and place maintenance
         */
        public function actionlistthissolallocatedwarehousesandplacesmaintainances(){
            
            $organization_id = $_REQUEST['organization_id'];
            $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.allocated_storage_capacity_in_cubic_feet as allocated_capacity, b.allocation_status as current_allocation_status, 
                c.name as warehouse_and_place, c.type as warehouse_type,c.remaining_storage_capacity_in_cubic_feet as remaining_storage_capacity_in_cubic_feet,
                c.is_for_storage as is_for_storage,e.name as owner_organization_name, e.id as owner_organization_id,
                (select name from organization where id = b.organization_id) as warehouse_owner_organization,
                (select name from user where id=a.initiated_by_id) as requester,
                (select name from service_outlet where id=b.service_outlet_id)as warehouse_owner_service_outlet
                from maintenance_for_warehouse_and_place a
                    JOIN allocate_warehouse_storage_space b ON a.warehouse_and_place_allocation_id=b.id
                    JOIN warehouse_and_place c ON b.warehouse_id=c.id
                    JOIN location d ON c.location_id=d.id
                    JOIN organization e ON d.organization_id=e.id
                    where (a.is_approved = 0 and b.service_outlet_id=$sol_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "allocated"=>$data,
                                  
                            ));
            
            
            
        }
        
        
        
        
        /**
         * This is the function that list all unapproved warehouse and place maintenance
         */
        public function actionlistthissolallocatedwarehousesandplacesapprovedmaintainances(){
            
            $organization_id = $_REQUEST['organization_id'];
            $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.allocated_storage_capacity_in_cubic_feet as allocated_capacity, b.allocation_status as current_allocation_status, 
                c.name as warehouse_and_place, c.type as warehouse_type,c.remaining_storage_capacity_in_cubic_feet as remaining_storage_capacity_in_cubic_feet,
                c.is_for_storage as is_for_storage,e.name as owner_organization_name, e.id as owner_organization_id,
                (select name from organization where id = b.organization_id) as warehouse_owner_organization,
                (select name from user where id=a.initiated_by_id) as requester,
                (select name from service_outlet where id=b.service_outlet_id)as warehouse_owner_service_outlet
                from maintenance_for_warehouse_and_place a
                    JOIN allocate_warehouse_storage_space b ON a.warehouse_and_place_allocation_id=b.id
                    JOIN warehouse_and_place c ON b.warehouse_id=c.id
                    JOIN location d ON c.location_id=d.id
                    JOIN organization e ON d.organization_id=e.id
                    where (a.is_approved = 1 and b.service_outlet_id=$sol_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "allocated"=>$data,
                                  
                            ));
            
            
            
        }
        
        
        
        /**
         * This is the function that approves a warehouse and place maintenance
         */
        public function actionapprovewarehouseandplacemaintenance(){
            
            $_id = $_POST['id'];
            $model= MaintenanceForWarehouseAndPlace::model()->findByPk($_id);
            
            $name = $_POST['warehouse_and_place'];
                      
             $model->is_approved = 1; 
             $model->maintenance_status = "approved"; 
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "This '$name' Warehouse or Place maintenance is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
}
