<?php

class ProjectController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listserviceoutletallprojects','addnewproject','listserviceoutletallmodifiedprojects',
                                    'listserviceoutletallunapprovedprojects','listserviceoutletallapprovedprojects','modifyproject','approvenewproject',
                                    'retrievedetailsofthisproject'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
         * this is the function that list all newly initiated projects
         */
        public function actionlistserviceoutletallprojects(){
            
             $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as service_outlet from project a
                    JOIN service_outlet b ON a.service_outlet_id=b.id
                     where (b.id =$sol_id and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        /**
         * this is the function that list all modifieda initiated projects
         */
        public function actionlistserviceoutletallmodifiedprojects(){
            
             $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as service_outlet from project a
                    JOIN service_outlet b ON a.service_outlet_id=b.id
                     where (b.id =$sol_id and a.is_modification_approved=0) and (a.is_deleted=0 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        
        /**
         * this is the function that list all unapproved projects
         */
        public function actionlistserviceoutletallunapprovedprojects(){
            
             $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as service_outlet from project a
                    JOIN service_outlet b ON a.service_outlet_id=b.id
                     where (b.id =$sol_id and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        
        /**
         * this is the function that list all approved projects
         */
        public function actionlistserviceoutletallapprovedprojects(){
            
             $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as service_outlet from project a
                    JOIN service_outlet b ON a.service_outlet_id=b.id
                     where (b.id =$sol_id and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
            
        }
        
        
       
        
        /**
         * This the function taht creates new projects
         */
        public function actionaddnewproject(){
            
            $model = new Project;
            
            $model->service_outlet_id = $_POST['sol_id'];
            $model->name = $_POST['name'];
           $model->description = $_POST['description'];
           $model->objective = $_POST['objective']; 
           $model->duration = $_POST['duration']; 
           $model->sponsor = $_POST['sponsor'];
           $model->project_manager = $_POST['project_manager']; 
           $model->allocated_budget = $_POST['allocated_budget']; 
           if(isset($_REQUEST['project_gl_id'])){
               $model->project_gl_id=$_REQUEST['project_gl_id'];
           }else{
               $model->project_gl_id = NULL;
           }
           $model->commencement_date = date("Y-m-d H:i:s", strtotime($_POST['commencement_date']));
              $model->date_created = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully created the  '$model->name' project";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to create the '$model->name' project was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
           
            
        }
        
        
        
         /**
         * This the function that modifies project
         */
        public function actionmodifyproject(){
            
            $_id = $_POST['id'];
           $model= Project::model()->findByPk($_id);
            
            $model->service_outlet_id = $_POST['sol_id'];
            $model->name = $_POST['name'];
           $model->description = $_POST['description'];
           $model->objective = $_POST['objective']; 
           $model->duration = $_POST['duration']; 
           $model->sponsor = $_POST['sponsor'];
           $model->project_manager = $_POST['project_manager']; 
           $model->allocated_budget = $_POST['allocated_budget']; 
           if(isset($_REQUEST['project_gl_id'])){
               $model->project_gl_id=$_REQUEST['project_gl_id'];
           }else{
               $model->project_gl_id = NULL;
           }
           $model->commencement_date = date("Y-m-d H:i:s", strtotime($_POST['commencement_date']));
           $model->is_rejected=0; 
           $model->is_approved=0;
           $model->is_modification_approved=0; 
              $model->date_updated = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully updated the  '$model->name' project";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update the '$model->name' project was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
           
            
        }
        
        
        
        /**
         * This is the function that approves a project
         */
        public function actionapprovenewproject(){
            
            $_id = $_POST['id'];
            $model= Project::model()->findByPk($_id);
            
                      
             $model->is_approved = 1;  
             $model->is_modification_approved=0; 
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' project is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'This approval request is unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        /**
         * This is the function that rejects a project creation request
         */
        public function actionrejectnewproject(){
            
            $_id = $_POST['id'];
            $model= Project::model()->findByPk($_id);
            
                      
             $model->is_approved = 0; 
             $model->is_rejected = 0;
             $model->is_modification_approved = 0;  
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' project is successfully rejected";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'This reject request is unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        /**
         * This is the function that retrieves the details of a project
         */
        public function actionretrievedetailsofthisproject(){
            
            $project_id = $_REQUEST['project_id'];
            
            $data = [];
            $q = "select a.*, b.name as service_outlet from project a
                    JOIN service_outlet b ON a.service_outlet_id=b.id
                     where a.id =$project_id 
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
        }
        
}
