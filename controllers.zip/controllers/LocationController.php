<?php

class LocationController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','deleteonelocation','listOrganizationlocations','addanewlocation','modifylocation'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all organization locations
         */
        public function actionlistOrganizationlocations(){
            
            $organization_id = $_REQUEST['organization_id'];
         
                   
            $data = [];
            $q = "select a.*, b.id as organization_id, b.name as organization_name,
                (select name from city where id=a.city_id) as city_name,
                (select state_id from city where id=a.city_id) as state_id,
                (select name from state where id=(select state_id from city where id=a.city_id)) as state_name,
                (select country_id from state where id=(select state_id from city where id=a.city_id)) as country_id,
                (select name from country where id=(select country_id from state where id=(select state_id from city where id=a.city_id))) as country_name
                from location a
                    JOIN organization b ON a.organization_id=b.id
                     where a.organization_id =$organization_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "location"=>$data,
                                  
                            ));
            
        }
        
        
        /**
      * This is the function that add new Location for an organization
      */
     public function actionaddanewlocation(){
         
         $model = new Location;
            
             $model->organization_id = $_POST['organization_id'];
             $model->city_id = $_POST['city_id'];
             $organization_name = $_POST['organization_name'];
            
               $model->name = $_POST['name']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  '$model->name' location to the '$organization_name' organization";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this location to the '$organization_name' was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
         
     }
     
     
     
     /**
         * This is the function that modifies a division
         */
        public function actionmodifylocation(){
            
            $_id = $_POST['id'];
            
            $model= Location::model()->findByPk($_id);
            $model->name = $_POST['name'];
            $model->city_id = $_POST['city_id'];
            $model->organization_id = $_POST['organization_id'];
              if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated this Location';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The update of this Location was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
            
        }
        
        
         /**
         * This is the function that deletes a Location
         */
        public function actiondeleteonelocation(){
            
            $_id = $_POST['id'];
            $model= Location::model()->findByPk($_id);
            
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' location is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
            
        }
}
