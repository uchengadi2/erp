<?php

class AssetForDispositionController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listserviceoutletallinitiatedsassetdispositions','listserviceoutletallmodifiedsassetdispositions',
                                    'listserviceoutletallUnapprovedsassetdispositions','listserviceoutletallApprovedsassetdispositions','listserviceoutletallforwithdrawalsassetdispositions',
                                    'unwithdrawassetdisposition','withdrawassetdisposition','rejectassetdisposition','approveassetdisposition','modifyassetdispositionrequest','placeassetdispositionrequest'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	 /**
         * This is the function that list all disposition of asset in a warehouse or place
         **/
        public function actionlistserviceoutletallinitiatedsassetdispositions(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.billboard_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.street_pole_batch_id =$asset_series_id and b.service_outlet_id =$sol_id)  and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_property_asset_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_walldrop_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_sds_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.charcoal_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.inventory_livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.commodity_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.plantation_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                       (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and b.production_asset_id=$production_asset_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
        
        
        /**
         * This is the function that list all modified disposition for asset slots that are warehoused or placed 
         **/
        public function actionlistserviceoutletallmodifiedsassetdispositions(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.billboard_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.street_pole_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_property_asset_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_walldrop_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_sds_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.charcoal_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.inventory_livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                       (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.commodity_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     a.measurement_unit as measurement_unit,a.is_approved as is_requisition_approved,a.description as description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.plantation_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
        
            
        /**
         * This is the function that list all unapproved disposition for asset slots that are warehoused or placed 
         **/
        public function actionlistserviceoutletallunapprovedsassetdispositions(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.billboard_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.street_pole_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_property_asset_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_walldrop_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_sds_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.charcoal_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.inventory_livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.commodity_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.plantation_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                       b.warehouse_id as warehouse_and_place_id, a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
        
        
        
        
        
        
        
         
            
        /**
         * This is the function that list all unapproved disposition for asset slots that are warehoused or placed 
         **/
        public function actionlistserviceoutletallApprovedsassetdispositions(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.billboard_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.street_pole_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_property_asset_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_walldrop_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_sds_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.charcoal_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.inventory_livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.commodity_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                       b.warehouse_id as warehouse_and_place_id, a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.plantation_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=1) and (a.is_deleted=0 and a.is_rejected=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        /**
         * This is the function that places asset disposition
         */
        public function actionplaceassetdispositionrequest(){
            $model = new AssetForDisposition;
            
                    
           $requested_quantity = (double)$_POST['quantity'];
           $quantity_in_stockt = (double)$_POST['sku_quantity_of_assets_in_capacity'];
           $warehouse_and_place = $_POST['warehouse_and_place'];
          $slot_code = $_POST['slot_code'];
            if($requested_quantity<=$quantity_in_stockt){
               $model->asset_in_warehouse_and_place_id = $_POST['sku_assignment_id'];
                 $model->disposition_method = $_POST['disposition_method'];
                $model->reason_for_disposition = $_POST['reason_for_disposition'];
                $model->quantity = $_POST['quantity']; 
                $model->measurement_unit = $_POST['measurement_unit'];
                $model->disposition_status="pending";
               
                if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              
              $model->date_initiated = new CDbExpression('NOW()');
                $model->initiated_by_id = Yii::app()->user->id;
                if($model->save()){
                    //update the items in a slot table
                    $this->updateItemQuantityInWarehouseAndPlace($model->asset_in_warehouse_and_place_id,$requested_quantity,$quantity_in_stockt);
                    
                        // $result['success'] = 'true';
                          $msg = "Your request for the disposition of  '$model->quantity'  $model->measurement_unit  of the $slot_code  slot items is successful but awaiting approval";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to dispose some or all items of the $slot_code slot from '$warehouse_and_place' warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
               
               
           }else{
               //$result['success'] = 'false';
                         $msg = "You cannot request for the disposition of  more assets than is available in this warehouse and place. Please amend your request and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
               
           }
               
    
            
        }
        
        
            
        
         /**
         * This is the function that modifies  asset disposition
         */
        public function actionmodifyassetdispositionrequest(){
            
            $_id = $_REQUEST['disposition_id'];
            $model= AssetForDisposition::model()->findByPk($_id);
            
            $original_quantity = (double)$_POST['original_quantity'];
            $requested_quantity = (double)$_POST['quantity'];
            $diff = $original_quantity - $requested_quantity;
            
            if($original_quantity == $requested_quantity){
                $quantity_in_stock = (double)$_POST['sku_quantity_of_assets_in_capacity'];
                $warehouse_and_place = $_POST['warehouse_and_place'];
                $slot_code = $_POST['slot_code'];
            // if($requested_quantity<=$quantity_in_stock){
               $model->asset_in_warehouse_and_place_id = $_POST['sku_assignment_id'];
                 $model->disposition_method = $_POST['disposition_method'];
                $model->reason_for_disposition = $_POST['reason_for_disposition'];
                $model->quantity = $_POST['quantity']; 
                $model->measurement_unit = $_POST['measurement_unit'];
                $model->disposition_status="pending";
                $model->is_rejected=0;
               
                if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              
              $model->date_initiated = new CDbExpression('NOW()');
                $model->initiated_by_id = Yii::app()->user->id;
                if($model->save()){
                    //update the items in a slot table
                    //$this->updateItemQuantityInWarehouseAndPlace($model->asset_in_warehouse_and_place_id,$requested_quantity,$quantity_in_stock);
                    
                        // $result['success'] = 'true';
                          $msg = "Your request for the disposition of  '$model->quantity'  $model->measurement_unit  of the $slot_code  slot items is successful updated but awaiting approval";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update the disposition request of some or all items of the $slot_code slot from '$warehouse_and_place' warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
               
               
         /**  }else{
               //$result['success'] = 'false';
                         $msg = "You cannot request for more asset than is available in this warehouse and place. Please amend your request and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
               
           }
          * 
          */
                
                
                
            }else{
               
                $quantity_in_stock = (double)$_POST['sku_quantity_of_assets_in_capacity'];
                $warehouse_and_place = $_POST['warehouse_and_place'];
                $slot_code = $_POST['slot_code'];
                //$new_requested_quantity = $requested_quantity - $original_quantity;
                $actual_quantity_in_stock = $quantity_in_stock + $original_quantity;
                
             if($requested_quantity<=$actual_quantity_in_stock){
               $model->asset_in_warehouse_and_place_id = $_POST['sku_assignment_id'];
                 $model->disposition_method = $_POST['disposition_method'];
                $model->reason_for_disposition = $_POST['reason_for_disposition'];
                $model->quantity = $_POST['quantity']; 
                $model->measurement_unit = $_POST['measurement_unit'];
                $model->disposition_status="pending";
                $model->is_rejected=0;
               
                if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              
              $model->date_initiated = new CDbExpression('NOW()');
                $model->initiated_by_id = Yii::app()->user->id;
                if($model->save()){
                    //update the items in a slot table
                    $this->updateItemQuantityInWarehouseAndPlace($model->asset_in_warehouse_and_place_id,$requested_quantity,$actual_quantity_in_stock);
                    
                        // $result['success'] = 'true';
                          $msg = "Your request for the disposition of  '$model->quantity'  $model->measurement_unit  of the $slot_code  slot items is successful updated but awaiting approval";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update the disposition of some or all items of the $slot_code slot from '$warehouse_and_place' warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
               
               
           }else{
               //$result['success'] = 'false';
                         $msg = "You cannot request for the disposition of  more assets than is available in this warehouse and place. Please amend your request and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
               
           }
                
                
            }
        
           
               
    
            
        }
        
        
        /**
         * this is the function that updates the stock quantity assigned to a warehouse
         */
        public function updateItemQuantityInWarehouseAndPlace($asset_in_warehouse_and_place_id,$requested_quantity,$quantity_in_stockt){
            $model = new AssetInWarehouseAndPlace;
            return $model->updateItemQuantityInWarehouseAndPlace($asset_in_warehouse_and_place_id,$requested_quantity,$quantity_in_stockt);
            
        }
        
        
        
        /**
         * This is the function that approves asset disposition
         */
        public function actionapproveassetdisposition(){
            
            $_id = $_POST['disposition_id'];
           $model= AssetForDisposition::model()->findByPk($_id);
            
            $model->is_approved = 1; 
            $model->is_rejected = 0;
            $model->is_deleted = 0; 
            $model->is_modification_approved = 1;
            $model->disposition_status = "approved";
             $model->approved_by_id = Yii::app()->user->id;
            $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "This asset disposition request is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        /**
         * This is the function that rejects asset disposition
         */
        public function actionrejectassetdisposition(){
            
            $_id = $_POST['disposition_id'];
           $model= AssetForDisposition::model()->findByPk($_id);
            
            $model->is_approved = 0;
            $model->is_approved = 0;
            $model->is_rejected = 1;
            $model->is_modification_approved = 1;
             $model->disposition_status = "rejected";
            $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The disposition request  of this item is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'rejection request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
         /**
         * This is the function that withdraws asset disposition
         */
        public function actionwithdrawassetdisposition(){
            
            $_id = $_POST['disposition_id'];
           $model= AssetForDisposition::model()->findByPk($_id);
            
            $model->is_approved = 0; 
            $model->is_rejected = 0;
            $model->is_deleted = 1; 
            $model->is_modification_approved = 0;
            $model->disposition_status = "pending";
             $model->approved_by_id = Yii::app()->user->id;
            $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The withdrawal request of this item is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        
        /**
         * This is the function that unwithdraws asset disposition
         */
        public function actionunwithdrawassetdisposition(){
            
            $_id = $_POST['disposition_id'];
           $model= AssetForDisposition::model()->findByPk($_id);
            
            $model->is_approved = 0; 
            $model->is_rejected = 0;
            $model->is_deleted = 0; 
            $model->is_modification_approved = 0;
            $model->disposition_status = "pending";
             $model->approved_by_id = Yii::app()->user->id;
            $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The disposition request  of this asset is successfully unwithdrawn";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
          
        
        
        /**
         * This is the function that list all disposition for asset slots that are warehoused or placed 
         **/
        public function actionlistserviceoutletallforwithdrawalsassetdispositions(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.billboard_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.street_pole_batch_id =$asset_series_id and b.service_outlet_id =$sol_id)  and (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_property_asset_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_walldrop_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_sds_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.charcoal_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.inventory_livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.commodity_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.plantation_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,b.id as assignment_id,a.id as id,a.id as disposition_id,a.disposition_method as disposition_method,a.reason_for_disposition as reason_for_disposition,a.quantity as quantity,
                        b.warehouse_id as warehouse_and_place_id,a.measurement_unit as measurement_unit,a.is_approved as is_disposition_approved,a.description as description,a.disposition_status as disposition_status,a.is_deleted as is_disposed_item_deleted,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select type from warehouse_and_place where id = b.warehouse_id) as type,
                         (select name from warehouse_and_place where id =  b.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id =  b.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id =  b.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select used_allocated_storage_capacity_in_cubic_feet from allocate_warehouse_storage_space where id=b.warehouse_and_place_allocation_id) as used_allocated_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id= b.warehouse_id)) as location
                         from asset_for_disposition a
                         JOIN asset_in_warehouse_and_place b ON a.asset_in_warehouse_and_place_id=b.id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=1 and a.is_approved=0) and b.production_asset_id=$production_asset_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
}
