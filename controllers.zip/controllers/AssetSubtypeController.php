<?php

class AssetSubtypeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listThisAssetAllSubTypes','addnewAssetSubType','modifyAssetSubType','deletethisAssetSubtype',
                                    'listAllAssetAllSubTypes'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all asset subtypes of an asset
         */
        public function actionlistThisAssetAllSubTypes(){
            
            $asset_type_id = $_REQUEST['assettype_id'];
         
                   
            $data = [];
            $q = "select a.*, b.id as asset_type_id, b.name as assettype_name, b.code as assettype_code  from `asset_subtype` a
                    JOIN asset_type b ON a.asset_type_id=b.id
                     where a.asset_type_id =$asset_type_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "type"=>$data,
                                  
                            ));
            
        }
        
        
        /**
         * This is the function that adds a new subtype to an Asset Type
         */
        public function actionaddnewAssetSubType(){
            
            $model = new AssetSubtype;
            
            $model->name = $_POST['name'];
            $model->asset_type_id = $_POST['asset_type_id']; 
             $model->code = $_POST['code']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                
                if($model->isAssetSubTypeCodeExist($model->code)== false){
                    if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  the '$model->name' asset subtype to th selected Asset Type";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this '$model->name'  asset subtype was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                    
                }else{
                     $msg = "This asset sybtype code is already created and cannot be duplicated";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    
                }
            
            
        }
        
        
        
        
         /**
         * This is the function that modifies an Asset SubType
         */
        public function actionmodifyAssetSubType(){
            
            $_id = $_POST['id'];
            
            $model= AssetSubtype::model()->findByPk($_id);
            
            $model->name = $_POST['name']; 
             $model->code = $_POST['code']; 
             $model->asset_type_id = $_POST['asset_type_id']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully modified  the '$model->name' asset subtype";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to modify this '$model->name'  asset subtype was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
            
        }
        
        
        
         /**
         * This is the function that deletes an Asset SubType
         */
        public function actiondeletethisAssetSubtype(){
            
            $_id = $_POST['id'];
            $model= AssetSubtype::model()->findByPk($_id);
            
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' Asset SubType is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
            
        }
        
        
        /**
         * This is the function that list all asset subtypes
         */
        public function actionlistAllAssetAllSubTypes(){
            
            $assettype= AssetSubtype::model()->findAll();
                if($assettype===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "type" => $assettype,
                                   
                    
                            ));
                       
                }
            
        }
        
}
