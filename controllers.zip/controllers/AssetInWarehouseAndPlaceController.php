<?php

class AssetInWarehouseAndPlaceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listserviceoutletwarehousedandplacedassetslots','addassetslotstoplaceorwarehouse',
                                    'listserviceoutletmodifiedwarehousedandplacedassetslots','listserviceoutletunapprovedwarehousedandplacedassetslots',
                                    'listserviceoutletallapprovedwarehousedandplacedassetslots','modifyassetslotsinplaceorwarehouse','rejectassetslotsinplaceorwarehouse',
                                    'approveassetslotsinplaceorwarehouse','gettheavailablestocksinthiswarehouseandplace','getthedetailsofthissku','listallallocatedseriesforthisproductionasset',
                                    'listallallocatedseriesslotskuforthisproductionasset'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all series assets slots that are warehoused or placed 
         **/
        public function actionlistserviceoutletwarehousedandplacedassetslots(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                        a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.billboard_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.street_pole_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_property_asset_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_walldrop_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

                                
            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_sds_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.charcoal_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.inventory_livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,  a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.commodity_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.plantation_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                      a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                         a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                          a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                       a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and  (b.is_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
        
        
        
        /**
         * This is the function that list all series assets modified slots that are warehoused or placed 
         **/
        public function actionlistserviceoutletmodifiedwarehousedandplacedassetslots(){
            
           $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                        a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet, a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.billboard_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet, a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.street_pole_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_property_asset_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_walldrop_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_sds_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.charcoal_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.inventory_livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,  a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.commodity_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.plantation_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                      a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                         a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                          a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                       a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_modification_approved=0 and b.production_asset_id=$production_asset_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
        
         /**
         * This is the function that list all series assets unapproved slots that are warehoused or placed 
         **/
        public function actionlistserviceoutletunapprovedwarehousedandplacedassetslots(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                        a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet, a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.billboard_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.street_pole_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_property_asset_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_walldrop_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_sds_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.charcoal_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.inventory_livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,  a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.commodity_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.plantation_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                      a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                         a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                          a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                       a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=0 and b.production_asset_id=$production_asset_id) and (b.is_deleted=0 and b.is_rejected=0)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
        
        
           /**
         * This is the function that list all series assets unapproved slots that are warehoused or placed 
         **/
        public function actionlistserviceoutletallapprovedwarehousedandplacedassetslots(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $sol_id = $_REQUEST['sol_id'];
            //$slot_id = $_REQUEST['slot_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                        a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet, a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                        c.id as slot_id,c.series_slot_name as slot_name, c.billboard_unique_number as slot_unique_number,c.number_of_billboards as number_of_items_in_slot,
                        c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.billboard_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                        JOIN imagineplace_billboard_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batch_billboard_asset d ON c.billboard_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.billboard_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.name as slot_name, c.street_pole_slot_unique_number as slot_unique_number,c.number_of_poles as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.batched_street_pole_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_street_pole_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_street_pole_asset d ON c.street_pole_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.street_pole_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.advert_property_unique_number as slot_unique_number,c.quantity as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.batch_series_name as series_name, d.advert_batch_property_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_advert_property_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_advert_batch_property_asset d ON c.batch_property_asset_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_property_asset_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0)and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.walldrop_unique_number as slot_unique_number,c.number_of_walldrop as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batched_walldrop_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_walldrop_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_walldrop_asset_series d ON c.batch_walldrop_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_walldrop_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0)and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.series_slot_name as slot_name, c.sds_unique_number as slot_unique_number,c.number_of_sds as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.batch_sds_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN imagineplace_sds_asset_slot c ON b.slot_id=c.id
                        JOIN imagineplace_batched_sds_asset d ON c.batch_sds_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.batch_sds_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.charcoal_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.charcoal_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_charcoal_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batch_charcoal_asset d ON c.charcoal_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.charcoal_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.inventory_livestock_unique_number as slot_unique_number,c.number_of_inventory_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.inventory_batch_livestock_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_inventory_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_inventory_batched_livestock_asset d ON c.inventory_livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.inventory_livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select b.*,  a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.livestock_unique_number as slot_unique_number,c.number_of_livestock as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.livestock_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_livestock_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_livestock_asset d ON c.livestock_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.livestock_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.commodity_unique_number as slot_unique_number,c.quantity_in_kg as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.commodity_batch_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_commodity_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_batched_commodity_asset d ON c.commodity_batch_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.commodity_batch_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_plants as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.plantation_acquisition_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN agrant_property_plantation_asset_slot c ON b.slot_id=c.id
                        JOIN agrant_property_plantation_asset d ON c.plantation_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.plantation_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                  a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                  c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                  c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_building_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_building_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                    a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                    c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                    c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_entertainment_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_entertainment_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                  $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                      a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                      c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                      c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_car_park_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_car_park_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
                                
                                
            }else if($asset_subtype_code == "airport") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, d.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_airport_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_airport_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                         a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                         c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                         c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                         (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_machinery_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_machinery_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                      $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                          a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                          c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                          c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_shoppingmail_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_shoppingmail_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                   $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                       a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                       c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                       c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_transport_station_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_transport_station_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                 $q = "select b.*, a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                     a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                     c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_sections as number_of_items_in_slot,
                     c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, c.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_complex_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_complex_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

               $q = "select b.*,a.id as allocation_id, a.allocated_storage_capacity_in_cubic_feet as total_allocated_storage_capacity_in_cubic_feet,
                   a.used_allocated_storage_capacity_in_cubic_feet as used_allocated_storage_capacity_in_cubic_feet,a.allocation_duration_in_weeks as allocation_duration_in_weeks,a.description as warehouse_description,
                   c.id as slot_id,c.slot_name as slot_name, c.slot_unique_number as slot_unique_number,c.number_of_stocks as number_of_items_in_slot,
                   c.quantity_of_assets_in_place_or_warehouse as quantity_of_assets_in_place_or_warehouse,c.short_description as slot_description,
                         d.id as series_id, d.asset_series_name as series_name, d.series_unique_number as series_unique_id, d.sol_id as sol_id,
                         e.id as asset_type_id, e.name as asset_name,
                        (select id from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place_id,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         JOIN fm_construction_asset_series_slot c ON b.slot_id=c.id
                        JOIN fm_construction_asset_series d ON c.asset_series_id=d.id
                        JOIN production_assets e ON d.production_asset_id=e.id
                        where (c.asset_series_id =$asset_series_id and b.service_outlet_id =$sol_id) and (b.is_approved=1 and b.is_deleted=0) and b.production_asset_id=$production_asset_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        /**
         * This is the function that assigns asset slots to a place or warehouyse
         */
        public function actionaddassetslotstoplaceorwarehouse(){
            $model = new AssetInWarehouseAndPlace;
            
           $slot_code = $_POST['slot_code'];
           if(isset($_POST['allocated_space_for_use'])){
               $allocated_space_for_use = $_POST['allocated_space_for_use'];
           }else{
               $allocated_space_for_use=0;
           }
           if($_POST['is_for_storage'] == 1){
               $allocated_storage_capacity_in_cubic_feet = $_POST['allocated_storage_capacity_in_cubic_feet'];
               $used_allocated_storage_capacity_in_cubic_feet = $_POST['used_allocated_storage_capacity_in_cubic_feet'];
           }else{
               $allocated_storage_capacity_in_cubic_feet=0;
               $used_allocated_storage_capacity_in_cubic_feet=0;
           }
           
           $warehouse_and_place = $_POST['warehouse_and_place'];
           $number_of_items_in_slot = $_POST['number_of_items_in_slot'];
           $quantity_of_assets_in_place_or_warehouse = $_POST['quantity_of_assets_in_place_or_warehouse'];
           $asset_subtype_code = $_POST['active_asset_subtype_code'];
           $series_id = $_POST['series_id'];
           $slot_id = $_POST['slot_id'];
           $sol_id = $_POST['sol_id'];
           $production_asset_id = $_POST['production_asset_id'];
           
            $remaining_storage_capacity = $allocated_storage_capacity_in_cubic_feet - $used_allocated_storage_capacity_in_cubic_feet;
                    
           $remaining_quantity_in_slot = $number_of_items_in_slot - $quantity_of_assets_in_place_or_warehouse;
           
           if($remaining_quantity_in_slot >= $_POST['quantity_of_assets_in_capacity']){
               
            if($allocated_space_for_use<=$remaining_storage_capacity){
               $model->warehouse_and_place_allocation_id = $_POST['allocation_id'];
                $model->production_asset_id = $_POST['production_asset_id'];
                $model->series_id = $_POST['series_id'];
                $model->slot_id = $_POST['slot_id']; 
                $model->service_outlet_id = $_POST['sol_id'];
                $model->warehouse_id=$_REQUEST['warehouse_and_place_id'];
                $model->sku = $_POST['sku']; 
                if(isset($_POST['allocated_space_for_use'])){
                    $model->allocated_storage_capacity_in_cubic_feet = $_POST['allocated_space_for_use'];
                }else{
                    $model->allocated_storage_capacity_in_cubic_feet = NULL;
                }
                
                $model->quantity_of_assets_in_capacity = $_POST['quantity_of_assets_in_capacity'];
                $model->warehousing_allocation_cost = $_POST['warehousing_allocation_cost'];
                $model->warehousing_duration_in_weeks = $_POST['warehousing_duration_in_weeks']; 
                $total_of_used_storage_space = (double)$used_allocated_storage_capacity_in_cubic_feet + (double)$allocated_space_for_use;
                if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
               $slot_updated_item = (double)$quantity_of_assets_in_place_or_warehouse + (double)$model->quantity_of_assets_in_capacity;
              $model->date_initiated = new CDbExpression('NOW()');
                $model->initiated_by_id = Yii::app()->user->id;
                if($model->save()){
                    //update the items in a slot table
                    $this->updateItemsInThisSlot($series_id,$slot_id,$asset_subtype_code,$slot_updated_item);
                    
                    //update the used allocated space for this warehouse
                    $this->updateTheUsedStorageCapacityForThisWarehouseAllocation($model->warehouse_and_place_allocation_id,$total_of_used_storage_space);
                         // $result['success'] = 'true';
                          $msg = "Successfully added  '$model->quantity_of_assets_in_capacity'  items of  '$slot_code' slot to the '$warehouse_and_place' warehouse or place";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this slot assets to '$warehouse_and_place' warehouse or place was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
               
               
           }else{
               //$result['success'] = 'false';
                         $msg = "The space you are using for warehousing or placement cannot be greater than the total space allocated to your service outlet";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
               
           }
               
               
           }else{
               //$result['success'] = 'false';
                         $msg = "You cannot add more items than you have in a slot. Please rectify this and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
               
               
           }
           
           
            
            
        }
        
        
        
        
         /**
         * This is the function that modifies assigned asset slots in a place or warehouyse
         */
        public function actionmodifyassetslotsinplaceorwarehouse(){
           $_id = $_POST['id'];
            
            $model= AssetInWarehouseAndPlace::model()->findByPk($_id);
            
           $slot_code = $_POST['slot_code'];
           $allocation_id = $_POST['allocation_id'];
           
           if(isset($_POST['allocated_space_for_use'])){
               $original_allocated_space_for_use = $_POST['original_allocated_space_for_use'];
               $allocated_space_for_use = (double)$_POST['allocated_space_for_use'];
               $diff = $allocated_space_for_use -  $original_allocated_space_for_use;
               if($diff == 0){
                   $allocated_space_for_use = 0;
               }else{
                   $allocated_space_for_use = $diff;
               }
               
               
           }else{
               $allocated_space_for_use=0;
           }
           if($_POST['is_for_storage'] == 1){
               $allocated_storage_capacity_in_cubic_feet = $_POST['total_allocated_storage_capacity_in_cubic_feet'];
               $used_allocated_storage_capacity_in_cubic_feet = $_POST['used_allocated_storage_capacity_in_cubic_feet'];
           }else{
               $allocated_storage_capacity_in_cubic_feet=0;
               $used_allocated_storage_capacity_in_cubic_feet=0;
           }
           
           $warehouse_and_place = $_POST['warehouse_and_place'];
           $number_of_items_in_slot = $_POST['number_of_items_in_slot'];
           $quantity_of_assets_in_place_or_warehouse = $_POST['quantity_of_assets_in_place_or_warehouse'];
           $asset_subtype_code = $_POST['active_asset_subtype_code'];
           $series_id = $_POST['series_id'];
           $slot_id = $_POST['slot_id'];
           $sol_id = $_POST['sol_id'];
           $production_asset_id = $_POST['production_asset_id'];
           
            $remaining_storage_capacity = (double)$allocated_storage_capacity_in_cubic_feet - (double)$used_allocated_storage_capacity_in_cubic_feet;
                    
           $remaining_quantity_in_slot = $number_of_items_in_slot - $quantity_of_assets_in_place_or_warehouse;
           
           if($remaining_quantity_in_slot >= $_POST['quantity_of_assets_in_capacity']){
               
            if($allocated_space_for_use<=$remaining_storage_capacity){
               $model->warehouse_and_place_allocation_id = $_POST['allocation_id'];
                $model->production_asset_id = $_POST['production_asset_id'];
                $model->warehouse_id=$_REQUEST['warehouse_and_place_id'];
                $model->series_id = $_POST['series_id'];
                $model->slot_id = $_POST['slot_id']; 
                $model->service_outlet_id = $_POST['sol_id'];
                $model->sku = $_POST['sku']; 
                if(isset($_POST['allocated_space_for_use'])){
                    $model->allocated_storage_capacity_in_cubic_feet = $_POST['allocated_space_for_use'];
                }else{
                    $model->allocated_storage_capacity_in_cubic_feet = 0;
                }
                $model->quantity_of_assets_in_capacity = $_POST['quantity_of_assets_in_capacity'];
                $model->warehousing_allocation_cost = $_POST['warehousing_allocation_cost'];
                $model->warehousing_duration_in_weeks = $_POST['warehousing_duration_in_weeks']; 
                $model->is_modification_approved = 0;
                $model->is_approved = 0; 
                $model->is_rejected = 0; 
                $total_of_used_storage_space = (double)$used_allocated_storage_capacity_in_cubic_feet + (double)$allocated_space_for_use;
                //$total_of_used_storage_space = (double)$used_allocated_storage_capacity_in_cubic_feet + (double)$model->allocated_storage_capacity_in_cubic_feet;
                if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
               $slot_updated_item = (double)$quantity_of_assets_in_place_or_warehouse + (double)$model->quantity_of_assets_in_capacity;
              $model->date_initiated = new CDbExpression('NOW()');
                $model->initiated_by_id = Yii::app()->user->id;
                if($model->save()){
                    //update the items in a slot table
                    $this->updateItemsInThisSlot($series_id,$slot_id,$asset_subtype_code,$slot_updated_item);
                    
                    //update the used allocated space for this warehouse
                    $this->updateTheUsedStorageCapacityForThisWarehouseAllocation($model->warehouse_and_place_allocation_id,$total_of_used_storage_space);
                         // $result['success'] = 'true';
                          $msg = "Successfully updated  '$model->quantity_of_assets_in_capacity'  items of  '$slot_code' slot in '$warehouse_and_place' warehouse or place";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update this slot assets in '$warehouse_and_place' warehouse or place was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
               
               
           }else{
               //$result['success'] = 'false';
                         $msg = "The space you are using for warehousing or placement cannot be greater than the remaining space allocated to your service outlet";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                        "remaining_storage_capacity"=>$remaining_storage_capacity,
                                        "allocated_space_for_use"=>$allocated_space_for_use,
                                        "allocated_storage_capacity_in_cubic_feet"=>$allocated_storage_capacity_in_cubic_feet,
                                        "used_allocated_storage_capacity_in_cubic_feet"=>$used_allocated_storage_capacity_in_cubic_feet)
                           );
               
           }
               
               
           }else{
               //$result['success'] = 'false';
                         $msg = "You cannot add more items than you have in a slot. Please rectify this and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
               
               
           }
           
           
            
            
        }
        
        
        /**
         * This is the function that updates the production assets slot
         */
        public function updateItemsInThisSlot($series_id,$slot_id,$asset_subtype_code,$slot_updated_item){
            $model = new ProductionAssets;
            return $model->updateItemsInThisSlot($series_id,$slot_id,$asset_subtype_code,$slot_updated_item);
        }
        
        
        /**
         * This is the function that updates the used storage allocated space in a warehouse
         */
        public function updateTheUsedStorageCapacityForThisWarehouseAllocation($warehouse_and_place_allocation_id,$total_of_used_storage_space){
            $model = new AllocateWarehouseStorageSpace;
            return $model->updateTheUsedStorageCapacityForThisWarehouseAllocation($warehouse_and_place_allocation_id,$total_of_used_storage_space);
            
        }
        
        
        
         /**
         * This is the function that updates the production assets slot
         */
        public function modifyItemsInThisSlot($series_id,$slot_id,$asset_subtype_code,$slot_updated_item){
            $model = new ProductionAssets;
            return $model->modifyItemsInThisSlot($series_id,$slot_id,$asset_subtype_code,$slot_updated_item);
        }
        
        
        
        
        /**
         * This is the function that updates the used storage allocated space in a warehouse
         */
        public function modifyTheUsedStorageCapacityForThisWarehouseAllocation($allocation_id,$warehouse_and_place_id,$sol_id,$total_of_used_storage_space){
            $model = new AllocateWarehouseStorageSpace;
            return $model->modifyTheUsedStorageCapacityForThisWarehouseAllocation($allocation_id,$warehouse_and_place_id,$sol_id,$total_of_used_storage_space);
            
        }
        
        
        
        /**
         * This is the function that approves a slot warehousing and placement allocation
         */
        public function actionapproveassetslotsinplaceorwarehouse(){
            
            $_id = $_POST['id'];
            $slot_number = $_POST['slot_code'];
            $model= AssetInWarehouseAndPlace::model()->findByPk($_id);
            
            $model->is_approved = 1; 
            $model->is_rejected = 0;
            $model->is_deleted = 0; 
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The warehousing and placement of all or some of the items in '$slot_number' slot is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
         /**
         * This is the function that approves a slot warehousing and placement allocation
         */
        public function actionrejectassetslotsinplaceorwarehouse(){
            
            $_id = $_POST['id'];
            $slot_number = $_POST['slot_code'];
            $model= AssetInWarehouseAndPlace::model()->findByPk($_id);
            
            $model->is_approved = 0;
            $model->is_approved = 0;
            $model->is_rejected = 1;
            //$model->is_deleted = 1; 
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The warehousing and placement of all or some of the items in '$slot_number' slot is rejected";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'rejection request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        /**
         * This is the function that retrieve the stock units in a warehouse and place
         */
        public function actiongettheavailablestocksinthiswarehouseandplace(){
            
           $data= [];
           $warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
           $sol_id = $_REQUEST['sol_id'];
           $slot_id =  $_REQUEST['slot_id'];
           $series_id = $_REQUEST['series_id'];
           $allocation_id = $_REQUEST['allocation_id'];
           $production_asset_id = $_REQUEST['production_asset_id'];
           
            
            $q = "select b.sku              
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         where (a.id =$allocation_id and b.warehouse_id=$warehouse_and_place_id) and (b.series_id=$series_id and b.slot_id =$slot_id) and (b.production_asset_id=$production_asset_id and b.service_outlet_id=$sol_id)
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "sku"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that list all approved allocated warehouse and places spaces that are ready for requisition
         */
        public function actiongetthedetailsofthissku(){
            $data= [];
        $warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
           $sol_id = $_REQUEST['sol_id'];
           $sku = $_POST['sku'];
            
            $q = "select a.*,b.allocated_storage_capacity_in_cubic_feet as sku_allocated_storage_capacity_in_cubic_feet, b.quantity_of_assets_in_capacity as sku_quantity_of_assets_in_capacity,b.id as assignment_id,
                b.warehousing_allocation_cost as warehousing_allocation_cost, b.warehousing_duration_in_weeks as warehousing_duration_in_weeks,b.description as warehouse_descrioption,b.sku,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         where (a.service_outlet_id =$sol_id and b.is_approved=1) and (a.warehouse_id=$warehouse_and_place_id and b.sku='$sku')
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
             
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "space"=>$data,
                                    "lenght" => sizeof($data)
                                  
                            ));
            
        }
        
        
        
        
        
         /**
         * This is the function that retrieve the stock units in an allocated warehouse and place
         */
        public function actionlistallallocatedseriesslotskuforthisproductionasset(){
            
           $data= [];
           $allocation_id = $_REQUEST['allocation_id'];
           $sol_id = $_REQUEST['sol_id'];
            
            $q = "select b.sku              
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         where (a.service_outlet_id =$sol_id and b.is_approved=1) and a.id=$allocation_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "sku"=>$data,
                                  
                            ));
        }
        
}
