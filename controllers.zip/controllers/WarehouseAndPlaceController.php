<?php

class WarehouseAndPlaceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listthissolwarehouseandplaces','listthissolmodifiedwarehouseandplaces',
                                    'listthissolwarehouseandplacesavailableforallocation','addnewwarehouseandplace','modifywarehouseandplace',
                                    'approvenewwarehouseandplace','approvemodifiedwarehouseandplace','listthissolavailablewarehouseandplaces'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list a service outlet created warehouses and places
         */
        public function actionlistthissolwarehouseandplaces(){
            
            $organization_id = $_REQUEST['organization_id'];
            $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as location from warehouse_and_place a
                    JOIN location b ON a.location_id=b.id
                    where a.service_outlet_owner_id =$sol_id and (is_deleted=0 and is_approved=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "warehouse"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that list a service outlet  warehouses and places that are currently modified
         */
        public function actionlistthissolmodifiedwarehouseandplaces(){
            
            $organization_id = $_REQUEST['organization_id'];
            $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as location from warehouse_and_place a
                    JOIN location b ON a.location_id=b.id
                    where a.service_outlet_owner_id =$sol_id and (is_deleted=0 and is_modification_approved=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "warehouse"=>$data,
                                  
                            ));
        }
        
        
        
        
         /**
         * This is the function that list a service outlet  all created warehouses and places
         */
        public function actionlistthissolavailablewarehouseandplaces(){
            
            $organization_id = $_REQUEST['organization_id'];
            $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as location from warehouse_and_place a
                    JOIN location b ON a.location_id=b.id
                    where a.service_outlet_owner_id =$sol_id and (is_deleted=0 and is_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "warehouse"=>$data,
                                  
                            ));
        }
        
        /**
         * This is the function that list a service outlet  warehouses and places that are available for maintenance and allocation
         */
        public function actionlistthissolwarehouseandplacesavailableforallocation(){
            
            $organization_id = $_REQUEST['organization_id'];
            $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as location from warehouse_and_place a
                    JOIN location b ON a.location_id=b.id
                    where a.service_outlet_owner_id =$sol_id and (is_deleted=0 and (is_modification_approved=1 and is_approved = 1))
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "warehouse"=>$data,
                                  
                            ));
        }
        
        
        /**
         * this is the function that adds a new warehouse or place
         */
        public function actionaddnewwarehouseandplace(){
            
            
             $model = new WarehouseAndPlace;
             $is_for_storage = $_POST['is_for_storage'];
            if($is_for_storage == 1){
                
                        
             
             $model->name = $_POST['name'];
            
                $model->location_id = $_POST['location_id'];
                $model->address = $_POST['address'];
                 $model->type = $_POST['type'];
               $model->location_longtitude = $_POST['location_longtitude'];
                $model->service_outlet_owner_id = $_POST['sol_id'];
                 $model->location_latitude = $_POST['location_latitude'];
                 $model->is_for_storage = 1;
                 if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
                 }
                 $model->warehouse_height_in_feet = $_POST['warehouse_height_in_feet'];
                 $model->warehouse_length_in_feet = $_POST['warehouse_length_in_feet'];
                 $model->warehouse_breadth_in_feet = $_POST['warehouse_breadth_in_feet'];
                 $model->total_unusable_space_in_square_feets = $_POST['total_unusable_space_in_square_feets'];
                 $model->total_space_in_square_feets = round((double)$model->warehouse_length_in_feet  * (double)$model->warehouse_breadth_in_feet,2);
                 $model->warehouse_total_storage_in_square_feets = round($model->total_space_in_square_feets - (double)$model->total_unusable_space_in_square_feets,2);
                 $model->warehouse_storage_capacity_in_cubic_feet = round($model->warehouse_total_storage_in_square_feets * (double)$model->warehouse_height_in_feet,2);
                 $model->remaining_storage_capacity_in_cubic_feet = round($model->warehouse_storage_capacity_in_cubic_feet,2);
                 $model->is_approved = 0;
                 $model->is_modification_approved = 0;
                 $model->create_time = new CDbExpression('NOW()');
                 $model->create_user_id = Yii::app()->user->id;
                
                 
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added the  '$model->name' Warehouse or Place  ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this warehouse or place  was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                
                
                
                
                
            }else{
                
                
            
             $model->service_outlet_owner_id = $_POST['sol_id'];
             $model->name = $_POST['name'];
             if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
                $model->location_id = $_POST['location_id'];
                $model->address = $_POST['address'];
                 $model->type = $_POST['type'];
                 $model->location_longtitude = $_POST['location_longtitude'];
                 $model->location_latitude = $_POST['location_latitude'];
                 $model->is_for_storage = 0;
                 $model->is_approved = 0;
                 $model->is_modification_approved = 0;
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added the  '$model->name' Warehouse or Place ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this warehouse or place  was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                
                
                
            }
            
        }
        
        
        
        
         /**
         * This is the function that modifies the warehouse and place info
         */
        public function actionmodifywarehouseandplace(){
            
            $_id = $_POST['id'];
            
            $model= WarehouseAndPlace::model()->findByPk($_id);
            $is_for_storage = $_POST['is_for_storage'];
            if($is_for_storage == 1){
                
                        
             
             $model->name = $_POST['name'];
            
                $model->location_id = $_POST['location_id'];
                $model->address = $_POST['address'];
                 $model->type = $_POST['type'];
               $model->location_longtitude = $_POST['location_longtitude'];
                $model->service_outlet_owner_id = $_POST['sol_id'];
                 $model->location_latitude = $_POST['location_latitude'];
                 $model->is_for_storage = 1;
                 if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
                 }
                 $model->warehouse_height_in_feet = $_POST['warehouse_height_in_feet'];
                 $model->warehouse_length_in_feet = $_POST['warehouse_length_in_feet'];
                 $model->warehouse_breadth_in_feet = $_POST['warehouse_breadth_in_feet'];
                 $model->total_unusable_space_in_square_feets = $_POST['total_unusable_space_in_square_feets'];
                 $model->total_space_in_square_feets = round((double)$model->warehouse_length_in_feet  * (double)$model->warehouse_breadth_in_feet,2);
                 $model->warehouse_total_storage_in_square_feets = round($model->total_space_in_square_feets - (double)$model->total_unusable_space_in_square_feets,2);
                 $model->warehouse_storage_capacity_in_cubic_feet = round($model->warehouse_total_storage_in_square_feets * (double)$model->warehouse_height_in_feet,2);
                 $model->remaining_storage_capacity_in_cubic_feet = round($model->warehouse_storage_capacity_in_cubic_feet,2);
                 $model->is_modification_approved = 0;
                 $model->update_time = new CDbExpression('NOW()');
                 $model->update_user_id = Yii::app()->user->id;
                
                 
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully modified the  '$model->name' Warehouse or Place  ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to modify this warehouse or place  was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                
                
                
                
                
            }else{
                
                
            
             $model->service_outlet_owner_id = $_POST['sol_id'];
             $model->name = $_POST['name'];
             if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
                $model->location_id = $_POST['location_id'];
                $model->address = $_POST['address'];
                 $model->type = $_POST['type'];
                 $model->location_longtitude = $_POST['location_longtitude'];
                 $model->location_latitude = $_POST['location_latitude'];
                 $model->is_for_storage = 0;
                 $model->is_modification_approved = 0;
                 $model->warehouse_height_in_feet = 0;
                 $model->warehouse_length_in_feet = 0;
                 $model->warehouse_breadth_in_feet = 0;
                 $model->total_unusable_space_in_square_feets = 0;
                 $model->total_space_in_square_feets = round((double)$model->warehouse_length_in_feet  * (double)$model->warehouse_breadth_in_feet,2);
                 $model->warehouse_total_storage_in_square_feets = round($model->total_space_in_square_feets - (double)$model->total_unusable_space_in_square_feets,2);
                 $model->warehouse_storage_capacity_in_cubic_feet = round($model->warehouse_total_storage_in_square_feets * (double)$model->warehouse_height_in_feet,2);
                 $model->remaining_storage_capacity_in_cubic_feet = round($model->warehouse_storage_capacity_in_cubic_feet,2);
                 
              $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully modified the  '$model->name' Warehouse or Place ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to modify this warehouse or place  was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                
                
                
            }
            
            
        }
        
        
        
        /**
         * This is the function that approves a  newly created warehouse and place 
         */
        public function actionapprovenewwarehouseandplace(){
            
            $_id = $_POST['id'];
            $model= WarehouseAndPlace::model()->findByPk($_id);
            
                      
             $model->is_approved = 1;  
             $model->is_modification_approved = 1;  
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' Warehouse or Place is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        /**
         * This is the function that approves a  modified warehouse and place 
         */
        public function actionapprovemodifiedwarehouseandplace(){
            
            $_id = $_POST['id'];
            $model= WarehouseAndPlace::model()->findByPk($_id);
            
             $model->is_approved = 1;           
             $model->is_modification_approved = 1;  
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' Warehouse or Place is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
}
