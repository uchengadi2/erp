<?php

class ImagineplaceBatchedStreetPoleAssetController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listthisolstreetpolesbatchseries','addnewstreetpoleassetbatchseries','modifystreetpoleassetbatchseries',
                                    'deleteoneassetbatchseries','listthissolforadjustmentstreetpolesbatchseries','listthissoldeletedstreetpolesbatchseries',
                                    'listthissolunapprovedstreetpolesbatchseries','approvestreetpoleassetbatchseries','undeletestreetpoleassetbatchseries'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all batched street poles series
         */
        public function actionlistthisolstreetpolesbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from imagineplace_batched_street_pole_asset a
                    where a.sol_id =$sol_id and is_deleted=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
        
        /**
         * This is the function that list all unapproved street pole batch series in a sol
         */
        public function actionlistthissolunapprovedstreetpolesbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from imagineplace_batched_street_pole_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
        
        
        /**
         * This is the function that list all deleted street poles batch series in a sol
         */
        public function actionlistthissoldeletedstreetpolesbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from imagineplace_batched_street_pole_asset a
                    where a.sol_id =$sol_id and (is_deleted=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
        /**
         * This is the function that list all for adjustment street poles batch series in a sol
         */
        public function actionlistthissolforadjustmentstreetpolesbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from imagineplace_batched_street_pole_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
        
        /**
         * This is the function that creates new street pole batched street
         */
        public function actionaddnewstreetpoleassetbatchseries(){
            
           $model = new ImagineplaceBatchedStreetPoleAsset;
           
           $active_asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            
           $model->sol_id = $_POST['sol_id'];
           $model->production_asset_id = $_POST['production_asset_id'];
           $model->total_number_of_poles = $_POST['total_number_of_poles'];
           $model->pole_location_type = $_POST['pole_location_type'];
           $model->batch_series_name = $_POST['batch_series_name'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
          // $model->pole_location_length_dimension = $_POST['pole_location_length_dimension'];
           $model->accounting_preference = $_POST['accounting_preference'];
                    
           
           if($_POST['method_of_acquisition'] == "others"){
               $model->other_acquisition_method = $_POST['other_acquisition_method'];
               $model->method_of_acquisition = $_POST['other_acquisition_method'];
           }else{
               $model->other_acquisition_method = NULL;
               $model->method_of_acquisition = $_POST['method_of_acquisition'];
           }
          
           if($_POST['batch_split_parameter'] =="others"){
               $model->other_batch_split_parameter = $_POST['other_batch_split_parameter'];
               $model->batch_split_parameter = $_POST['other_batch_split_parameter'];
           }else{
              $model->other_batch_split_parameter=NULL; 
               $model->batch_split_parameter = $_POST['batch_split_parameter'];
           }
           
           $model->number_to_split_batch = $_POST['number_to_split_batch'];
           $model->acquired_from = $_POST['acquired_from'];
           $model->street_pole_gl_id = $_POST['street_pole_gl_id'];
           $model->total_cost = $_POST['total_cost'];
           $model->average_cost_per_unit = (double)$model->total_cost/(double)$model->total_number_of_poles;
          // $model->primary_source_document_number_id = $_POST['primary_source_document_number_id'];
           $model->is_acquisition_approved = 0;
           $model->date_acquired = date("Y-m-d H:i:s", strtotime($_POST['date_acquired']));
           //$model->acquisition_approved_date = date("Y-m-d H:i:s", strtotime($_POST['acquisition_approved_date']));
           //$model->acquisition_approved_id = $_POST['acquisition_approved_id'];
           //$model->transaction_type_id = $_POST['transaction_type_id'];
           $model->property_acquisition_duration_in_days = $_POST['property_acquisition_duration_in_days'];
           $model->property_location = $_POST['property_location'];
           $model->pole_location_condition = $_POST['pole_location_condition'];
           $model->batched_street_pole_unique_number = $model->generateTheStreetPoleAssetBatchSeriesUniqueNumber();
           
            if(isset($_POST['is_pole_location_with_work'])){
               $model->is_pole_location_with_working_street_light = $_POST['is_pole_location_with_work'];
           }else{
               $model->is_pole_location_with_working_street_light=0;
           }
            if(isset($_POST['is_pole_location_with_working_street_light'])){
               $model->is_pole_location_with_working_street_light = $_POST['is_pole_location_with_working_street_light'];
           }else{
               $model->is_pole_location_with_working_street_light=0;
           }
           
           $model->batch_series_incrementer = (int)$model->getTheCurrentIncrementedNumber() + 1;
           
           if((int)$model->total_number_of_poles>=(int)$model->number_to_split_batch){
               if((int)$model->total_number_of_poles%(int)$model->number_to_split_batch==0){
                    $model->batch_series_remaining_slot = (int)$model->total_number_of_poles/(int)$model->number_to_split_batch;
                }else{
                    $model->batch_series_remaining_slot = (int)$model->total_number_of_poles/(int)$model->number_to_split_batch + 1;
                 }
          
               
           }else{
               $model->batch_series_remaining_slot= 1;
           }
           
           
           $model->create_time = new CDbExpression('NOW()');
           $model->acquisition_enterred_by_id = Yii::app()->user->id;
           if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created Street Pole Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                              "batch_series_number"=>$model->batched_street_pole_unique_number )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to create this Street Pole Batch Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            "batch_series_number"=>$model->batched_street_pole_unique_number)
                           );
                    } 
          
            
        }
        
        
        
         /**
         * This is the function that modifies street pole batched street
         */
        public function actionmodifystreetpoleassetbatchseries(){
            
             $_id = $_POST['id'];
             $model= ImagineplaceBatchedStreetPoleAsset::model()->findByPk($_id);
            
            $model->sol_id = $_POST['sol_id'];
           $model->production_asset_id = $_POST['production_asset_id'];
           $total_number_of_poles = $_POST['total_number_of_poles'];
           $model->pole_location_type = $_POST['pole_location_type'];
           $model->batch_series_name = $_POST['batch_series_name'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
          // $model->pole_location_length_dimension = $_POST['pole_location_length_dimension'];
           $model->accounting_preference = $_POST['accounting_preference'];
           
           if($_POST['method_of_acquisition'] == "others"){
               $model->other_acquisition_method = $_POST['other_acquisition_method'];
               $model->method_of_acquisition = $_POST['other_acquisition_method'];
           }else{
               $model->other_acquisition_method = NULL;
               $model->method_of_acquisition = $_POST['method_of_acquisition'];
           }
          
           if($_POST['batch_split_parameter'] =="others"){
               $model->other_batch_split_parameter = $_POST['other_batch_split_parameter'];
               $model->batch_split_parameter = $_POST['other_batch_split_parameter'];
           }else{
              $model->other_batch_split_parameter=NULL; 
               $model->batch_split_parameter = $_POST['batch_split_parameter'];
           }
           
           $number_to_split_batch = $_POST['number_to_split_batch'];
           $model->acquired_from = $_POST['acquired_from'];
           $model->street_pole_gl_id = $_POST['street_pole_gl_id'];
           $model->total_cost = $_POST['total_cost'];
           
          // $model->primary_source_document_number_id = $_POST['primary_source_document_number_id'];
          // $model->is_acquisition_approved = 0;
           $model->date_acquired = date("Y-m-d H:i:s", strtotime($_POST['date_acquired']));
          // $model->acquisition_approved_date = $_POST['acquisition_approved_date'];
           //$model->acquisition_approved_id = $_POST['acquisition_approved_id'];
           //$model->transaction_type_id = $_POST['transaction_type_id'];
           $model->property_acquisition_duration_in_days = $_POST['property_acquisition_duration_in_days'];
           $model->property_location = $_POST['property_location'];
           $model->pole_location_condition = $_POST['pole_location_condition'];
           if(isset($_POST['is_pole_location_a_dual_carriageway'])){
               $model->is_pole_location_a_dual_carriageway = $_POST['is_pole_location_a_dual_carriageway'];
           }else{
               $model->is_pole_location_a_dual_carriageway=0;
           }
           
           if(isset($_POST['is_pole_location_with_work'])){
               $model->is_pole_location_with_working_street_light = $_POST['is_pole_location_with_work'];
           }else{
               $model->is_pole_location_with_working_street_light=0;
           }
            if(isset($_POST['is_pole_location_with_working_street_light'])){
               $model->is_pole_location_with_working_street_light = $_POST['is_pole_location_with_working_street_light'];
           }else{
               $model->is_pole_location_with_working_street_light=0;
           }
           
           if($this->isThisBatchSeriesWithAssets($_id)){
               $model->total_number_of_poles = $model->total_number_of_poles;
               $model->number_to_split_batch = $model->number_to_split_batch;
               $model->batch_series_remaining_slot = $model->batch_series_remaining_slot;
               $model->average_cost_per_unit = round((double)$model->total_cost/(double)$model->total_number_of_poles,2);
           }else{
             if((int)$total_number_of_poles>=(int)$number_to_split_batch){
               if((int)$total_number_of_poles%(int)$number_to_split_batch==0){
                    $model->batch_series_remaining_slot = (int)$total_number_of_poles/(int)$number_to_split_batch;
                    $model->total_number_of_poles=$total_number_of_poles;
                    $model->number_to_split_batch = $number_to_split_batch;
                    $model->average_cost_per_unit = round((double)$model->total_cost/(double)$total_number_of_poles,2);
                }else{
                    $model->batch_series_remaining_slot = (int)$total_number_of_poles/(int)$number_to_split_batch + 1;
                    $model->total_number_of_poles=$total_number_of_poles;
                    $model->number_to_split_batch = $number_to_split_batch;
                    $model->average_cost_per_unit = round((double)$model->total_cost/(double)$total_number_of_poles,2);
                 }
          
               
           }else{
               $model->batch_series_remaining_slot= 1;
               $model->total_number_of_poles=$total_number_of_poles;
               $model->number_to_split_batch = $number_to_split_batch;
               $model->average_cost_per_unit = round((double)$model->total_cost/(double)$total_number_of_poles,2);
           }
               
           }
      
           $model->update_time = new CDbExpression('NOW()');
           $model->update_user_id = Yii::app()->user->id;
           if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated this Street Pole Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg
                              )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to update this Street Pole Btach Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        
        
        /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($id){
            $model = new ImagineplaceStreetPoleAssetSlot;
            return $model->isThisBatchSeriesWithAssets($id);
        }
        
        
         /**
         * This is the function that removes  street pole batched street
         */
        public function actiondeleteoneassetbatchseries(){
            
            $_id = $_POST['id'];
            $model= ImagineplaceBatchedStreetPoleAsset::model()->findByPk($_id);
            
                      
             $model->is_deleted = 1;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->batch_series_name' Asset Batch Series is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        
        /**
         * This is the function that approves street pole batched street
         */
        public function actionapprovestreetpoleassetbatchseries(){
            
            $_id = $_POST['id'];
            $model= ImagineplaceBatchedStreetPoleAsset::model()->findByPk($_id);
            
                      
             $model->is_acquisition_approved = 1;  
             $model->acquisition_approved_id = Yii::app()->user->id;
             $model->acquisition_approved_date = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->batch_series_name' Asset Batch Series is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        
         /**
         * This is the function that undeletes street poles batched street
         */
        public function actionundeletestreetpoleassetbatchseries(){
            
            $_id = $_POST['id'];
            $model= ImagineplaceBatchedStreetPoleAsset::model()->findByPk($_id);
            
                      
            
            // if($model->batch_series_remaining_slot > 0){
                  if($this->isThisBatchSeriesWithAssets($_id)){
                      $model->batch_series_remaining_slot = (int)$model->batch_series_remaining_slot - 1;
                      
                  }else{
                     $model->batch_series_remaining_slot=$model->batch_series_remaining_slot; 
                  }
                 
                  $model->is_deleted = 0;   
                  
                  if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->batch_series_name' Asset Batch Series is successfully undeleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'undeletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
                  
                  
                  
          /**   }else{
                  $msg = 'You cannot undelete from this series as its slot had been exhausted';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
             }
           * 
           */
             
            
            
            
        }
        
        
}
