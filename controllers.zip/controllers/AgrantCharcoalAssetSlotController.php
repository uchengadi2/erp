<?php

class AgrantCharcoalAssetSlotController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addnewcharcoalassetslottoseries','modifycharcoalassetslottoseries','listAllSlotsInThisBatchSeries'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all series slots in a batch
         */
        public function actionlistAllSlotsInThisBatchSeries(){
            $model = new AgrantCharcoalAssetSlot;
            
            $batch_series_id = $_REQUEST['batch_series_id'];
        // $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from agrant_charcoal_asset_slot a
                    where a.charcoal_batch_id =$batch_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "asset"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that adds a new slot to a batch series
         */
        public function actionaddnewcharcoalassetslottoseries(){
            
            
            $model = new AgrantCharcoalAssetSlot;
           
           $model->charcoal_batch_id = $_REQUEST['active_batch_series_id'];
            
           $model->slot_name = $_POST['slot_name'];
           $model->quantity_in_kg = $_POST['quantity_in_kg'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
           $model->charcoal_type = $_POST['charcoal_type'];
           $model->slot_gl_id = $_POST['slot_gl_id'];
           $model->total_slots_cost = $_POST['total_slots_cost'];
           $model->delivery_cost = $_POST['delivery_cost'];
           $model->loading_cost = $_POST['loading_cost'];
           $model->bagging_cost = $_POST['bagging_cost'];
           if(isset($_POST['is_certified'])){
                if($_POST['is_certified'] == 1){
                   $model->is_certified = $_POST['is_certified'];
                   $model->certification_by = $_POST['certification_by'];
                   $model->certification_method = $_POST['certification_method'];
               }else{
                    $model->is_certified = $_POST['is_certified'];
                   $model->certification_by = null;
                   $model->certification_method = null;
               }
           }else{
               $model->is_certified = NUll;
               $model->certification_by = NUll;
               $model->certification_method = NUll;
           }
           if(isset($_POST['is_charcoal_packed'])){
               $model->is_charcoal_packed = $_POST['is_charcoal_packed'];
               
           }else{
               $model->is_charcoal_packed = 0;
               
           }
                                            
           $charcoal_batch_unique_number = $_POST['charcoal_batch_unique_number'];
           
           $model->charcoal_unique_number = $model->generateThisSlotUniqueNumber($charcoal_batch_unique_number);
           
          $model->series_slot_incrementer = (int)$model->getTheCurrentIncrementedNumber() + 1;
          
          $batch_series_remaining_slot = $this->retrieveTheRemainingBatchSlot($model->charcoal_batch_id);
          
          if($batch_series_remaining_slot>0){
              
              if($model->save()){
               
                        //reduce the remaining numbe of batches column in the batch series table
                        $new_batch_series_remaining_slot = $this->reduceTheRemainNumberOfBatchSeries($model->charcoal_batch_id);
                        
                        
                         // $result['success'] = 'true';
                          $msg = 'Successfully added new slot to this Charcoal Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                               )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to add this slot to this Charcoal Batch Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            )
                           );
                    } 
              
              
          }else{
               $msg = 'You cannot add any more slot to this  batch asset series as it had been exhausted';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            )
                           );
              
          }
          
           
            
        }
        
        
        
          /**
         * This is the function that reduces the remaining number of batch series
         */
        public function reduceTheRemainNumberOfBatchSeries($batch_series_id){
            $model = new AgrantBatchCharcoalAsset;
            return $model->reduceTheRemainNumberOfBatchSeries($batch_series_id);
        }
        
        
        
         /**
         * This is the function that retrieves the remaining number of batch series
         */
        public function retrieveTheRemainingBatchSlot($batch_series_id){
            $model = new AgrantBatchCharcoalAsset;
            return $model->retrieveTheRemainingBatchSlot($batch_series_id);
        }
        
        
        
        /**
         * This is the function that modifies a slot in a  batch series
         */
        public function actionmodifycharcoalassetslottoseries(){
            
                  
          $_id = $_POST['id'];
          $model= AgrantCharcoalAssetSlot::model()->findByPk($_id);  
          
           $model->charcoal_batch_id = $_REQUEST['active_batch_series_id'];
            
           $model->slot_name = $_POST['slot_name'];
           $model->quantity_in_kg = $_POST['quantity_in_kg'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
           $model->charcoal_type = $_POST['charcoal_type'];
           $model->slot_gl_id = $_POST['slot_gl_id'];
           $model->total_slots_cost = $_POST['total_slots_cost'];
           $model->delivery_cost = $_POST['delivery_cost'];
           $model->loading_cost = $_POST['loading_cost'];
           $model->bagging_cost = $_POST['bagging_cost'];
           if(isset($_POST['is_certified'])){
               if($_POST['is_certified'] == 1){
                   $model->is_certified = $_POST['is_certified'];
                   $model->certification_by = $_POST['certification_by'];
                   $model->certification_method = $_POST['certification_method'];
               }else{
                    $model->is_certified = $_POST['is_certified'];
                   $model->certification_by = null;
                   $model->certification_method = null;
               }
               
           }else{
               $model->is_certified = 0;
               $model->certification_by = NUll;
               $model->certification_method = NUll;
           }
           if(isset($_POST['is_charcoal_packed'])){
               $model->is_charcoal_packed = $_POST['is_charcoal_packed'];
               
           }else{
               $model->is_charcoal_packed = 0;
               
           }
          
          
                        
              if($model->save()){
               
                                              
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated slot in this Charcoal Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                               )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to update this slot in this Charcoal Batch Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            )
                           );
                    } 
              
              
          }
        
        
        
}
