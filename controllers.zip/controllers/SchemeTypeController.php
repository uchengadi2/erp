<?php

class SchemeTypeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllSchemeTypes','deletethisSchemeType','addnewSchemeType','modifySchemeType'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function that list all scheme types
         */
        public function actionlistAllSchemeTypes(){
            
            $schemetype= SchemeType::model()->findAll();
                if($schemetype===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "type" => $schemetype,
                                   
                    
                            ));
                       
                }
            
        }
        
        
        
           /**
      * This is the function that add new scheme type
      */
     public function actionaddnewSchemeType(){
         
         $model = new SchemeType;
            
            $model->name = $_POST['name']; 
             $model->code = $_POST['code']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                
                if($model->isSchemeTypeExist($model->code)== false){
                    if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  the '$model->name' scheme type";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this '$model->name'  scheme type was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                    
                }else{
                     $msg = "This scheme type is already created and cannot be duplicated";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    
                }
                
         
     }
     
     
      /**
      * This is the function that modifies new scheme type
      */
     public function actionmodifySchemeType(){
         
          $_id = $_POST['id'];
            
            $model= SchemeType::model()->findByPk($_id);
            
            $model->name = $_POST['name']; 
             $model->code = $_POST['code']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully modified  the '$model->name' scheme type";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to modify this '$model->name'  scheme type was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
         
     }
     
     
      /**
         * This is the function that deletes a Scheme Type
         */
        public function actiondeletethisSchemeType(){
            
            $_id = $_POST['id'];
            $model= SchemeType::model()->findByPk($_id);
            
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' Scheme Type is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
            
        }
}
