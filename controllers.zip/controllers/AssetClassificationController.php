<?php

class AssetClassificationController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listThisGroupAllAssetClassifications','deletethisAssetClassification',
                                    'addnewAssetClassification','modifyAssetClassification'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all corporate group asset classifications
         */
        public function actionlistThisGroupAllAssetClassifications(){
            
            $group_id = $_REQUEST['group_id'];
            
            $data = [];
            $q = "select a.id as asset_subtype_id, a.name as asset_subtype_name, b.*, c.name as group_name from asset_subtype a
                    JOIN asset_classification b ON a.id=b.asset_subtype_id
                    JOIN corp_group c ON b.group_id=c.id
                     where c.id =$group_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "classification"=>$data,
                                  
                            ));
            
        }
        
        
        
        /**
         * This is the function that adds a new asset classificatopn 
         */
        public function actionaddnewAssetClassification(){
            
            $model = new AssetClassification;
            
            $group_name = $_POST['group_name'];
            $asset_subtype_name = $_POST['asset_subtype_name'];
            $model->name = $_POST['name'];
            $model->asset_subtype_id = $_POST['asset_subtype_id']; 
             $model->group_id = $_POST['group_id']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  the '$model->name' asset classification to the selected '$asset_subtype_name' asset type";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this '$model->name'  asset classification to the '$asset_subtype_name' asset type was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                    
              
            
        }
        
        
        
        /**
         * This is the function that modifies asset classificatopn 
         */
        public function actionmodifyAssetClassification(){
            
            $_id = $_POST['id'];
            
            $model= AssetClassification::model()->findByPk($_id);
            
            $group_name = $_POST['group_name'];
            $asset_subtype_name = $_POST['asset_subtype_name'];
            $model->name = $_POST['name'];
            $model->asset_subtype_id = $_POST['asset_subtype_id']; 
             $model->group_id = $_POST['group_id']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully updated the '$model->name' asset classification";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update this '$model->name'  asset classification was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                    
              
            
        }
        
        
        
        /**
         * This is the function that deletes an Asset classification
         */
        public function actiondeletethisAssetClassification(){
            
            $_id = $_POST['id'];
            $model= AssetClassification::model()->findByPk($_id);
            
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' Asset Classification is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
            
        }
}
