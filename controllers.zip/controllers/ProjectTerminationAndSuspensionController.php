<?php

class ProjectTerminationAndSuspensionController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listinitiatedterminatedorsuspendedprojects','listmodifiedterminatedorsuspendedprojects',
                                    'listunapprovedterminatedorsuspendedprojects','listapprovedterminatedorsuspendedprojects','listforwithdrawalterminatedorsuspendedprojects',
                                    'listallsuspendedprojects','listallfreezedprojects','initiateprojectterminationrequest','modifyprojectterminationrequest',
                                    'rejectprojectterminationrequest','approveprojectterminationrequest','withdrawprojectterminationrequest',
                                    'unwithdrawprojectterminationrequest','unsuspendprojectterminationrequest','unfreezeprojectterminationrequest'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all newly initiated peoject terminations
         */
        public function actionlistinitiatedterminatedorsuspendedprojects(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as termination_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,c.name as service_outlet,c.id as sol_id
                  from project_termination_and_suspension a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and (a.is_approved=0 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that list all modified peoject terminations
         */
        public function actionlistmodifiedterminatedorsuspendedprojects(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as termination_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,c.name as service_outlet,c.id as sol_id
                  from project_termination_and_suspension a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and a.is_deleted=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
        }
        
        
        
        
        /**
         * This is the function that list all unapprove peoject terminations
         */
        public function actionlistunapprovedterminatedorsuspendedprojects(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as termination_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,c.name as service_outlet,c.id as sol_id
                  from project_termination_and_suspension a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and (a.is_approved=0 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that list all approve project terminations
         */
        public function actionlistapprovedterminatedorsuspendedprojects(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as termination_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,c.name as service_outlet,c.id as sol_id
                  from project_termination_and_suspension a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and (a.is_approved=1 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that list all withdrawn  project terminations
         */
        public function actionlistforwithdrawalterminatedorsuspendedprojects(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as termination_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,c.name as service_outlet,c.id as sol_id
                  from project_termination_and_suspension a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and (a.is_approved=0 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that list all suspended  peoject 
         */
        public function actionlistallsuspendedprojects(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as termination_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,c.name as service_outlet,c.id as sol_id
                  from project_termination_and_suspension a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id and a.type='suspend') and (a.is_approved=1 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that list all freezed  peoject
         */
        public function actionlistallfreezedprojects(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as termination_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,c.name as service_outlet,c.id as sol_id
                  from project_termination_and_suspension a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id and a.type='freeze') and (a.is_approved=1 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
        }
        
        
        /**
         * This is the function that add a  newly initiated project termination request
         */
        public function actioninitiateprojectterminationrequest(){
            
            $model = new ProjectTerminationAndSuspension;
            
            $sol_id = $_REQUEST['sol_id'];
            $model->project_id = $_REQUEST['project_id'];
            
            if($model->isThisProjectAlreadyTerminated($model->project_id) == false){
                $model->type = $_POST['type']; 
               $model->termination_commencement_date = date("Y-m-d H:i:s", strtotime($_POST['termination_commencement_date']));
               $model->termination_cost = $_POST['termination_cost'];
               $model->incrementer = $model->getTheCurrentIncrementedNumber() + 1;
                $model->ref_number = $model->getTheTransRefNumberOfThisProjectTermination($model->project_id,$sol_id, $model->incrementer);
               if(isset($_POST['termination_description'])){
                    $model->description = $_POST['termination_description']; 
               }
               if(isset($_POST['reason_for_termination'])){
                    $model->reason_for_termination = $_POST['reason_for_termination']; 
               }
              $model->date_initiated = new CDbExpression('NOW()');
                $model->initiated_by_id = Yii::app()->user->id;
                
                
                if($model->save()){
                    
                       
                         // $result['success'] = 'true';
                          $msg = "Successfully initiated this Project Termination Request. Approval is pending";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to initiate this Project Termination Request was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                       )
                           );
                    } 
                
            }else{
                //$result['success'] = 'false';
                         $msg = "The project is already terminated. You can only change the termination status of the project";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                       )
                           );
                
            }
               
            
        }
        
        
        
         /**
         * This is the function that modifies  project termination request
         */
        public function actionmodifyprojectterminationrequest(){
            
             $_id = $_POST['id'];
            $model= ProjectTerminationAndSuspension::model()->findByPk($_id);
            
            $sol_id = $_REQUEST['sol_id'];
            $model->project_id = $_REQUEST['project_id'];
            
           
               $model->type = $_POST['type']; 
               $model->termination_commencement_date = date("Y-m-d H:i:s", strtotime($_POST['termination_commencement_date']));
               $model->termination_cost = $_POST['termination_cost'];
               if(isset($_POST['termination_description'])){
                    $model->description = $_POST['termination_description']; 
               }
               if(isset($_POST['reason_for_termination'])){
                    $model->reason_for_termination = $_POST['reason_for_termination']; 
               }
              $model->is_rejected = 0;
               $model->is_approved = 0;
               $model->is_modification_approved = 0;
               $model->date_last_modified = new CDbExpression('NOW()');
               $model->modified_by_id = Yii::app()->user->id;
                
                
                if($model->save()){
                    
                       
                         // $result['success'] = 'true';
                          $msg = "Successfully updated this Project Termination Request. Approval is pending";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update this Project Termination Request was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                       )
                           );
                    } 
                
           
               
            
        }
        
        
        
        /**
         * This is the function that approves project termination request
         */
        public function actionapproveprojectterminationrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectTerminationAndSuspension::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
            $model->is_approved = 1;
            $model->is_modification_approved = 1; 
            $model->is_rejected = 0;
            $model->is_deleted = 0; 
            $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project termination request is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project termination approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
         /**
         * This is the function that rejects project termination request
         */
        public function actionrejectprojectterminationrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectTerminationAndSuspension::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
            $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_rejected = 1;
            //$model->is_deleted = 1; 
            $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project termination request is successfully rejected";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project termination approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        /**
         * This is the function that withdrawa project termination request
         */
        public function actionwithdrawprojectterminationrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectTerminationAndSuspension::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
             $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_deleted = 1; 
             $model->withdrawn_by_id = Yii::app()->user->id;
             $model->date_withdrawn = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project termination request is successfully withdrawn";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project termination withdrawal request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
         /**
         * This is the function that unwithdrawa project termination request
         */
        public function actionunwithdrawprojectterminationrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectTerminationAndSuspension::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
             $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_deleted = 0; 
             $model->withdrawn_by_id = Yii::app()->user->id;
             $model->date_withdrawn = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project termination request is successfully unwithdrawn";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project termination unwithdrawal request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        /**
         * This is the function that unsuspends a project
         */
        public function actionunsuspendprojectterminationrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectTerminationAndSuspension::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
             $model->type = "unsuspend";
            $model->is_approved = 0;
            $model->unsuspendd_by_id = Yii::app()->user->id;
             $model->date_unsuspended = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project termination request is successfully unsuspended";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project termination unsuspension request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        /**
         * This is the function that unfreezes a project
         */
        public function actionunfreezeprojectterminationrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectTerminationAndSuspension::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
             $model->type = "unsuspend";
            $model->is_approved = 0;
            $model->unfreezed_by_id = Yii::app()->user->id;
             $model->date_unfreezed = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project termination request is successfully unfreezed";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project termination unfreeze request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        
        
}
