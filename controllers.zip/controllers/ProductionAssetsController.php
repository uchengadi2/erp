<?php

class ProductionAssetsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listthisorganizationproductionassets','deleteoneProductionAssets','modifyProductionAssets',
                                    'addanewProductionAssets','listthisassetsolbatchseries','listthisasssetsolbatchseriesslots','retrievedetailsofthisseriesslot',
                                    'listallproductionassetsofanorganization'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	     /**
    * This is the function that list all production assets of an organization
    */
     public function actionlistthisorganizationproductionassets(){
         
         $organization_id = $_REQUEST['organization_id'];
         
         
                   
            $data = [];
            $q = "select a.*, b.id as asset_subtype_id, b.name as asset_subtype_name,b.asset_type_id as asset_type_id,b.code as asset_subtype_code,
                (select id from organization where id=a.organization_id) as organization_id,
                (select name from organization where id=a.organization_id) as organization_name,
                c.code as asset_type_code
                from production_assets a
                    JOIN asset_subtype b ON a.asset_subtype_id=b.id
                    JOIN asset_type c ON c.id =b.asset_type_id
                    where a.organization_id =$organization_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "asset"=>$data,
                                  
                            ));
         
     }  
     
     
     
     /**
      * This is the function that add new production asset to an organization
      */
     public function actionaddanewProductionAssets(){
         
         $model = new ProductionAssets;
            
           $model->organization_id = $_POST['organization_id'];
           $model->asset_subtype_id = $_POST['asset_subtype_id'];
             $organization_name = $_POST['organization_name'];
             $asset_subtype_name = $_POST['asset_subtype_name'];
            
               $model->name = $_POST['name']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  '$model->name' production asset to '$organization_name'";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this '$model->name' production asset to '$organization_name' was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
         
     }
     
     
     
     /**
      * This is the function that modifies production asset to an organization
      */
     public function actionmodifyProductionAssets(){
         
         $_id = $_POST['id'];
            
            $model= ProductionAssets::model()->findByPk($_id);
            
           $model->organization_id = $_POST['organization_id'];
           $model->asset_subtype_id = $_POST['asset_subtype_id'];
             $organization_name = $_POST['organization_name'];
             $asset_subtype_name = $_POST['asset_subtype_name'];
            
               $model->name = $_POST['name']; 
               if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
              $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully updated  '$model->name' production asset";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update this '$model->name' production asset was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
         
     }
     
     
     
     /**
         * This is the function that deletes  a production asset
         */
        public function actiondeleteoneProductionAssets(){
            
           $_id = $_POST['id'];
            
            $model= ProductionAssets::model()->findByPk($_id);
            
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' production asset is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
            
        }
        
        
        /**
         * This is the function that list all series of a production asset for a service outlet
         **/
        public function actionlistthisassetsolbatchseries(){
            
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
            $asset_subtype_code = $_REQUEST['asset_subtype_code'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select a.id, a.billboard_batch_unique_number as series_code, a.asset_series_name as series_name from imagineplace_batch_billboard_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
                     $q = "select a.id, a.batched_street_pole_unique_number as series_code, a.batch_series_name as series_name from imagineplace_batched_street_pole_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
                $q = "select a.id, a.advert_batch_property_unique_number as series_code, a.batch_series_name as series_name from imagineplace_advert_batch_property_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
                    $q = "select a.id, a.batched_walldrop_unique_number as series_code, a.asset_series_name as series_name from imagineplace_batched_walldrop_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
                $q = "select a.id, a.batch_sds_unique_number as series_code, a.asset_series_name as series_name from imagineplace_batched_sds_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
                $q = "select a.id, a.charcoal_batch_unique_number as series_code, a.asset_series_name as series_name from agrant_batch_charcoal_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
                $q = "select a.id, a.inventory_batch_livestock_unique_number as series_code, a.asset_series_name as series_name from agrant_inventory_batched_livestock_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
                    $q = "select a.id, a.livestock_batch_unique_number as series_code, a.asset_series_name as series_name from agrant_batched_livestock_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
                $q = "select a.id, a.commodity_batch_unique_number as series_code, a.asset_series_name as series_name from agrant_batched_commodity_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select a.id, a.plantation_acquisition_unique_number as series_code, a.asset_series_name as series_name from agrant_property_plantation_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select a.id, a.series_unique_number as series_code, a.asset_series_name as series_name from fm_building_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select a.id, a.series_unique_number as series_code, a.asset_series_name as series_name from fm_entertainment_park_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                     $q = "select a.id, a.series_unique_number as series_code, a.asset_series_name as series_name from fm_car_park_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }else if($asset_subtype_code == "airport") {
                 $q = "select a.id, a.series_unique_number as series_code, a.asset_series_name as series_name from fm_airport_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                    $q = "select a.id, a.series_unique_number as series_code, a.asset_series_name as series_name from fm_machinery_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                    $q = "select a.id, a.series_unique_number as series_code, a.asset_series_name as series_name from fm_shoppingmail_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                    $q = "select a.id, a.series_unique_number as series_code, a.asset_series_name as series_name from fm_transport_station_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                    $q = "select a.id, a.series_unique_number as series_code, a.asset_series_name as series_name from fm_complex_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

                $q = "select a.id, a.series_unique_number as series_code, a.asset_series_name as series_name from fm_construction_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
        /**
         * This is the function that list all series slots 
         **/
        public function actionlistthisasssetsolbatchseriesslots(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select a.id as id, a.series_slot_name as slot_name, a.billboard_unique_number as slot_code, a.number_of_billboards as number_of_items_in_slot, b.billboard_batch_unique_number as series_code from imagineplace_billboard_asset_slot a
                    JOIN imagineplace_batch_billboard_asset b ON a.billboard_batch_id=b.id
                    where a.billboard_batch_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
              $q = "select a.id as id, a.name as slot_name, a.street_pole_slot_unique_number as slot_code, a.number_of_poles as number_of_items_in_slot, b.batched_street_pole_unique_number as series_code from imagineplace_street_pole_asset_slot a
                JOIN imagineplace_batched_street_pole_asset b ON a.street_pole_batch_id=b.id    
                where a.street_pole_batch_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select a.id as id, a.series_slot_name as slot_name, a.advert_property_unique_number as slot_code, a.quantity as number_of_items_in_slot, b.advert_batch_property_unique_number as series_code from imagineplace_advert_property_asset_slot a
                JOIN imagineplace_advert_batch_property_asset b ON a.batch_property_asset_id=b.id    
                where a.batch_property_asset_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select a.id as id, a.series_slot_name as slot_name, a.walldrop_unique_number as slot_code, a.number_of_walldrop as number_of_items_in_slot, b.batched_walldrop_unique_number as series_code from imagineplace_walldrop_asset_slot a
                JOIN imagineplace_batched_walldrop_asset_series b ON a.batch_walldrop_id=b.id    
                where a.batch_walldrop_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select a.id as id, a.series_slot_name as slot_name, a.sds_unique_number as slot_code, a.number_of_sds as number_of_items_in_slot, b.batch_sds_unique_number as series_code from imagineplace_sds_asset_slot a
                JOIN imagineplace_batched_sds_asset b ON a.batch_sds_id=b.id    
                where a.batch_sds_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select a.id as id, a.slot_name as slot_name, a.charcoal_unique_number as slot_code, a.quantity_in_kg as number_of_items_in_slot, b.charcoal_batch_unique_number as series_code from agrant_charcoal_asset_slot a
                JOIN agrant_batch_charcoal_asset b ON a.charcoal_batch_id=b.id    
                where a.charcoal_batch_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
             $q = "select a.id as id, a.slot_name as slot_name, a.inventory_livestock_unique_number as slot_code, a.number_of_inventory_livestock as number_of_items_in_slot, b.inventory_batch_livestock_unique_number as series_code from agrant_inventory_livestock_asset_slot a
                JOIN agrant_inventory_batched_livestock_asset b ON a.inventory_livestock_batch_id=b.id    
                where a.inventory_livestock_batch_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select a.id as id, a.slot_name as slot_name, a.livestock_unique_number as slot_code, a.number_of_livestock as number_of_items_in_slot, b.livestock_batch_unique_number as series_code from agrant_livestock_asset_slot a
                JOIN agrant_batched_livestock_asset b ON a.livestock_batch_id=b.id    
                where a.livestock_batch_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
              $q = "select a.id as id, a.slot_name as slot_name, a.commodity_unique_number as slot_code, a.quantity_in_kg as number_of_items_in_slot, b.commodity_batch_unique_number as series_code from agrant_commodity_asset_slot a
                JOIN agrant_batched_commodity_asset b ON a.commodity_batch_id=b.id    
                where a.commodity_batch_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_plants as number_of_items_in_slot, b.plantation_acquisition_unique_number as series_code from agrant_property_plantation_asset_slot a
                JOIN agrant_property_plantation_asset b ON a.plantation_id=b.id    
                where a.plantation_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code from fm_building_asset_series_slot a
                JOIN fm_building_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code from fm_entertainment_park_asset_series_slot a
                JOIN fm_entertainment_park_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                   $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code from fm_car_park_asset_series_slot a
                JOIN fm_car_park_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }else if($asset_subtype_code == "airport") {
                  $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code from fm_airport_asset_series_slot a
                JOIN fm_airport_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code from fm_machinery_asset_series_slot a
                JOIN fm_machinery_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                     $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code from fm_shoppingmail_asset_series_slot a
                JOIN fm_shoppingmail_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                    $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code from fm_transport_station_asset_series_slot a
                JOIN fm_transport_station_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                   $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code from fm_complex_asset_series_slot a
                JOIN fm_complex_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

                $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_stocks as number_of_items_in_slot, b.series_unique_number as series_code from fm_construction_asset_series_slot a
                JOIN fm_construction_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
        
        
        /**
         * This is the function that list all series slots 
         **/
        public function actionretrievedetailsofthisseriesslot(){
            
            $asset_series_id = $_REQUEST['series_id'];
            $asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            $slot_id = $_REQUEST['slot_id'];
            
            $data = [];
            
            if($asset_subtype_code == "billboard"){
                    $q = "select a.id as id, a.series_slot_name as slot_name, a.billboard_unique_number as slot_code, a.number_of_billboards as number_of_items_in_slot,
                        a.billboard_batch_unique_number as series_code, b.short_description as description, a.quantity_of_assets_in_place_or_warehouse from imagineplace_billboard_asset_slot a
                    JOIN imagineplace_batch_billboard_asset b ON a.billboard_batch_id=b.id
                    where a.billboard_batch_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));


            }else if($asset_subtype_code == "streetpoles") {
              $q = "select a.id as id, a.name as slot_name, a.street_pole_slot_unique_number as slot_code, a.number_of_poles as number_of_items_in_slot, b.batched_street_pole_unique_number as series_code,
                  a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from imagineplace_street_pole_asset_slot a
                JOIN imagineplace_batched_street_pole_asset b ON a.street_pole_batch_id=b.id    
                where a.street_pole_batch_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "advertproperty") {
              $q = "select a.id as id, a.series_slot_name as slot_name, a.advert_property_unique_number as slot_code, a.quantity as number_of_items_in_slot, b.advert_batch_property_unique_number as series_code,
                  a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from  imagineplace_advert_property_asset_slot a
                JOIN imagineplace_advert_batch_property_asset b ON a.batch_property_asset_id=b.id    
                where a.batch_property_asset_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "walldrips") {
              $q = "select a.id as id, a.series_slot_name as slot_name, a.walldrop_unique_number as slot_code, a.number_of_walldrop as number_of_items_in_slot, b.batched_walldrop_unique_number as series_code,
                  a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from imagineplace_walldrop_asset_slot a
                JOIN imagineplace_batched_walldrop_asset_series b ON a.batch_walldrop_id=b.id    
                where a.batch_walldrop_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "streetdirectionalsign") {
              $q = "select a.id as id, a.series_slot_name as slot_name, a.sds_unique_number as slot_code, a.number_of_sds as number_of_items_in_slot, b.batch_sds_unique_number as series_code,
                  a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from imagineplace_sds_asset_slot a
                JOIN imagineplace_batched_sds_asset b ON a.batch_sds_id=b.id    
                where a.batch_sds_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "charcoal") {
              $q = "select a.id as id, a.slot_name as slot_name, a.charcoal_unique_number as slot_code, a.quantity_in_kg as number_of_items_in_slot, b.charcoal_batch_unique_number as series_code,
                  a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from agrant_charcoal_asset_slot a
                JOIN agrant_batch_charcoal_asset b ON a.charcoal_batch_id=b.id    
                where a.charcoal_batch_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "inventory_livestock") {
             $q = "select a.id as id, a.slot_name as slot_name, a.inventory_livestock_unique_number as slot_code, a.number_of_inventory_livestock as number_of_items_in_slot, b.inventory_batch_livestock_unique_number as series_code,
                 a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from agrant_inventory_livestock_asset_slot a
                JOIN agrant_inventory_batched_livestock_asset b ON a.inventory_livestock_batch_id=b.id    
                where a.inventory_livestock_batch_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "livestock") {
              $q = "select a.id as id, a.slot_name as slot_name, a.livestock_unique_number as slot_code, a.number_of_livestock as number_of_items_in_slot, b.livestock_batch_unique_number as series_code,
                  a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from agrant_livestock_asset_slot a
                JOIN agrant_batched_livestock_asset b ON a.livestock_batch_id=b.id    
                where a.livestock_batch_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "commodity") {
              $q = "select a.id as id, a.slot_name as slot_name, a.commodity_unique_number as slot_code, a.quantity_in_kg as number_of_items_in_slot, b.commodity_batch_unique_number as series_code,
                  a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from agrant_commodity_asset_slot a
                JOIN agrant_batched_commodity_asset b ON a.commodity_batch_id=b.id    
                where a.commodity_batch_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "plantation") {
                $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_plants as number_of_items_in_slot, b.plantation_acquisition_unique_number as series_code,
                    a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from agrant_property_plantation_asset_slot a
                JOIN agrant_property_plantation_asset b ON a.plantation_id=b.id    
                where a.plantation_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "building") {
              
              $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code,
                  a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from fm_building_asset_series_slot a
                JOIN fm_building_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "entertainment_park") {
                $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code,
                    a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from fm_entertainment_park_asset_series_slot a
                JOIN fm_entertainment_park_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "car_park") {

                   $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code,
                       a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from fm_car_park_asset_series_slot a
                JOIN fm_car_park_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }else if($asset_subtype_code == "airport") {
                  $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code,
                      a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from fm_airport_asset_series_slot a
                JOIN fm_airport_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "machinery") {
                     $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code,
                         a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from fm_machinery_asset_series_slot a
                JOIN fm_machinery_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "shopping_mall") {
                     $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code,
                         a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from fm_shoppingmail_asset_series_slot a
                JOIN fm_shoppingmail_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "transport_station") {
                    $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code,
                        a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from fm_transport_station_asset_series_slot a
                JOIN fm_transport_station_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "complex") {
                   $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_sections as number_of_items_in_slot, b.series_unique_number as series_code,
                       a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from fm_complex_asset_series_slot a
                JOIN fm_complex_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));

            }else if($asset_subtype_code == "construction") {

                $q = "select a.id as id, a.slot_name as slot_name, a.slot_unique_number as slot_code, a.number_of_stocks as number_of_items_in_slot, b.series_unique_number as series_code,
                    a.short_description as description, a.quantity_of_assets_in_place_or_warehouse from fm_construction_asset_series_slot a
                JOIN fm_construction_asset_series b ON a.asset_series_id=b.id    
                where a.asset_series_id =$asset_series_id and a.id=$slot_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            }
                    
        }
        
        
        
   
        
        
        
}
