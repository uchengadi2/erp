<?php

class ServiceOuletHasUserController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addusertothisserviceoutlet','retrieveserviceoutletforauser'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that adds a user to a service outlet
         */
        public function actionaddusertothisserviceoutlet(){
            
            $model = new ServiceOuletHasUser;
            
            $user_id = $_POST['id'];
            $service_outlet_id = $_POST['service_outlet_id'];
            $name = $_POST['name'];
            
            if($model->isTheDeactivationOfUserOtherSolAccountASuccess($user_id,$service_outlet_id)){
                $model->user_id = $user_id;
                $model->service_outlet_id = $service_outlet_id;
                $model->status = "active";
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                
                 if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  '$name' to this service outlet";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add '$name' to this service outlet was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                
            }else{
                 //$result['success'] = 'false';
                         $msg = "Could not deactivate this user's account from other service outlet(s) hence this operation was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                
            }
            
            
        }
        
        
        /**
         * This is the function that retrieves a user's info about its service outlet
         */
        public function actionretrieveserviceoutletforauser(){
            
            $model = new ServiceOutlet;
            
            $user_id = $_REQUEST['user_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='user_id=:userid and status="active"';
            $criteria->params = array(':userid'=>$user_id);
            $user= ServiceOuletHasUser::model()->find($criteria);
            
            if($user == null){
                
                $service_outlet = "";
                $branch = "";
            }else{
               $service_outlet =  $model->getTheNameOfThisServiceOutlet($user['service_outlet_id']);
               $branch = $this->getTheNameOfThisServiceOutletBranch($user['service_outlet_id']);
            }
            
            header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "service_outlet" => $service_outlet,
                                        "branch"=>$branch)
                           );
            
            
            
            
        }
        
        
        /**
         * This is the function that retrieves the name of a branch
         */
        public function getTheNameOfThisServiceOutletBranch($service_outlet_id){
            
            $model = new ServiceOutlet;
            return $model->getTheNameOfThisServiceOutletBranch($service_outlet_id);
            
        }
}
