<?php

class ServiceOutletController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listbranchserviceoutlets','deleteoneServiceOutlet','addanewServiceOutlet','modifyServiceOutlet',
                                    'listorganizationserviceoutlets'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that list branch all service outlets
         */
        public function actionlistbranchserviceoutlets(){
            
            $branch_id = $_REQUEST['branch_id'];
            
            $data = [];
            $q = "select a.*, b.id as branch_id,b.name as branch_name, c.name as location_name from service_outlet a
                    JOIN branch b ON a.branch_id=b.id
                    JOIN location c ON b.location_id=c.id
                     where a.branch_id =$branch_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "outlet"=>$data,
                                  
                            ));
            
        }
        
        
        
        
        /**
         * This is the function that list organization all service outlets
         */
        public function actionlistorganizationserviceoutlets(){
            
            $organization_id = $_REQUEST['organization_id'];
            
            $data = [];
            $q = "select a.*, b.id as branch_id,b.name as branch_name, c.name as location_name, d.id as organization_id, d.name as organization_name from service_outlet a
                    JOIN branch b ON a.branch_id=b.id
                    JOIN location c ON b.location_id=c.id
                    JOIN organization d ON c.organization_id=d.id
                     where d.id =$organization_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "outlet"=>$data,
                                  
                            ));
            
        }
        
        
        
        /**
         * This is the function that adds a new service outlet
         */
        public function actionaddanewServiceOutlet(){
            
            $model = new ServiceOutlet;
            
            $branch_name = $_POST['branch_name'];
            //$location_name = $_POST['location_name'];
            $model->name = $_POST['name'];
            $model->branch_id = $_POST['branch_id']; 
            $model->solid = $_POST['solid']; 
           if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
           if(isset($_POST['address'])){
                    $model->address = $_POST['address']; 
               }    
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
             if($model->isSolIdExist($model->solid,$model->branch_id)== false){   
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  the '$model->solid' Service Outlet ID to the selected '$branch_name' branch";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this '$model->solid' Service Outlet ID to the '$branch_name' branch was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                    
             }else{
                  $msg = "This service outlet ID  is already created for this branch and cannot be duplicated";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    
                 
             }
            
        }
        
        
        
        /**
         * This is the function that modifies service outlet
         */
        public function actionmodifyServiceOutlet(){
            
            $_id = $_POST['id'];
            
            $model= ServiceOutlet::model()->findByPk($_id);
            
            $branch_name = $_POST['branch_name'];
           // $location_name = $_POST['location_name'];
            $model->name = $_POST['name'];
            $model->branch_id = $_POST['branch_id']; 
            $model->solid = $_POST['solid']; 
           if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
           if(isset($_POST['address'])){
                    $model->address = $_POST['address']; 
               }    
              $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
             if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "Successfully added  the '$model->solid' Service Outlet ID to the selected '$branch_name' branch";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to add this '$model->solid' Service Outlet ID to the '$branch_name' branch was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                    
           
        }
        
        
        
        /**
         * This is the function that deletes a service outlet
         */
        public function actiondeleteoneServiceOutlet(){
            
             $_id = $_POST['id'];
            
            $model= ServiceOutlet::model()->findByPk($_id);
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->solid' Service Outlet ID is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
            
        }
}
