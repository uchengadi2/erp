<?php

class AgrantPropertyBatchedPondsAssetController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listthisolfishpondbatchseries','listthisolunapprovedfishpondbatchseries',
                                    'listthisoldeletedfishpondbatchseries','listthisolforadjustmentfishpondbatchseries'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all fish pond batch series
         */
        public function actionlistthisolfishpondbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from agrant_property_batched_ponds_asset a
                    where a.sol_id =$sol_id and (is_deleted=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
          /**
         * This is the function that list all unapproved fish pond batch series in a sol
         */
        public function actionlistthisolunapprovedfishpondbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from agrant_property_batched_ponds_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
         /**
         * This is the function that list all deleted fish pond batch series in a sol
         */
        public function actionlistthisoldeletedfishpondbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from agrant_property_batched_ponds_asset a
                    where a.sol_id =$sol_id and (is_deleted=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
         /**
         * This is the function that list all for adjustment fish pond batch series in a sol
         */
        public function actionlistthisolforadjustmentfishpondbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from agrant_property_batched_ponds_asset a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
}
