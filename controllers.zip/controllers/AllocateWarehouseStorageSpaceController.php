<?php

class AllocateWarehouseStorageSpaceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','allocatewarehouseandplacetoserviceoutlet','listserviceoutletunapprovedselfallocatedspaces',
                                    'approveallocatedwarehouseandplace','listthissolapprovedallocatedwarehousesandplaces','changestatusofallocatedwarehouseandplace',
                                    'listthissolapprovedownallocatedwarehousesandplaces','setcommencementdateonallocatedwarehouseandplace','retrieveallocatedwarehouseandplace',
                                    'retrievethissolallocatedwarehousesandplacesforequisition'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function that allocates warehouse and places spaces to service outlets
         */
        public function actionallocatewarehouseandplacetoserviceoutlet(){
            
            $model = new AllocateWarehouseStorageSpace;
            
            $name = $_POST['warehouse_and_place'];
            $service_outlet_id = $_POST['service_outlet'];
            $organization_id = $_POST['organization_id'];
            $sol_name = $this->getTheNameOfThisServiceOutlet($service_outlet_id);
            $remaining_storage_capacity_in_cubic_feet = $_POST['remaining_storage_capacity_in_cubic_feet'];
            $storage_preference = $_POST['storage_preference'];
            $model->warehouse_id = $_POST['warehouse_id'];
            $model->service_outlet_id =$service_outlet_id;
            if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
               }
            $model->allocation_duration_in_weeks = $_POST['allocation_duration_in_weeks'];
            $model->allocation_status = $_POST['allocation_status'];
            $model->warehouse_gl_id = $_POST['warehouse_gl_id'];
            $model->allocation_cost = $_POST['allocation_cost'];
            $model->is_approved = 0;
            $model->date_initiated = new CDbExpression('NOW()');
            $model->initiated_by_id = Yii::app()->user->id;   
           if($storage_preference == 1){
                if($model->isThisServiceOuletalreadyWithAllocation($model->warehouse_id,$service_outlet_id) == false){
             
              $model->allocated_storage_capacity_in_cubic_feet = $_POST['allocated_storage_capacity_in_cubic_feet'];
              if($remaining_storage_capacity_in_cubic_feet>=$model->allocated_storage_capacity_in_cubic_feet){
                   
                    
                    //calculate the new remaining space
                    $new_remaining_space = $remaining_storage_capacity_in_cubic_feet - $model->allocated_storage_capacity_in_cubic_feet;
                if($model->save()){
                        //deduct the allocaed space from the remaining spaces
                        $this->recalculateWarehouseAndPlaceRemainingSpace($model->warehouse_id, $new_remaining_space);
                         // $result['success'] = 'true';
                          $msg = "Successfully allocated this Warehouse and Place space capacity to '$sol_name' service outlet";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to allocate Warehouse and Place space capacity  to '$sol_name' service outlet was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                  
                  
              }else{
                   //$result['success'] = 'false';
                         $msg = "You cannot allocate more space capacity than is available. Please correct that and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  
                  
              }
                
                
            }else{
                 //$result['success'] = 'false';
                         $msg = "This service outlet already has an allocation of this warehouse and place and therefore your request cannot be processed.";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                
                
            }
               
           }else{
                if($model->isThisServiceOuletalreadyWithAllocation($model->warehouse_id,$service_outlet_id) == false){
                    if($model->save()){
                       
                         // $result['success'] = 'true';
                          $msg = "Successfully allocated this Warehouse and Place space capacity to '$sol_name' service outlet";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to allocate Warehouse and Place space capacity  to '$sol_name' service outlet was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                    
                }else{
                    //$result['success'] = 'false';
                         $msg = "This service outlet already has an allocation of this warehouse and place and therefore your request cannot be processed.";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    
                    
                }
               
               
               
           }      
            
             
               
            
        }
        
        
        /**
         * This is the function that recalculates the remaining available space for a warehouse or place
         */
        public function recalculateWarehouseAndPlaceRemainingSpace($warehouse_id, $new_remaining_space){
            $model = new WarehouseAndPlace;
            return $model->recalculateWarehouseAndPlaceRemainingSpace($warehouse_id, $new_remaining_space);
            
        }
        
        /**
         * This is the function that gets the name of a service outlet
         */
        public function getTheNameOfThisServiceOutlet($service_outlet_id){
            $model = new ServiceOutlet;
            return $model->getTheNameOfThisServiceOutlet($service_outlet_id);
        }
        
        
        /**
         * This is the function that list all unapproved self allocated warehouse and places spaces
         */
        public function actionlistserviceoutletunapprovedselfallocatedspaces(){
            
          $organization_id = $_REQUEST['organization_id'];
            $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as warehouse_and_place, c.name as location,d.name as owner_organization_name,d.id as owner_organization_id,
                (select name from organization where id = a.organization_id) as organization_name,
                (select name from service_outlet where id=a.service_outlet_id)as service_outlet,
                (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as is_for_storage,
                (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                (select type from warehouse_and_place where id=a.warehouse_id) as type,
                (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet
                from allocate_warehouse_storage_space a
                    JOIN warehouse_and_place b ON a.warehouse_id=b.id
                    JOIN location c ON b.location_id=c.id
                    JOIN organization d ON c.organization_id=d.id
                    where (a.is_approved = 0 and b.service_outlet_owner_id=$sol_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "spaces"=>$data,
                                  
                            ));
            
        }
        
        
        
        
        /**
         * This is the function that list all approved allocated warehouse and places spaces
         */
        public function actionlistthissolapprovedallocatedwarehousesandplaces(){
            
          $organization_id = $_REQUEST['organization_id'];
            $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as warehouse_and_place, c.name as location,d.name as owner_organization_name,d.id as owner_organization_id,
                (select name from organization where id = a.organization_id) as organization_name,
                (select name from service_outlet where id=a.service_outlet_id)as service_outlet,
                (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as is_for_storage,
                (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                (select type from warehouse_and_place where id=a.warehouse_id) as type,
                (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet
                from allocate_warehouse_storage_space a
                    JOIN warehouse_and_place b ON a.warehouse_id=b.id
                    JOIN location c ON b.location_id=c.id
                    JOIN organization d ON c.organization_id=d.id
                    where (a.is_approved = 1 and b.service_outlet_owner_id=$sol_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "spaces"=>$data,
                                  
                            ));
            
        }
        
        
        
        
         /**
         * This is the function that list all approved own allocated warehouse and places spaces
         */
        public function actionlistthissolapprovedownallocatedwarehousesandplaces(){
            
          $organization_id = $_REQUEST['organization_id'];
            $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as warehouse_and_place, c.name as location,d.name as owner_organization_name, d.id as owner_organization_id,
                (select name from organization where id = a.organization_id) as organization_name,
                (select name from service_outlet where id=a.service_outlet_id)as service_outlet,
                (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as is_for_storage,
                (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                (select type from warehouse_and_place where id=a.warehouse_id) as type,
                (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet
                from allocate_warehouse_storage_space a
                    JOIN warehouse_and_place b ON a.warehouse_id=b.id
                    JOIN location c ON b.location_id=c.id
                    JOIN organization d ON c.organization_id=d.id
                    where (a.is_approved = 1 and a.service_outlet_id=$sol_id)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "spaces"=>$data,
                                  
                            ));
            
        }
        
        
        
        /**
         * This is the function that approves a warehouse and place allocation
         */
        public function actionapproveallocatedwarehouseandplace(){
            
            $_id = $_POST['id'];
            $model= AllocateWarehouseStorageSpace::model()->findByPk($_id);
            
            $name = $this->getTheNameOfThisWarehouseAndPlace($model->warehouse_id);
                      
             $model->is_approved = 1; 
             $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$name' Warehouse or Place is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        
        /**
         * This is the function that changes the status of a warehouse and place
         */
        public function actionchangestatusofallocatedwarehouseandplace(){
            
            $_id = $_POST['id'];
            $model= AllocateWarehouseStorageSpace::model()->findByPk($_id);
            
            $name = $this->getTheNameOfThisWarehouseAndPlace($model->warehouse_id);
                      
             $model->allocation_status = $_REQUEST['allocation_status'];
             //$model->approved_by_id = Yii::app()->user->id;
             //$model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The Status of '$name' Warehouse or Place is successfully changed";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        
        /**
         * This is the function that sets commencement date on allocated warehouse and place
         */
        public function actionsetcommencementdateonallocatedwarehouseandplace(){
            
            $_id = $_POST['id'];
            $model= AllocateWarehouseStorageSpace::model()->findByPk($_id);
            
            $name = $this->getTheNameOfThisWarehouseAndPlace($model->warehouse_id);
                      
             $model->allocation_commencement_date = date("Y-m-d H:i:s", strtotime($_POST['allocation_commencement_date']));
             
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The Commencement Date  of '$name' Warehouse or Place is successfully set";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        /**
         * this is the function that gets the name of a warehouse and place
         */
        public function getTheNameOfThisWarehouseAndPlace($warehouse_id){
            $model = new WarehouseAndPlace;
            return $model->getTheNameOfThisWarehouseAndPlace($warehouse_id);
            
        }
        
        
        
        
         /**
         * This is the function that retrieve an allocated warehouse and places spaces
         */
        public function actionretrieveallocatedwarehouseandplace(){
            
          $warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
           $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.*, b.name as warehouse_and_place,b.type as type, b.is_for_storage as purpose,b.remaining_storage_capacity_in_cubic_feet as remaining_storage_capacity_in_cubic_feet,
                c.name as location,d.name as owner_organization_name,d.id as owner_organization_id,
                (select name from organization where id = a.organization_id) as organization_name,
                (select name from service_outlet where id=a.service_outlet_id)as service_outlet,
                (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as is_for_storage,
                (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                (select type from warehouse_and_place where id=a.warehouse_id) as type,
                (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet
                from allocate_warehouse_storage_space a
                    JOIN warehouse_and_place b ON a.warehouse_id=b.id
                    JOIN location c ON b.location_id=c.id
                    JOIN organization d ON c.organization_id=d.id
                    where (a.is_approved = 1 and b.service_outlet_owner_id=$sol_id) and a.warehouse_id= $warehouse_and_place_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "space"=>$data,
                                  
                            ));
            
        }
        
        
        /**
         * This is the function that list all approved allocated warehouse and places spaces that are ready for requisition
         */
        public function actionretrievethissolallocatedwarehousesandplacesforequisition(){
            $data= [];
        $warehouse_and_place_id = $_REQUEST['warehouse_and_place_id'];
           $sol_id = $_REQUEST['sol_id'];
            
            $q = "select a.*,b.allocated_storage_capacity_in_cubic_feet as allocated_storage_capacity_in_cubic_feet, b.quantity_of_assets_in_capacity as quantity_of_assets_in_capacity,b.id as assignment_id,
                b.warehousing_allocation_cost as warehousing_allocation_cost, b.warehousing_duration_in_weeks as warehousing_duration_in_weeks,b.description as warehouse_descrioption,b.sku,
                         (select remaining_storage_capacity_in_cubic_feet from warehouse_and_place where id=a.warehouse_id) as remaining_storage_capacity_in_cubic_feet,
                         (select type from warehouse_and_place where id=a.warehouse_id) as type,
                         (select name from warehouse_and_place where id=a.warehouse_id) as warehouse_and_place,
                         (select is_for_storage from warehouse_and_place where id=a.warehouse_id) as purpose,
                         (select name from location where id =(select location_id from warehouse_and_place where id=a.warehouse_id)) as location
                         from allocate_warehouse_storage_space a
                         JOIN asset_in_warehouse_and_place b ON a.id=b.warehouse_and_place_allocation_id
                         where (a.service_outlet_id =$sol_id and b.is_approved=1) and a.warehouse_id=$warehouse_and_place_id
                     group by b.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "space"=>$data,
                                    "lenght" => sizeof($data)
                                  
                            ));
            
        }
}
