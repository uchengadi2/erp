<?php

class CityController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllCitiesInThisState','addnewcity','updatecity','deleteonecity','listAllCities'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all states in a country
         */
        public function actionlistAllCitiesInThisState(){
            $model = new City;
            
            $state_id = $_REQUEST['state_id'];
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='state_id=:id';
              $criteria->params = array(':id'=>$state_id);
              $city= City::model()->findAll($criteria);
              if($city===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "city" => $city,
                                   
                    
                            ));
                       
                       
                }
            
        }
        
        
        /**
         * This is the function that adds new city to a state
         */
        public function actionaddnewcity(){
            
            $model = new City;
            $model->name = $_POST['name'];
                $model->state_id = $_POST['state_id'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                //$model->type = $_POST['type'];
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created new city';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'New city creation was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
        /**
         * This is the function that modifies ezisting city information
         */
        public function actionupdatecity(){
            
            //get the state id
            $state= $_POST['state_id'];
         
            $_id = $_POST['id'];
            
            $model=City::model()->findByPk($_id);
            $model->name = $_POST['name'];
            $model->state_id = $state;
           if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
              // $model->type = $_POST['type'];  
            $model->update_time = new CDbExpression('NOW()');
            //$model->update_user_id = Yii::app()->user->id;
            if($model->save()){
                       // $data['success'] = 'true';
                        $msg = 'City information successfully updated';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                   // $data['success'] = 'false';
                    $msg = 'City information update was unsuccessful';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                }
        }
        
        
        
        /**
	 * Deletes a particular model instance
	 * 
         **/
	public function actiondeleteonecity()
	{
            
            $_id = $_POST['id'];
            $model=City::model()->findByPk($_id);
            
                       
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' city is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
        
        
        /**
         * This is the function that list all cities in the marketplace
         */
        public function actionlistAllCities(){
            $cities = City::model()->findAll();
                if($cities===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "city" => $cities)
                           );
                       
                }
        }
}
