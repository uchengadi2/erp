<?php

class CorporateClientController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listthisorganizationcorporateclients','addnewcorporateclient','modifycorporateclient',
                                    'deleteonecorporateclient','listthisorganizationdeletedcorporateclients','undeletethiscorporateclient','listallcorporateclients',
                                    'listallcorporateclients'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all corporate clients for an organization
         */
        public function actionlistthisorganizationcorporateclients(){
            
            $organization_id = $_REQUEST['organization_id'];
            
            $data = [];
            $q = "select a.*, b.name as sector_name, c.name as organization_name from corporate_client a
                    JOIN sector b ON b.id=a.sector_id
                     JOIN organization c ON c.id=b.organization_id
                     where b.organization_id =$organization_id and a.is_deleted=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "client"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        /**
         * This is the function that adds new corporate client
         */
        public function actionaddnewcorporateclient(){
            
            $model = new CorporateClient;
            $model->name = $_POST['name'];
            $model->sector_id = $_POST['sector_id'];
            $model->email = $_POST['email']; 
            $model->regno = $_POST['regno'];
            $model->address = $_POST['address'];
            $model->phone_number = $_POST['phone_number'];
            $model->tax_identification_pin = $_POST['tax_identification_pin'];
            $model->vat_number = $_POST['vat_number']; 
            $model->contact_person_name = $_POST['contact_person_name'];
            $model->contact_person_mobile_number = $_POST['contact_person_mobile_number'];
            $model->contact_person_email = $_POST['contact_person_email'];
            $model->clientid = $model->generateThisClientID();
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully added a new Client';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The addition of this new client was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
        /**
         * This is the function that modifies corporate client
         */
        public function actionmodifycorporateclient(){
            
             $_id = $_POST['id'];
            
            $model= CorporateClient::model()->findByPk($_id);
            $model->name = $_POST['name'];
            $model->sector_id = $_POST['sector_id'];
            $model->email = $_POST['email']; 
            $model->regno = $_POST['regno'];
            $model->address = $_POST['address'];
            $model->phone_number = $_POST['phone_number'];
            $model->tax_identification_pin = $_POST['tax_identification_pin'];
            $model->vat_number = $_POST['vat_number']; 
            $model->contact_person_name = $_POST['contact_person_name'];
            $model->contact_person_mobile_number = $_POST['contact_person_mobile_number'];
            $model->contact_person_email = $_POST['contact_person_email'];
            //$model->clientid = $model->generateThisClientID();
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully added a new sector';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The addition of this new corporate client was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        /**
	 * This is the function that deletes a client
	 */
	public function actiondeleteonecorporateclient()
	{
            $_id = $_POST['id'];
            $model= CorporateClient::model()->findByPk($_id);
            
             $model->is_deleted = 1;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' sector is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        
         /**
	 * This is the function that undeletes a sector
	 */
	public function actionundeletethiscorporateclient()
	{
            $_id = $_POST['client'];
            $model= CorporateClient::model()->findByPk($_id);
            
             $model->is_deleted = 0;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' sector is successfully undeleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        /**
         * This is the function that list all corporate clients for an organization
         */
        public function actionlistthisorganizationdeletedcorporateclients(){
            
            $organization_id = $_REQUEST['organization_id'];
            
            $data = [];
            $q = "select a.*, b.name as sector_name, c.name as organization_name from corporate_client a
                    JOIN sector b ON b.id=a.sector_id
                     JOIN organization c ON c.id=b.organization_id
                     where b.organization_id =$organization_id and a.is_deleted=1
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "client"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        /**
         * This is the function that list all clients on the platform
         */
        public function actionlistallcorporateclients(){
            
            $clients = CorporateClient::model()->findAll();
                if($clients===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "client" => $clients,
                                   
                    
                            ));
                       
                }
        }
        
        
        
        
        
}
