<?php

class ImagineplaceWalldropAssetSlotController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllSlotsInThisBatchSeries','addnewwalldripassetslottoseries','modifywalldripassetslottoseries'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all series slots in a batch
         */
        public function actionlistAllSlotsInThisBatchSeries(){
            $model = new ImagineplaceWalldropAssetSlot;
            
            $batch_series_id = $_REQUEST['batch_series_id'];
        // $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from imagineplace_walldrop_asset_slot a
                    where a.batch_walldrop_id =$batch_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "asset"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that adds a new slot to a batch series
         */
        public function actionaddnewwalldripassetslottoseries(){
            
            
            $model = new ImagineplaceWalldropAssetSlot;
           
           $model->batch_walldrop_id = $_REQUEST['active_batch_series_id'];
            
           $model->series_slot_name = $_POST['series_slot_name'];
           $model->number_of_walldrop = $_POST['number_of_walldrip'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
           $model->dimension_height = $_POST['dimension_height'];
           $model->dimension_width = $_POST['dimension_width'];
           $model->walldrop_type = $_POST['walldrop_type'];
            $model->property_type = $_POST['property_type'];
            $model->slot_gl_id = $_POST['slot_gl_id'];
           $model->total_cost = $_POST['total_cost'];
           $model->delivery_cost = $_POST['delivery_cost'];
           $model->average_cost_per_unit =(double)$model->total_cost/(double)$model->number_of_walldrop;
                      
           $batched_walldrop_unique_number = $_POST['batched_walldrop_unique_number'];
           
           $model->walldrop_unique_number = $model->generateThisSlotUniqueNumber($batched_walldrop_unique_number);
           
          $model->series_slot_incrementer = (int)$model->getTheCurrentIncrementedNumber() + 1;
          
          $batch_series_remaining_slot = $this->retrieveTheRemainingBatchSlot($model->batch_walldrop_id);
          
          if($batch_series_remaining_slot>0){
              
              if($model->save()){
               
                        //reduce the remaining numbe of batches column in the batch series table
                        $new_batch_series_remaining_slot = $this->reduceTheRemainNumberOfBatchSeries($model->batch_walldrop_id);
                        
                        
                         // $result['success'] = 'true';
                          $msg = 'Successfully added new slot to this  Wall Drip Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                               )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to create this slot in this Wall Drip Batch Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            )
                           );
                    } 
              
              
          }else{
               $msg = 'There is no more slot for this batch series as it had been exhausted';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            )
                           );
              
          }
          
           
            
        }
        
        
        /**
         * This is the function that reduces the remaining number of batch series
         */
        public function reduceTheRemainNumberOfBatchSeries($walldrip_batch_id){
            $model = new ImagineplaceBatchedWalldropAssetSeries;
            return $model->reduceTheRemainNumberOfBatchSeries($walldrip_batch_id);
        }
        
        
        
         /**
         * This is the function that retrieves the remaining number of batch series
         */
        public function retrieveTheRemainingBatchSlot($walldrip_batch_id){
            $model = new ImagineplaceBatchedWalldropAssetSeries;
            return $model->retrieveTheRemainingBatchSlot($walldrip_batch_id);
        }
        
        
        
        
        /**
         * This is the function that modifies a slot in a  batch series
         */
        public function actionmodifywalldripassetslottoseries(){
            
                  
          $_id = $_POST['id'];
          $model= ImagineplaceWalldropAssetSlot::model()->findByPk($_id);   
           
           $model->batch_walldrop_id = $_REQUEST['active_batch_series_id'];
            
           $model->series_slot_name = $_POST['series_slot_name'];
           $model->number_of_walldrop = $_POST['number_of_walldrip'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
           
           $model->dimension_height = $_POST['dimension_height'];
           $model->dimension_width = $_POST['dimension_width'];
           $model->walldrop_type = $_POST['walldrop_type'];
           $model->property_type = $_POST['property_type'];
            
           $model->slot_gl_id = $_POST['slot_gl_id'];
           $model->total_cost = $_POST['total_cost'];
           $model->delivery_cost = $_POST['delivery_cost'];
           $model->average_cost_per_unit =(double)$model->total_cost/(double)$model->number_of_walldrop;
          
                        
              if($model->save()){
               
                                              
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated slot in this  Wall Drip Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                               )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to update this slot in this Wall Drip Btach Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            )
                           );
                    } 
              
              
          }
        
}
