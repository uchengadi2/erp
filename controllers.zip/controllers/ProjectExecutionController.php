<?php

class ProjectExecutionController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listprojectallinitiatedexecutions','listprojectallmodifiedexecutions','listprojectallunapprovedexecutions',
                                    'listprojectallapprovedexecutions','listprojectallforwithdrawalexecutions','initiateprojectexecutionrequest',
                                    'modifyprojectexecutionrequest','rejectprojectexecutionrequest','approveprojectexecutionrequest','withdrawprojectexecutionrequest',
                                    'unwithdrawprojectexecutionrequest'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all newly initiated peoject executions
         */
        public function actionlistprojectallinitiatedexecutions(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as execution_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,c.name as service_outlet,c.id as sol_id
                  from project_execution a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and (a.is_approved=0 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that list all modified  project executions request
         */
        public function actionlistprojectallmodifiedexecutions(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as execution_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,b.commencement_date,c.name as service_outlet,c.id as sol_id
                  from project_execution a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and a.is_deleted=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
        }
        
        
        
        
        /**
         * This is the function that list all unapproved  project executions request
         */
        public function actionlistprojectallunapprovedexecutions(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as execution_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,b.commencement_date,c.name as service_outlet,c.id as sol_id
                  from project_execution a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and (a.is_approved=0 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
        }
        
        
        
         /**
         * This is the function that list all approved  project executions request
         */
        public function actionlistprojectallapprovedexecutions(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as execution_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,b.commencement_date,c.name as service_outlet,c.id as sol_id
                  from project_execution a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and (a.is_approved=1 and a.is_deleted=0) and a.is_rejected=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
        }
        
        
        
        /**
         * This is the function that list all for withdrawn  project executions request
         */
        public function actionlistprojectallforwithdrawalexecutions(){
            
            $project_id = $_REQUEST['project_id'];
            $sol_id = $_REQUEST['sol_id'];
            $organization_id = $_REQUEST['organization_id'];
                    
            
            $data = [];
            $q = "select a.*, a.description as execution_description,b.id as project_id, b.name as project_name, b.description, b.commencement_date, b.service_outlet_id,
                b.objective, b.project_number, b.project_gl_id, b.duration, b.sponsor, b.project_manager,b.commencement_date,c.name as service_outlet,c.id as sol_id
                  from project_execution a
                    JOIN project b ON a.project_id=b.id
                    JOIN service_outlet c ON b.service_outlet_id=c.id
                     where (a.project_id=$project_id) and (a.is_approved=0 and a.is_rejected=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "project"=>$data,
                                  
                            ));
            
        }
        
        
        
        /**
         * This is the function that initiates a  new projects execution
         */
        public function actioninitiateprojectexecutionrequest(){
            
            
            $model = new ProjectExecution;
            
            $sol_id = $_REQUEST['sol_id'];
            $model->project_id = $_REQUEST['project_id'];
               $model->event_type = $_POST['event_type']; 
               $model->event_phase = $_POST['event_phase'];
               $model->event = $_POST['event'];
               $model->execution_cost = $_POST['execution_cost'];
               $model->incrementer = $model->getTheCurrentIncrementedNumber() + 1;
                $model->trans_ref_number = $model->getTheTransRefNumberOfThisProjectExecution($model->project_id,$sol_id, $model->incrementer);
               if(isset($_POST['execution_description'])){
                    $model->description = $_POST['execution_description']; 
               }
               if(isset($_POST['purpose'])){
                    $model->purpose = $_POST['purpose']; 
               }
              $model->date_initiated = new CDbExpression('NOW()');
                $model->initiated_by_id = Yii::app()->user->id;
                if($model->save()){
                    
                       
                         // $result['success'] = 'true';
                          $msg = "Successfully initiated this Project Execution Request. Approval is pending";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to initiate this Project Execution Request was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                       )
                           );
                    } 
        }
        
        
        
        
         /**
         * This is the function that modifies a  project execution
         */
        public function actionmodifyprojectexecutionrequest(){
            
            
           $_id = $_POST['id'];
            $model= ProjectExecution::model()->findByPk($_id);
            
            $sol_id = $_REQUEST['sol_id'];
            $model->project_id = $_REQUEST['project_id'];
               $model->event_type = $_POST['event_type']; 
               $model->event_phase = $_POST['event_phase'];
               $model->event = $_POST['event'];
               $model->execution_cost = $_POST['execution_cost'];
              if(isset($_POST['execution_description'])){
                    $model->description = $_POST['execution_description']; 
               }
               if(isset($_POST['purpose'])){
                    $model->purpose = $_POST['purpose']; 
               }
                $model->is_rejected = 0;
               $model->is_approved = 0;
               $model->is_modification_approved = 0;
               $model->date_last_modified = new CDbExpression('NOW()');
               $model->modified_by_id = Yii::app()->user->id;
              
                if($model->save()){
                    
                       
                         // $result['success'] = 'true';
                          $msg = "Successfully updated this Project Execution Request. Approval is pending";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The attempt to update this Project Execution Request was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                       )
                           );
                    } 
        }
        
        
        
         /**
         * This is the function that approves project execution request
         */
        public function actionapproveprojectexecutionrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectExecution::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
            $model->is_approved = 1;
            $model->is_modification_approved = 1; 
            $model->is_rejected = 0;
            $model->is_deleted = 0; 
            $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project execution request is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project execution approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
         /**
         * This is the function that rejects project execution request
         */
        public function actionrejectprojectexecutionrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectExecution::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
            $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_rejected = 1;
            //$model->is_deleted = 1; 
            $model->approved_by_id = Yii::app()->user->id;
             $model->date_approved = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project execution request is successfully rejected";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project execution rejection request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        /**
         * This is the function that withdraws project execution request
         */
        public function actionwithdrawprojectexecutionrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectExecution::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
           $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_deleted = 1; 
             $model->withdrawn_by_id = Yii::app()->user->id;
             $model->date_withdrawn = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project execution request is successfully withdrawn";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project execution withdrawal request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        
        /**
         * This is the function that unwithdraws project execution request
         */
        public function actionunwithdrawprojectexecutionrequest(){
            
            $_id = $_POST['id'];
            
            $model= ProjectExecution::model()->findByPk($_id);
            
            $project = $_REQUEST['project_name'];
            
           $model->is_approved = 0;
            $model->is_modification_approved = 0;
            $model->is_deleted = 0; 
             $model->withdrawn_by_id = Yii::app()->user->id;
             $model->date_withdrawn = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "The '$project' project execution request is successfully unwithdrawn";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'project execution unwithdrawal request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
}
