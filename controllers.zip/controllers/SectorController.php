<?php

class SectorController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listthisorganizationsectors','addnewsector','modifysector','deleteonesector',
                                    'listthisorganizationdeletedsectors','undeletethissector'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all sectors for an organization
         */
        public function actionlistthisorganizationsectors(){
            
            $organization_id = $_REQUEST['organization_id'];
            
            $data = [];
            $q = "select a.*, b.name as organization_name from sector a
                    JOIN organization b ON b.id=a.organization_id
                     where a.organization_id =$organization_id and a.is_deleted=0
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "sector"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        /**
         * This is the function that adds new sector
         */
        public function actionaddnewsector(){
            
            $model = new Sector;
            $model->name = $_POST['name'];
            $model->organization_id = $_POST['organization_id'];
                
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully added a new sector';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The addition of this new sector was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
         /**
         * This is the function that modifies a sector
         */
        public function actionmodifysector(){
            
             $_id = $_POST['id'];
            
            $model= Sector::model()->findByPk($_id);
            $model->name = $_POST['name'];
             $model->organization_id = $_POST['organization_id'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated this sector';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The update of this sector was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
        /**
	 * This is the function that deletes a sector
	 */
	public function actiondeleteonesector()
	{
            $_id = $_POST['id'];
            $model= Sector::model()->findByPk($_id);
            
             $model->is_deleted = 1;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' sector is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        
        /**
         * This is the function that list all deleted sectors for an organization
         */
        public function actionlistthisorganizationdeletedsectors(){
            
            $organization_id = $_REQUEST['organization_id'];
            
            $data = [];
            $q = "select a.*, b.name as organization_name from sector a
                    JOIN organization b ON b.id=a.organization_id
                     where a.organization_id =$organization_id and a.is_deleted=1
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "sector"=>$data,
                                  
                            ));
            
            
        }
        
        
        
        /**
	 * This is the function that undeletes a sector
	 */
	public function actionundeletethissector()
	{
            $_id = $_POST['sector'];
            $model= Sector::model()->findByPk($_id);
            
             $model->is_deleted = 0;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' sector is successfully undeleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
}
