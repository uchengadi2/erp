<?php

class AgrantPropertyPlantationAssetSlotController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllSlotsInThisBatchSeries','addnewplantationassetslottoseries','modifyplantationassetslottoseries'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all series slots in a batch
         */
        public function actionlistAllSlotsInThisBatchSeries(){
            $model = new AgrantPropertyPlantationAssetSlot;
            
            $batch_series_id = $_REQUEST['batch_series_id'];
        // $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from agrant_property_plantation_asset_slot a
                    where a.plantation_id =$batch_series_id
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "asset"=>$data,
                                  
                            ));
        }
        
        
        
        /**
         * This is the function that adds a new slot to a batch series
         */
        public function actionaddnewplantationassetslottoseries(){
            
            
            $model = new AgrantPropertyPlantationAssetSlot;
           
           $model->plantation_id = $_REQUEST['active_batch_series_id'];
            
           $model->slot_name = $_POST['slot_name'];
           $model->number_of_plants = $_POST['number_of_plants'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
          // $model->charcoal_type = $_POST['charcoal_type'];
           $model->slot_gl_id = $_POST['slot_gl_id'];
           $model->total_slots_cost = $_POST['total_slots_cost'];
           $model->cultivation_cost = $_POST['cultivation_cost'];
           if($model->number_of_plants>0){
               $model->average_cost_per_plant = round((double)$model->total_slots_cost/(double)$model->number_of_plants,2);
           }
           
           $model->plantation_type = $_POST['plantation_type'];
           $model->plant_specie = $_POST['plant_specie'];
           $model->plant_fertilization_status = $_POST['plant_fertilization_status'];
           $model->plant_variant = $_POST['plant_variant'];
           $model->location = $_POST['location'];
           $model->average_dimension_height_in_meters = $_POST['average_dimension_height_in_meters'];
           $model->duration_of_acquisition_in_months = $_POST['duration_of_acquisition_in_months'];
          
                                       
           $plantation_acquisition_unique_number = $_POST['plantation_acquisition_unique_number'];
           
           $model->slot_unique_number = $model->generateThisSlotUniqueNumber($plantation_acquisition_unique_number);
           
          $model->series_slot_incrementer = (int)$model->getTheCurrentIncrementedNumber() + 1;
          
          $batch_series_remaining_slot = $this->retrieveTheRemainingBatchSlot($model->plantation_id);
          
          if($batch_series_remaining_slot>0){
              
              if($model->save()){
               
                        //reduce the remaining numbe of batches column in the batch series table
                        $new_batch_series_remaining_slot = $this->reduceTheRemainNumberOfBatchSeries($model->plantation_id);
                        
                        
                         // $result['success'] = 'true';
                          $msg = 'Successfully added new slot to this plantation Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                               )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to add this slot to this plantation Batch Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            )
                           );
                    } 
              
              
          }else{
               $msg = 'You cannot add any more slot to this  batch asset series as it had been exhausted';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            )
                           );
              
          }
          
           
            
        }
        
        
        
          /**
         * This is the function that reduces the remaining number of batch series
         */
        public function reduceTheRemainNumberOfBatchSeries($batch_series_id){
            $model = new AgrantPropertyPlantationAsset;
            return $model->reduceTheRemainNumberOfBatchSeries($batch_series_id);
        }
        
        
        
         /**
         * This is the function that retrieves the remaining number of batch series
         */
        public function retrieveTheRemainingBatchSlot($batch_series_id){
            $model = new AgrantPropertyPlantationAsset;
            return $model->retrieveTheRemainingBatchSlot($batch_series_id);
        }
        
        
        
         /**
         * This is the function that modifies a slot in a  batch series
         */
        public function actionmodifyplantationassetslottoseries(){
            
                  
          $_id = $_POST['id'];
          $model= AgrantPropertyPlantationAssetSlot::model()->findByPk($_id);  
          
          $model->plantation_id = $_REQUEST['active_batch_series_id'];
            
           $model->slot_name = $_POST['slot_name'];
           $model->number_of_plants = $_POST['number_of_plants'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
          // $model->charcoal_type = $_POST['charcoal_type'];
           $model->slot_gl_id = $_POST['slot_gl_id'];
           $model->total_slots_cost = $_POST['total_slots_cost'];
           $model->cultivation_cost = $_POST['cultivation_cost'];
           if($model->number_of_plants>0){
               $model->average_cost_per_plant = round((double)$model->total_slots_cost/(double)$model->number_of_plants,2);
           }
           
           $model->plantation_type = $_POST['plantation_type'];
           $model->plant_specie = $_POST['plant_specie'];
           $model->plant_fertilization_status = $_POST['plant_fertilization_status'];
           $model->plant_variant = $_POST['plant_variant'];
           $model->location = $_POST['location'];
           $model->average_dimension_height_in_meters = $_POST['average_dimension_height_in_meters'];
           $model->duration_of_acquisition_in_months = $_POST['duration_of_acquisition_in_months'];
                        
              if($model->save()){
               
                                              
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated slot in this Plantation Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                               )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to update this slot in this Plantation Batch Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                            )
                           );
                    } 
              
              
          }
        
}
