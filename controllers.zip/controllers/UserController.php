<?php

class UserController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','Login','confirmtheauthenticityofthisgroupadminuser','confirmtheauthenticityofthisuser',
                                    'confirmtheauthenticityofthisorganizationadminuser','confirmtheauthenticityofuser'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','Logout','confirmtheauthenticityofthisuser','listAllGroupAdminUsers','addnewgroupadminuser','modifygroupadminuser',
                                    'deleteonegroupadmin','confirmtheauthenticityofthisgroupadminuser','addneworganizationadminuser','listAllOrganizationAdminUsers',
                                    'modifyorganizationadminuser','confirmtheauthenticityofthisorganizationadminuser','listAllCrmAdminUsersForAnOrganization',
                                    'addnewcrmadminuser','modifycrmadminuser','deleteonecrmadmin','confirmtheauthenticityofuser','addnewstaffuser',
                                    'modifystaffuser','deleteonestaffuser','listAllOrganizationStaffUsers','listAllOrganizationApplicationAdminUsers','deleteoneappadminuser',
                                    'addnewappadminuser','modifyappadminuser','listAllOrganizationIndividualCustomers','modifyindividualcustomer','addnewindividualcustomer',
                                    'deleteonecustomer','undeleteonecustomer','listthisorganizationdeletedindividualcustomers','listAllOrganizationCorporateCustomers',
                                    'deleteonecorporatecustomer','addnewcorporatecustomer','modifycorporatecustomer','listthisorganizationdeletedcorporatecustomers',
                                    'undeleteonecorporatecustomer'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	public function actionLogin()
	{
		
             $model = new User('login');
            
                                             
               
                              
                $model->username = $_POST['username'];
                $model->password = $_POST['password'];
                
                
                //determine the users id
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='username=:name and is_deleted=0';
                $criteria->params = array(':name'=>$_POST['username']);
                $user = User::model()->find($criteria);   
                
               $name = $user['name'];
              //validate the users logon credentials
              
         if($this->validatePassword($model, $user->id,$model->password) && $model->login()) {
           // if($model->login()) {
                      header('Content-Type: application/json');
                      $msg = "$name";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg,
                          // "firstname"=>$id['name'],
                           "user"=>$user
                            )
                           
                       );
          // }  

        }else {
                     header('Content-Type: application/json');
                      $msg= 'Incorrect username or password.';
                     echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                         "firstname"=>$user['name']
                             )
                       );
                       
                }
                
            
                
		
		
	}
        
        
         /**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
		Yii::app()->user->logout();
		//$this->redirect(Yii::app()->homeUrl);
                header('Content-Type: application/json');
                      $msg= "You just logged out. Please come again";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg,
                           
                            )
                           
                       );
	}
        
        
                /*
         * validate the password during authorisation
         */
        public function validatePassword($model, $id, $password){
         
            //determine the existing password
            
           $criteria = new CDbCriteria();
           $criteria->select = 'id, password';
           $criteria->condition='id=:id';
           $criteria->params = array(':id'=>$id);
           $existing_password = User::model()->find($criteria);   
        
           return $model->hashPassword($password)=== $existing_password->password;
           
            
        }
        
        
        /**
         * This is the function that confirms if a user's logged in authenticity
         */
        public function actionconfirmtheauthenticityofthisuser(){
            
            $userid = $_REQUEST['userid'];
            
            $logged_in_user = Yii::app()->user->id;
            
            if((int)$userid == (int)$logged_in_user){
                $is_authentic = true;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$userid);
                $user = User::model()->find($criteria);   
                
            }else{
               $is_authentic = false;
               $user=null;
            }
            
             header('Content-Type: application/json');
                      $msg= "You just logged out. Please come again";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "is_authentic" => $is_authentic,
                            "user"=>$user
                            
                            )
                           
                       );
            
        }
        
        
        /**
         * This is the function that list all group admin users of a particular group
         */
        public function actionlistAllGroupAdminUsers(){
            
            $group_id = $_REQUEST['group_id'];
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='group_id=:groupid and role=:role';
                $criteria->params = array(':groupid'=>$group_id,':role'=>"groupAdminUser");
                $user = User::model()->findAll($criteria);   
                
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $user)
                           );
                       
                }
            
        }
        
        
        
        
        /**
         * This is the function that adds new corporate group administrator
         */
        public function actionaddnewgroupadminuser(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            $model->group_id = $_POST['group_id'];
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->status = strtolower($_POST['status']);
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'User Creation was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'User creation was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the marketplace so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
        
        /**
         * This is the function that modifies a  corporate group admin user information
         */
        public function actionmodifygroupadminuser(){
           
            $_id = $_POST['id'];
           $model=User::model()->findByPk($_id);
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
             $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->group_id = $_POST['group_id'];
            $model->status = strtolower($_POST['status']);
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            $password = "";
            $password_repeat = "";
            
             $icon_error_counter = 0;
                      if($_FILES['picture']['name'] != ""){
                             if($model->isIconTypeAndSizeLegal()){
                       
                                 $icon_filename = $_FILES['picture']['name'];
                                                                       
                             }else{
                       
                                 $icon_error_counter = $icon_error_counter + 1;
                                                
                             }//end of the determine size and type statement
                      }else{
                             $icon_filename = $model->retrieveThePreviousIconName($_id);
                                            
                      }//end of the if icon is empty statement
                  
                      if($icon_error_counter ==0){
                           if($model->validate()){
                              $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                  if($model->isTheUserModificationASuccess($_id,$model->group_id,$model->status,$model->name,$model->picture)) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'User update was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'Userrr update was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                        }
                        
                                       
                         
                                }else{
                                    $msg = 'User update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
            
        }
        
        
        
        /**
	 * This is the function that deletes this corporate group admin user
	 */
	public function actiondeleteonegroupadmin()
	{
            //delete one user
            $_id = $_REQUEST['id'];
            $model=User::model()->findByPk($_id);
            if($model === null){
                $msg = "This model is null and there are no data to delete";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => $msg)
                       );
            }else if($model->isTheRemovalOfUserImageASuccess($_id)){
                if($model->delete()){
                    if($model->deleteRoleAssignedToAUser($model->role, $_id)){
                         $msg = "'$model->name' corporate group user was successfully deleted";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                );
                        
                    }else{
                        $msg = "The '$model->name' corporate group admin was deleted but his/her record(s) still exist in the role assignment table";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => $msg)
                       );
                        
                        
                    }
                    
                    
                }else{
                     $msg = "'$model->name' corporate group admin user record deletion was not successful.Please contact customer service for assistance";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => $msg)
                       );
                            
                    
                }
                
                  
          }else{
               $msg = "'$model->name' corporate group admin user could not be deleted as there was issue in removing his/her picture. Please contact customer service for assistance";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
              
              
              
          }              
                                      
           
                    
          
	}
        
        
        /**
         * This is the function that confirms  a group admin user's logged in authenticity
         */
        public function actionconfirmtheauthenticityofthisgroupadminuser(){
            
            $userid = $_REQUEST['userid'];
            $gcode = $_REQUEST['gcode'];
            
            $logged_in_user = Yii::app()->user->id;
            
            if((int)$userid == (int)$logged_in_user){
                //get the group_id of this group code
                $group_id = $this->getTheCorporateGroupIdOfThisCode("$gcode");
                
                if($group_id!=null){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$userid);
                    $user = User::model()->find($criteria);  
                    if($user['group_id'] ==$group_id){
                        $group_name = $this->getTheNameOfTheGroup($group_id);
                        $is_authentic = true;
                    }else{
                        $is_authentic = false;
                        $user=null;
                        $group_name=null;
                    }
                    
                }else{
                    $is_authentic = false;
                    $user=null;
                    $group_name=null;
                    
                }
                
                
                
            }else{
               $is_authentic = false;
               $user=null;
               $group_name=null;
            }
            
             header('Content-Type: application/json');
                      $msg= "You just logged out. Please come again";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "is_authentic" => $is_authentic,
                            "user"=>$user,
                           "group_name"=>$group_name
                               
                            
                            )
                           
                       );
            
        }
        
        /**
         * This is the function that retrieves id of a corporate group code
         */
        public function getTheCorporateGroupIdOfThisCode($gcode){
            $model = new CorpGroup;
            return $model->getTheCorporateGroupIdOfThisCode($gcode);
        }
        
        
        /**
         * This is the function that retrieves a group's name
         */
        public function getTheNameOfTheGroup($group_id){
            $model = new CorpGroup;
            return $model->getTheNameOfTheGroup($group_id);
        }
        
        
        
        
        /**
         * This is the function that adds new organization administrator 
         */
        public function actionaddneworganizationadminuser(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            $model->group_id = $_POST['group_id'];
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->status = strtolower($_POST['status']);
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            $organization_id = $_POST['organization_id'];
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                               
                                               //assign this admin to the organization
                                               if($this->assignUserToOrganization($model->id,$organization_id,$model->status)){
                                                    // $result['success'] = 'true';
                                                $msg = 'User Creation was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                                                   
                                               }else{
                                                    $msg = 'User Organization Admin was added but could not be linked to the organization. Please contact the support team';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                                                   
                                               }
                                               
                              
                                            }else {
                                                $msg = 'User creation was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the marketplace so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
        
        /**
         * This is the function that assigns a user to his organization
         */
        public function assignUserToOrganization($user_id,$organization_id,$status){
            $model = new OrganizationHasUser;
            return $model->assignUserToOrganization($user_id,$organization_id,$status);
        }
        
        /**
         * This is the function that list all admins for an organization
         */
        public function actionlistAllOrganizationAdminUsers(){
            $model = new OrganizationHasUser;
            
            $target = [];
            $group_id = $_REQUEST['group_id'];
            $organization_id = $_REQUEST['organization_id'];
            
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='group_id=:groupid and role=:role';
                $criteria->params = array(':groupid'=>$group_id,':role'=>"organizationAdminUser");
                $users = User::model()->findAll($criteria);   
                
                 if($users===null){
                     http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
             
                    
                }else{
                    
                     foreach($users as $user){
                            if($model->isUserInThisOrganization($user['id'],$organization_id)){
                                 $target[] = $user;
                            }
                    }   
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $target)
                           );
                       
                }
            
        }
        
        
        /**
         * This is the function that modifies an organization admin user information
         */
        public function actionmodifyorganizationadminuser(){
           
            $_id = $_POST['id'];
           $model=User::model()->findByPk($_id);
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
             $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->group_id = $_POST['group_id'];
            $model->status = strtolower($_POST['status']);
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            $password = "";
            $password_repeat = "";
            
             $icon_error_counter = 0;
                      if($_FILES['picture']['name'] != ""){
                             if($model->isIconTypeAndSizeLegal()){
                       
                                 $icon_filename = $_FILES['picture']['name'];
                                                                       
                             }else{
                       
                                 $icon_error_counter = $icon_error_counter + 1;
                                                
                             }//end of the determine size and type statement
                      }else{
                             $icon_filename = $model->retrieveThePreviousIconName($_id);
                                            
                      }//end of the if icon is empty statement
                  
                      if($icon_error_counter ==0){
                           if($model->validate()){
                              $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                  if($model->isTheUserModificationASuccess($_id,$model->group_id,$model->status,$model->name,$model->picture)) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'User update was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'Userrr update was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                        }
                        
                                       
                         
                                }else{
                                    $msg = 'User update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
            
        }
        
        
       /**
         * This is the function that confirms  an organization admin user's logged in authenticity
         */
        public function actionconfirmtheauthenticityofthisorganizationadminuser(){
            
            $userid = $_REQUEST['userid'];
            $gcode = $_REQUEST['gcode'];
            $organization_id = $_REQUEST['organization_id'];
            
            $logged_in_user = Yii::app()->user->id;
            
            if((int)$userid == (int)$logged_in_user){
                //get the group_id of this group code
                $group_id = $this->getTheCorporateGroupIdOfThisCode("$gcode");
                
                if($group_id!=null){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$userid);
                    $user = User::model()->find($criteria);  
                    if($user['group_id'] ==$group_id){
                        if($this->isOrganizationExist($organization_id)){
                            if($this->isUserInThisOrganization($userid,$organization_id)){
                                $group_name = $this->getTheNameOfTheGroup($group_id);
                                $organization_name = $this->getTheNameOfTheOrganization($organization_id);
                                $organization_id=$organization_id;
                                $is_authentic = true;
                        }else{
                             $is_authentic = false;
                            $user=null;
                            $group_name=null;
                            $organization_id=null;
                            $organization_name = null;
                        }
                        }else{
                            $is_authentic = false;
                            $user=null;
                            $group_name=null;
                            $organization_id=null;
                            $organization_name = null;
                            
                        }
                        
                       
                    }else{
                        $is_authentic = false;
                        $user=null;
                        $group_name=null;
                        $organization_id=null;
                        $organization_name = null;
                    }
                    
                }else{
                    $is_authentic = false;
                    $user=null;
                    $group_name=null;
                    $organization_id=null;
                    $organization_name = null;
                    
                }
                
                
                
            }else{
               $is_authentic = false;
               $user=null;
               $group_name=null;
               $organization_id=null;
               $organization_name = null;
            }
            
             header('Content-Type: application/json');
                      $msg= "You just logged out. Please come again";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "is_authentic" => $is_authentic,
                            "user"=>$user,
                           "group_name"=>$group_name,
                           "organization_id"=>$organization_id,
                           "organization_name"=>$organization_name
                      
                            )
                           
                       );
            
        } 
        
        
        /**
         * This is the function that confirms if a user is in an organization
         */
        public function isUserInThisOrganization($userid,$organization_id){
            $model = new OrganizationHasUser;
            return $model->isUserInThisOrganization($userid,$organization_id);
            
        }
        
        
        /**
         * This is the function that gets the name of an organization
         */
        public function getTheNameOfTheOrganization($organization_id){
            $model = new Organization;
            return $model->getTheNameOfTheOrganization($organization_id);
        }
        
        
        /**
         * This is the function that confirms if an organization exist
         */
        public function isOrganizationExist($organization_id){
            $model = new Organization;
            return $model->isOrganizationExist($organization_id);
        }
        
        
        
        
         /**
         * This is the function that list all crm admins for an organization
         */
        public function actionlistAllCrmAdminUsersForAnOrganization(){
            $model = new OrganizationHasUser;
            
            $target = [];
            $group_id = $_REQUEST['group_id'];
            $organization_id = $_REQUEST['organization_id'];
            
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='group_id=:groupid and (role=:role and is_deleted=0)';
                $criteria->params = array(':groupid'=>$group_id,':role'=>"crmAdminUser");
                $users = User::model()->findAll($criteria);   
                
                if($users===null){
                     http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                    
           
                }else{
                    
                    foreach($users as $user){
                            if($model->isUserInThisOrganization($user['id'],$organization_id)){
                                $target[] = $user;
                            }
                    }
                
                    
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $target)
                           );
                       
                }
            
        }
        
        
        
        /**
         * This is the function that adds new crm administrator for an organization
         */
        public function actionaddnewcrmadminuser(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            $model->group_id = $_POST['group_id'];
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->status = strtolower($_POST['status']);
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            $organization_id = $_POST['organization_id'];
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                               
                                               //assign this admin to the organization
                                               if($this->assignUserToOrganization($model->id,$organization_id,$model->status)){
                                                   //assign the crm module to this user
                                                   //
                                                   //get the module id of the crm solution
                                                   $module_id = $this->getCrmModuleId();
                                                   $this->assignThisModuleToThisUser($model->id,$module_id);
                                                           
                                                    // $result['success'] = 'true';
                                                $msg = 'User Creation was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                                                   
                                               }else{
                                                    $msg = 'CRM Admin was added but could not be linked to the organization. Please contact the support team';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                                                   
                                               }
                                               
                              
                                            }else {
                                                $msg = 'User creation was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the platform so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
        /**
         * This is the function that gets the module id of a crm
         * 
         */
        public function getCrmModuleId(){
            $model  = new Modules;
            return $model->getCrmModuleId();
        }
        
        
        /**
         * This is the function that assigns a module to a user
         */
        public function assignThisModuleToThisUser($id,$module_id){
            $model = new UserHasModule;
            return $model->assignThisModuleToThisUser($id,$module_id);
        }
        
        
        
        /**
         * This is the function that modifies an organization crm admin user information
         */
        public function actionmodifycrmadminuser(){
           
            $_id = $_POST['id'];
           $model=User::model()->findByPk($_id);
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
             $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->group_id = $_POST['group_id'];
            $model->status = strtolower($_POST['status']);
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            $password = "";
            $password_repeat = "";
            
             $icon_error_counter = 0;
                      if($_FILES['picture']['name'] != ""){
                             if($model->isIconTypeAndSizeLegal()){
                       
                                 $icon_filename = $_FILES['picture']['name'];
                                                                       
                             }else{
                       
                                 $icon_error_counter = $icon_error_counter + 1;
                                                
                             }//end of the determine size and type statement
                      }else{
                             $icon_filename = $model->retrieveThePreviousIconName($_id);
                                            
                      }//end of the if icon is empty statement
                  
                      if($icon_error_counter ==0){
                           if($model->validate()){
                              $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                  if($model->isTheUserModificationASuccess($_id,$model->group_id,$model->status,$model->name,$model->picture)) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'User update was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'User update was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                        }
                        
                                       
                         
                                }else{
                                    $msg = 'User update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
            
        }
        
        
        
        
        /**
	 * This is the function that deletes this crm admin user
	 */
	public function actiondeleteonecrmadmin()
	{
            $_id = $_POST['id'];
            $model= User::model()->findByPk($_id);
            
             $model->is_deleted = 1;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' crm admin user is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        
        /**
         * This is the function that confirms  a crm admin user's logged in authenticity
         */
        public function actionconfirmtheauthenticityofuser(){
            
            $userid = $_REQUEST['userid'];
            $gcode = $_REQUEST['gcode'];
            $organization_id = $_REQUEST['organization_id'];
            
            $logged_in_user = Yii::app()->user->id;
            
            if((int)$userid == (int)$logged_in_user){
                //get the group_id of this group code
                $group_id = $this->getTheCorporateGroupIdOfThisCode("$gcode");
                
                if($group_id!=null){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$userid);
                    $user = User::model()->find($criteria);  
                    if($user['group_id'] ==$group_id){
                        if($this->isOrganizationExist($organization_id)){
                            if($this->isUserInThisOrganization($userid,$organization_id)){
                                $group_name = $this->getTheNameOfTheGroup($group_id);
                                $organization_name = $this->getTheNameOfTheOrganization($organization_id);
                                $organization_id=$organization_id;
                                $is_authentic = true;
                                $service_outlet_id = $this->getTheActiveServiceOutletOfThisUser($userid,$user['role']);
                                $service_outlet_name =$this->getTheServiceOutletNameOfThisUser($userid,$user['role']);
                               
                        }else{
                             $is_authentic = false;
                            $user=null;
                            $group_name=null;
                            $organization_id=null;
                            $organization_name = null;
                            $service_outlet_id=null;
                            $service_outlet_name=null;
                        }
                        }else{
                            $is_authentic = false;
                            $user=null;
                            $group_name=null;
                            $organization_id=null;
                            $organization_name = null;
                            $service_outlet_id=null;
                            $service_outlet_name=null;
                            
                        }
                        
                       
                    }else{
                        $is_authentic = false;
                        $user=null;
                        $group_name=null;
                        $organization_id=null;
                        $organization_name = null;
                        $service_outlet_id=null;
                        $service_outlet_name=null;
                    }
                    
                }else{
                    $is_authentic = false;
                    $user=null;
                    $group_name=null;
                    $organization_id=null;
                    $organization_name = null;
                    $service_outlet_id=null;
                    $service_outlet_name=null;
                    
                }
                
                
                
            }else{
               $is_authentic = false;
               $user=null;
               $group_name=null;
               $organization_id=null;
               $organization_name = null;
               $service_outlet_id=null;
               $service_outlet_name=null;
            }
            
             header('Content-Type: application/json');
                      $msg= "You just logged out. Please come again";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "is_authentic" => $is_authentic,
                            "user"=>$user,
                           "group_name"=>$group_name,
                           "organization_id"=>$organization_id,
                           "organization_name"=>$organization_name,
                           "service_outlet_id"=>$service_outlet_id,
                           "service_outlet_name"=>$service_outlet_name
                      
                            )
                           
                       );
            
        } 
        
        
        /**
         * This is the function that retrieves the service outlet's id of a user
         */
        public function getTheActiveServiceOutletOfThisUser($userid,$role){
            $model = new ServiceOuletHasUser;
            return $model->getTheActiveServiceOutletOfThisUser($userid,$role);
        }
        
        
         /**
         * This is the function that retrieves the service outlet's name of a user
         */
        public function getTheServiceOutletNameOfThisUser($userid,$role){
            $model = new ServiceOuletHasUser;
            return $model->getTheServiceOutletNameOfThisUser($userid,$role);
        }
        
        
        
        /**
         * This is the function that list all staff users for an organization
         */
        public function actionlistAllOrganizationStaffUsers(){
            $model = new OrganizationHasUser;
            
            $target = [];
            $group_id = $_REQUEST['group_id'];
            $organization_id = $_REQUEST['organization_id'];
            
          $criteria = new CDbCriteria();
                $criteria->select = '*';
                //$criteria->condition='group_id=:groupid and (role!=:role and is_deleted=0)';
                $criteria->condition='(group_id=:groupid and is_deleted=0) and (type=:type and role not in ("organizationAdminUser","crmAdminUser","appAdminUser","groupAdminUser","platformSuperAdmin"))';
                //$criteria->params = array(':groupid'=>$group_id,':role'=>"organizationAdminUser",'role'=>"crmAdminUser",':role'=>"appAdminUser");
                $criteria->params = array(':groupid'=>$group_id,':type'=>"staff");
                $users = User::model()->findAll($criteria);   
                
                if($users===null){
                     http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                    
           
                }else{
                    
                    foreach($users as $user){
                            if($model->isUserInThisOrganization($user['id'],$organization_id)){
                                $target[] = $user;
                            }
                    }
                
                    
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $target)
                           );
                       
                }
          
            
        }
        
        
        
        /**
         * This is the function that adds new staff user for an organization
         */
        public function actionaddnewstaffuser(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            $model->group_id = $_POST['group_id'];
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->status = strtolower($_POST['status']);
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            $organization_id = $_POST['organization_id'];
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                               
                                               //assign this admin to the organization
                                               if($this->assignUserToOrganization($model->id,$organization_id,$model->status)){
                                                    // $result['success'] = 'true';
                                                $msg = 'User Creation was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                                                   
                                               }else{
                                                    $msg = 'Staff User was added but could not be linked to the organization. Please contact the support team';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                                                   
                                               }
                                               
                              
                                            }else {
                                                $msg = 'User creation was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the platform so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
        
        
        
        /**
         * This is the function that modifies an organization staff user information
         */
        public function actionmodifystaffuser(){
           
            $_id = $_POST['id'];
           $model=User::model()->findByPk($_id);
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
             $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->group_id = $_POST['group_id'];
            $model->status = strtolower($_POST['status']);
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            $password = "";
            $password_repeat = "";
            
             $icon_error_counter = 0;
                      if($_FILES['picture']['name'] != ""){
                             if($model->isIconTypeAndSizeLegal()){
                       
                                 $icon_filename = $_FILES['picture']['name'];
                                                                       
                             }else{
                       
                                 $icon_error_counter = $icon_error_counter + 1;
                                                
                             }//end of the determine size and type statement
                      }else{
                             $icon_filename = $model->retrieveThePreviousIconName($_id);
                                            
                      }//end of the if icon is empty statement
                  
                      if($icon_error_counter ==0){
                           if($model->validate()){
                              $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                  if($model->isTheUserModificationASuccess($_id,$model->group_id,$model->status,$model->name,$model->picture)) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'User update was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'User update was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                        }
                        
                                       
                         
                                }else{
                                    $msg = 'User update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
            
        }
        
        
        /**
	 * This is the function that deletes this staff user
	 */
	public function actiondeleteonestaffuser()
	{
            $_id = $_POST['id'];
            $model= User::model()->findByPk($_id);
            
             $model->is_deleted = 1;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' staff user is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        
         /**
         * This is the function that list all app admins for an organization
         */
        public function actionlistAllOrganizationApplicationAdminUsers(){
            $model = new OrganizationHasUser;
            
            $target = [];
            $group_id = $_REQUEST['group_id'];
            $organization_id = $_REQUEST['organization_id'];
            
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='group_id=:groupid and (role=:role and is_deleted=0)';
                $criteria->params = array(':groupid'=>$group_id,':role'=>"appAdminUser");
                $users = User::model()->findAll($criteria);   
                
                if($users===null){
                     http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                    
           
                }else{
                    
                    foreach($users as $user){
                            if($model->isUserInThisOrganization($user['id'],$organization_id)){
                                $target[] = $user;
                            }
                    }
                
                    
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $target)
                           );
                       
                }
            
        }
        
        
        
         /**
         * This is the function that adds new app administrator for an organization
         */
        public function actionaddnewappadminuser(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            $model->group_id = $_POST['group_id'];
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->status = strtolower($_POST['status']);
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            $organization_id = $_POST['organization_id'];
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                               
                                               //assign this admin to the organization
                                               if($this->assignUserToOrganization($model->id,$organization_id,$model->status)){
                                                    // $result['success'] = 'true';
                                                $msg = 'User Creation was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                                                   
                                               }else{
                                                    $msg = 'App Admin was added but could not be linked to the organization. Please contact the support team';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                                                   
                                               }
                                               
                              
                                            }else {
                                                $msg = 'User creation was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the platform so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
        
        /**
         * This is the function that modifies an organization app admin user information
         */
        public function actionmodifyappadminuser(){
           
            $_id = $_POST['id'];
           $model=User::model()->findByPk($_id);
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
             $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->group_id = $_POST['group_id'];
            $model->status = strtolower($_POST['status']);
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            $password = "";
            $password_repeat = "";
            
             $icon_error_counter = 0;
                      if($_FILES['picture']['name'] != ""){
                             if($model->isIconTypeAndSizeLegal()){
                       
                                 $icon_filename = $_FILES['picture']['name'];
                                                                       
                             }else{
                       
                                 $icon_error_counter = $icon_error_counter + 1;
                                                
                             }//end of the determine size and type statement
                      }else{
                             $icon_filename = $model->retrieveThePreviousIconName($_id);
                                            
                      }//end of the if icon is empty statement
                  
                      if($icon_error_counter ==0){
                           if($model->validate()){
                              $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                  if($model->isTheUserModificationASuccess($_id,$model->group_id,$model->status,$model->name,$model->picture)) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'User update was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'User update was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                        }
                        
                                       
                         
                                }else{
                                    $msg = 'User update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
            
        }
        
        
        
        
        /**
	 * This is the function that deletes this app admin user
	 */
	public function actiondeleteoneappadminuser()
	{
            $_id = $_POST['id'];
            $model= User::model()->findByPk($_id);
            
             $model->is_deleted = 1;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' app admin user is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        
        /**
         * This is the function that list all individual customer for an organization
         */
        public function actionlistAllOrganizationIndividualCustomers(){
            $model = new OrganizationHasUser;
            
            $target = [];
            $group_id = $_REQUEST['group_id'];
            $organization_id = $_REQUEST['organization_id'];
            
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                //$criteria->condition='group_id=:groupid and (role!=:role and is_deleted=0)';
                $criteria->condition='(group_id=:groupid and is_deleted=0) and (type=:type and client_id=:clientid) and (role not in ("organizationAdminUser","crmAdminUser","appAdminUser","groupAdminUser","platformSuperAdmin"))';
                //$criteria->params = array(':groupid'=>$group_id,':role'=>"organizationAdminUser",'role'=>"crmAdminUser",':role'=>"appAdminUser");
                $criteria->params = array(':groupid'=>$group_id,':type'=>"others",':clientid'=>0);
                $users = User::model()->findAll($criteria);   
                
                if($users===null){
                     http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                    
           
                }else{
                    
                    foreach($users as $user){
                            if($model->isUserInThisOrganization($user['id'],$organization_id)){
                                $target[] = $user;
                            }
                    }
                
                    
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $target)
                           );
                       
                }
            
        }
        
        
        
        /**
         * This is the function that adds new customer for an organization
         */
        public function actionaddnewindividualcustomer(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            $model->group_id = $_POST['group_id'];
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->status = strtolower($_POST['status']);
            $model->type = "others";
            $model->client_id = 0;
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            $organization_id = $_POST['organization_id'];
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                               
                                               //assign this admin to the organization
                                               if($this->assignUserToOrganization($model->id,$organization_id,$model->status)){
                                                    // $result['success'] = 'true';
                                                $msg = 'Customer Creation was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                                                   
                                               }else{
                                                    $msg = 'Customer was added but could not be linked to the organization. Please contact the support team';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                                                   
                                               }
                                               
                              
                                            }else {
                                                $msg = 'Customer creation was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this Customer";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'Customer creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the platform so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
        
        
        
        /**
         * This is the function that modifies an organization staff user information
         */
        public function actionmodifyindividualcustomer(){
           
            $_id = $_POST['id'];
           $model=User::model()->findByPk($_id);
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
             $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->type = "others";
            $model->client_id = 0;
            $model->group_id = $_POST['group_id'];
            $model->status = strtolower($_POST['status']);
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            $password = "";
            $password_repeat = "";
            
             $icon_error_counter = 0;
                      if($_FILES['picture']['name'] != ""){
                             if($model->isIconTypeAndSizeLegal()){
                       
                                 $icon_filename = $_FILES['picture']['name'];
                                                                       
                             }else{
                       
                                 $icon_error_counter = $icon_error_counter + 1;
                                                
                             }//end of the determine size and type statement
                      }else{
                             $icon_filename = $model->retrieveThePreviousIconName($_id);
                                            
                      }//end of the if icon is empty statement
                  
                      if($icon_error_counter ==0){
                           if($model->validate()){
                              $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                  if($model->isTheUserModificationASuccess($_id,$model->group_id,$model->status,$model->name,$model->picture)) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'Customer update was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'Customer update was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this Customer";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                        }
                        
                                       
                         
                                }else{
                                    $msg = 'Customer update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
            
        }
        
        
        
        /**
	 * This is the function that deletes this customer
	 */
	public function actiondeleteonecustomer()
	{
            $_id = $_POST['id'];
            $model= User::model()->findByPk($_id);
            
             $model->is_deleted = 1;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' customer is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        
        
        /**
	 * This is the function that deletes this customer
	 */
	public function actionundeleteonecustomer()
	{
            $_id = $_POST['customer'];
            $model= User::model()->findByPk($_id);
            
             $model->is_deleted = 0;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' customer is successfully undeleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        
        /**
         * This is the function that list all individual customer for an organization
         */
        public function actionlistthisorganizationdeletedindividualcustomers(){
            $model = new OrganizationHasUser;
            
            $target = [];
            $group_id = $_REQUEST['group_id'];
            $organization_id = $_REQUEST['organization_id'];
            
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                //$criteria->condition='group_id=:groupid and (role!=:role and is_deleted=0)';
                $criteria->condition='(group_id=:groupid and is_deleted=1) and (type=:type and client_id=:clientid) and (role not in ("organizationAdminUser","crmAdminUser","appAdminUser","groupAdminUser","platformSuperAdmin"))';
                //$criteria->params = array(':groupid'=>$group_id,':role'=>"organizationAdminUser",'role'=>"crmAdminUser",':role'=>"appAdminUser");
                $criteria->params = array(':groupid'=>$group_id,':type'=>"others",':clientid'=>0);
                $users = User::model()->findAll($criteria);   
                
                if($users===null){
                     http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                    
           
                }else{
                    
                    foreach($users as $user){
                            if($model->isUserInThisOrganization($user['id'],$organization_id)){
                                $target[] = $user;
                            }
                    }
                
                    
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $target)
                           );
                       
                }
            
        }
        
        
        
        
        /**
         * This is the function that list all corporate customer for an organization
         */
        public function actionlistAllOrganizationCorporateCustomers(){
            $model = new OrganizationHasUser;
            
            $target = [];
            $group_id = $_REQUEST['group_id'];
            $organization_id = $_REQUEST['organization_id'];
            
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                //$criteria->condition='group_id=:groupid and (role!=:role and is_deleted=0)';
                $criteria->condition='(group_id=:groupid and is_deleted=0) and (type=:type and client_id>:clientid) and (role not in ("organizationAdminUser","crmAdminUser","appAdminUser","groupAdminUser","platformSuperAdmin"))';
                //$criteria->params = array(':groupid'=>$group_id,':role'=>"organizationAdminUser",'role'=>"crmAdminUser",':role'=>"appAdminUser");
                $criteria->params = array(':groupid'=>$group_id,':type'=>"others",':clientid'=>0);
                $users = User::model()->findAll($criteria);   
                
                if($users===null){
                     http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                    
           
                }else{
                    
                    foreach($users as $user){
                            if($model->isUserInThisOrganization($user['id'],$organization_id)){
                                $target[] = $user;
                            }
                    }
                
                    
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $target)
                           );
                       
                }
            
        }
        
        
        
        /**
         * This is the function that adds new corporate customer for an organization
         */
        public function actionaddnewcorporatecustomer(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            $model->group_id = $_POST['group_id'];
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->status = strtolower($_POST['status']);
            $model->type = "others";
            $model->client_id = $_POST['client_id'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            $organization_id = $_POST['organization_id'];
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                               
                                               //assign this admin to the organization
                                               if($this->assignUserToOrganization($model->id,$organization_id,$model->status)){
                                                    // $result['success'] = 'true';
                                                $msg = 'Corporate Customer Creation was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                                                   
                                               }else{
                                                    $msg = 'Corporate Customer was added but could not be linked to the organization. Please contact the support team';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                                                   
                                               }
                                               
                              
                                            }else {
                                                $msg = 'Corporate Customer creation was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this Customer";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'Corporate Customer creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the platform so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
        
        
        
        /**
         * This is the function that modifies an organization staff user information
         */
        public function actionmodifycorporatecustomer(){
           
            $_id = $_POST['id'];
           $model=User::model()->findByPk($_id);
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
             $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->type = "others";
            $model->client_id = $_POST['client_id'];
            $model->group_id = $_POST['group_id'];
            $model->status = strtolower($_POST['status']);
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            $password = "";
            $password_repeat = "";
            
             $icon_error_counter = 0;
                      if($_FILES['picture']['name'] != ""){
                             if($model->isIconTypeAndSizeLegal()){
                       
                                 $icon_filename = $_FILES['picture']['name'];
                                                                       
                             }else{
                       
                                 $icon_error_counter = $icon_error_counter + 1;
                                                
                             }//end of the determine size and type statement
                      }else{
                             $icon_filename = $model->retrieveThePreviousIconName($_id);
                                            
                      }//end of the if icon is empty statement
                  
                      if($icon_error_counter ==0){
                           if($model->validate()){
                              $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                  if($model->isTheUserModificationASuccess($_id,$model->group_id,$model->status,$model->name,$model->picture)) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'Corporate Customer update was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'Corporate Customer update was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this Customer";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                        }
                        
                                       
                         
                                }else{
                                    $msg = 'Corporate Customer update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
            
        }
        
        
        
        /**
	 * This is the function that deletes this corporate customer
	 */
	public function actiondeleteonecorporatecustomer()
	{
            $_id = $_POST['id'];
            $model= User::model()->findByPk($_id);
            
             $model->is_deleted = 1;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' customer is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        /**
	 * This is the function that deletes this customer
	 */
	public function actionundeleteonecorporatecustomer()
	{
            $_id = $_POST['customer'];
            $model= User::model()->findByPk($_id);
            
             $model->is_deleted = 0;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' customer is successfully undeleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }          
                                      
           
                    
          
	}
        
        
        
        /**
         * This is the function that list all corporate customer for an organization
         */
        public function actionlistthisorganizationdeletedcorporatecustomers(){
            $model = new OrganizationHasUser;
            
            $target = [];
            $group_id = $_REQUEST['group_id'];
            $organization_id = $_REQUEST['organization_id'];
            
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                //$criteria->condition='group_id=:groupid and (role!=:role and is_deleted=0)';
                $criteria->condition='(group_id=:groupid and is_deleted=1) and (type=:type and client_id>:clientid) and (role not in ("organizationAdminUser","crmAdminUser","appAdminUser","groupAdminUser","platformSuperAdmin"))';
                //$criteria->params = array(':groupid'=>$group_id,':role'=>"organizationAdminUser",'role'=>"crmAdminUser",':role'=>"appAdminUser");
                $criteria->params = array(':groupid'=>$group_id,':type'=>"others",':clientid'=>0);
                $users = User::model()->findAll($criteria);   
                
                if($users===null){
                     http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                    
           
                }else{
                    
                    foreach($users as $user){
                            if($model->isUserInThisOrganization($user['id'],$organization_id)){
                                $target[] = $user;
                            }
                    }
                
                    
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $target)
                           );
                       
                }
            
        }
}
