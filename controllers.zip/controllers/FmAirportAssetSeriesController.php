<?php

class FmAirportAssetSeriesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listthisolbatchseries','listthisolunapprovedbatchseries','listthisoldeletedbatchseries',
                                    'listthisolforadjustmentbatchseries','addnewassetbatchseries','modifyassetbatchseries','deleteoneassetbatchseries',
                                    'approveassetbatchseries','undeleteassetbatchseries'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all batch series
         */
        public function actionlistthisolbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from fm_airport_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
          /**
         * This is the function that list all unapproved batch series in a sol
         */
        public function actionlistthisolunapprovedbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from fm_airport_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=0)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
         /**
         * This is the function that list all deleted batch series in a sol
         */
        public function actionlistthisoldeletedbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from fm_airport_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
         /**
         * This is the function that list all for adjustment batch series in a sol
         */
        public function actionlistthisolforadjustmentbatchseries(){
            
         $organization_id = $_REQUEST['organization_id'];
         $sol_id = $_REQUEST['sol_id'];
            
            $data = [];
            $q = "select a.* from fm_airport_asset_series a
                    where a.sol_id =$sol_id and (is_deleted=0 and is_acquisition_approved=1)
                     group by a.id";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "batch"=>$data,
                                  
                            ));
            
        }
        
        
        
        /**
         * This is the function that creates new  batched street
         */
        public function actionaddnewassetbatchseries(){
            
           $model = new FmAirportAssetSeries;
           
           $active_asset_subtype_code = $_REQUEST['active_asset_subtype_code'];
            
           $model->sol_id = $_POST['sol_id'];
           $model->production_asset_id = $_POST['production_asset_id'];
           $model->number_of_sections = $_POST['number_of_sections'];
           $model->asset_series_name = $_POST['asset_series_name'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
           $model->accounting_preference = $_POST['accounting_preference'];
                
            if($model->accounting_preference == "batched"){
               $model->number_to_split_batch = $_POST['number_of_sections'];
           }else{
               $model->number_to_split_batch = $_POST['number_to_split_batch'];
           }
           
           if($_POST['method_of_acquisition'] == "others"){
               $model->other_acquisition_method = $_POST['other_acquisition_method'];
               $model->method_of_acquisition = $_POST['method_of_acquisition'];
           }else{
               $model->other_acquisition_method = NULL;
               $model->method_of_acquisition = $_POST['method_of_acquisition'];
           }
          
           if($_POST['batch_split_parameter'] =="others"){
               $model->other_batch_split_parameter = $_POST['other_batch_split_parameter'];
               $model->batch_split_parameter = $_POST['batch_split_parameter'];
           }else{
              $model->other_batch_split_parameter=NULL; 
               $model->batch_split_parameter = $_POST['batch_split_parameter'];
           }
           
           $model->acquired_from = $_POST['acquired_from'];
           $model->series_gl_id = $_POST['series_gl_id'];
           $model->total_contract_cost = $_POST['total_contract_cost'];
           $model->average_contract_cost_per_section = (double)$model->total_contract_cost/(double)$model->number_of_sections;
          // $model->primary_source_document_number_id = $_POST['primary_source_document_number_id'];
           $model->is_acquisition_approved = 0;
           $model->date_acquired = date("Y-m-d H:i:s", strtotime($_POST['date_acquired']));
           $model->location = $_POST['location'];
           $model->series_unique_number = $model->generateTheAssetBatchSeriesUniqueNumber();
           
                    
           $model->batch_series_incrementer = (int)$model->getTheCurrentIncrementedNumber() + 1;
           
           if((int)$model->number_of_sections>=(int)$model->number_to_split_batch){
               if((int)$model->number_of_sections%(int)$model->number_to_split_batch==0){
                    $model->batch_series_remaining_slot = (int)$model->number_of_sections/(int)$model->number_to_split_batch;
                }else{
                    $model->batch_series_remaining_slot = (int)$model->number_of_sections/(int)$model->number_to_split_batch + 1;
                 }
          
               
           }else{
               $model->batch_series_remaining_slot= 1;
           }
           
           
           $model->create_time = new CDbExpression('NOW()');
           $model->acquisition_enterred_by_id = Yii::app()->user->id;
           if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created an Asset Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                               )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to create this Asset Batch Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                           )
                           );
                    } 
          
            
        }
        
        
        
        /**
         * This is the function that modifies batched street
         */
        public function actionmodifyassetbatchseries(){
            
           $_id = $_POST['id'];
           $model= FmAirportAssetSeries::model()->findByPk($_id);
           
           $model->sol_id = $_POST['sol_id'];
           $model->production_asset_id = $_POST['production_asset_id'];
           $number_of_sections = $_POST['number_of_sections'];
           $model->asset_series_name = $_POST['asset_series_name'];
           $model->short_description = $_POST['short_description'];
           $model->description = $_POST['description'];
           $model->accounting_preference = $_POST['accounting_preference'];
           
           if($_POST['method_of_acquisition'] == "others"){
               $model->other_acquisition_method = $_POST['other_acquisition_method'];
               $model->method_of_acquisition = $_POST['method_of_acquisition'];
           }else{
               $model->other_acquisition_method = NULL;
               $model->method_of_acquisition = $_POST['method_of_acquisition'];
           }
          
           if($_POST['batch_split_parameter'] =="others"){
               $model->other_batch_split_parameter = $_POST['other_batch_split_parameter'];
               $model->batch_split_parameter = $_POST['batch_split_parameter'];
           }else{
              $model->other_batch_split_parameter=NULL; 
               $model->batch_split_parameter = $_POST['batch_split_parameter'];
           }
           
          
            if($model->accounting_preference == "batched"){
              $number_to_split_batch = $number_of_sections;
           }else{
               $number_to_split_batch = $_POST['number_to_split_batch'];
           }
           $model->acquired_from = $_POST['acquired_from'];
           $model->series_gl_id = $_POST['series_gl_id'];
           $model->total_contract_cost = $_POST['total_contract_cost'];
           //$model->average_contract_cost_per_section = (double)$model->total_contract_cost/(double)$model->number_of_sections;
           $model->date_acquired = date("Y-m-d H:i:s", strtotime($_POST['date_acquired']));
        
           //$model->duration_of_acquisition_in_months = $_POST['duration_of_acquisition_in_months'];
            $model->location = $_POST['location'];
                    
           if($this->isThisBatchSeriesWithAssets($_id)){
               $model->number_of_sections = $model->number_of_sections;
               $model->number_to_split_batch = $model->number_to_split_batch;
               $model->batch_series_remaining_slot = $model->batch_series_remaining_slot;
               $model->average_contract_cost_per_section = round((double)$model->total_contract_cost/(double)$model->number_of_sections,2);
           }else{
             if((int)$number_of_sections>=(int)$number_to_split_batch){
               if((int)$number_of_sections%(int)$number_to_split_batch==0){
                    $model->batch_series_remaining_slot = (int)$number_of_sections/(int)$number_to_split_batch;
                    $model->number_of_sections=$number_of_sections;
                    $model->number_to_split_batch = $number_to_split_batch;
                    $model->average_contract_cost_per_section = round((double)$model->total_contract_cost/(double)$number_of_sections,2);
                }else{
                    $model->batch_series_remaining_slot = (int)$number_of_sections/(int)$number_to_split_batch + 1;
                    $model->$number_of_sections=$number_of_sections;
                    $model->number_to_split_batch = $number_to_split_batch;
                   $model->average_contract_cost_per_section = round((double)$model->total_contract_cost/(double)$number_of_sections,2);
                 }
          
               
           }else{
               $model->batch_series_remaining_slot= 1;
               $model->number_of_sections=$number_of_sections;
               $model->number_to_split_batch = $number_to_split_batch;
               $model->average_cost_per_unit = round((double)$model->total_contract_cost/(double)$number_of_sections,2);
           }
               
           }
      
           $model->update_time = new CDbExpression('NOW()');
           $model->update_user_id = Yii::app()->user->id;
           if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated this Asset Batch Series';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg
                              )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to update this Asset Batch Series was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
          
            
        }
        
        
        
         /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($id){
            $model = new FmAirportAssetSeriesSlot;
            return $model->isThisBatchSeriesWithAssets($id);
        }
        
        
        
         /**
         * This is the function that removes  sds  batched street
         */
        public function actiondeleteoneassetbatchseries(){
            
            $_id = $_POST['id'];
            $model= FmAirportAssetSeries::model()->findByPk($_id);
            
                      
             $model->is_deleted = 1;          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->asset_series_name' Asset Batch Series is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
        
        /**
         * This is the function that approves series  batched street
         */
        public function actionapproveassetbatchseries(){
            
            $_id = $_POST['id'];
            $model= FmAirportAssetSeries::model()->findByPk($_id);
            
                      
             $model->is_acquisition_approved = 1;  
             $model->acquisition_approved_id = Yii::app()->user->id;
             $model->acquisition_approved_date = new CDbExpression('NOW()');
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->asset_series_name' Asset Batch Series is successfully approved";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'approval request unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
            
            
        }
        
        
         /**
         * This is the function that undeletes plantation batched street
         */
        public function actionundeleteassetbatchseries(){
            
            $_id = $_POST['id'];
            $model= FmAirportAssetSeries::model()->findByPk($_id);
            
                if($this->isThisBatchSeriesWithAssets($_id)){
                      $model->batch_series_remaining_slot = (int)$model->batch_series_remaining_slot - 1;
                      
                  }else{
                     $model->batch_series_remaining_slot=$model->batch_series_remaining_slot; 
                  }
                 
                  $model->is_deleted = 0;   
                  
                  if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->save()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->asset_series_name' Asset Batch Series is successfully undeleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'undeletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                } 
    
            
        }
        
}
