# ext-theme-neptune-b8a326fc-4a0a-456d-877d-ad394ca3c843/resources

This folder contains static resources (typically an `"images"` folder as well).
