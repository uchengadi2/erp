<?php

/**
 * This is the model class for table "agrant_property_pond_asset".
 *
 * The followings are the available columns in table 'agrant_property_pond_asset':
 * @property string $id
 * @property string $pond_batch_id
 * @property integer $pond_unique_number
 * @property integer $number_of_ponds
 * @property string $short_description
 * @property string $description
 * @property string $accounting_preference
 * @property string $method_of_acquisition
 * @property string $acquired_from
 * @property integer $property_pond_gl_id
 * @property string $pond_type
 * @property string $pond_technology_type
 * @property string $pond_location
 * @property integer $pond_capacity
 * @property double $dimension_width
 * @property double $dimension_height
 * @property double $dimension_depth
 * @property double $acquisition_cost
 * @property double $construction_cost
 * @property integer $primary_source_document_number_id
 * @property integer $is_acquisition_approved
 * @property string $date_acquired
 * @property string $acquisition_approved_date
 * @property string $update_time
 * @property integer $acquisition_approved_id
 * @property integer $acquisition_enterred_by_id
 * @property integer $transaction_type_id
 *
 * The followings are the available model relations:
 * @property AgrantPropertyBatchedPondsAsset $pondBatch
 */
class AgrantPropertyPondAsset extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'agrant_property_pond_asset';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('pond_batch_id, pond_unique_number', 'required'),
			array('pond_unique_number, number_of_ponds, property_pond_gl_id, pond_capacity, primary_source_document_number_id, is_acquisition_approved, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id', 'numerical', 'integerOnly'=>true),
			array('dimension_width, dimension_height, dimension_depth, acquisition_cost, construction_cost', 'numerical'),
			array('pond_batch_id, accounting_preference', 'length', 'max'=>10),
			array('short_description, method_of_acquisition, acquired_from, pond_type, pond_technology_type, pond_location', 'length', 'max'=>250),
			array('description, date_acquired, acquisition_approved_date, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, pond_batch_id, pond_unique_number, number_of_ponds, short_description, description, accounting_preference, method_of_acquisition, acquired_from, property_pond_gl_id, pond_type, pond_technology_type, pond_location, pond_capacity, dimension_width, dimension_height, dimension_depth, acquisition_cost, construction_cost, primary_source_document_number_id, is_acquisition_approved, date_acquired, acquisition_approved_date, update_time, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'pondBatch' => array(self::BELONGS_TO, 'AgrantPropertyBatchedPondsAsset', 'pond_batch_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'pond_batch_id' => 'Pond Batch',
			'pond_unique_number' => 'Pond Unique Number',
			'number_of_ponds' => 'Number Of Ponds',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'accounting_preference' => 'Accounting Preference',
			'method_of_acquisition' => 'Method Of Acquisition',
			'acquired_from' => 'Acquired From',
			'property_pond_gl_id' => 'Property Pond Gl',
			'pond_type' => 'Pond Type',
			'pond_technology_type' => 'Pond Technology Type',
			'pond_location' => 'Pond Location',
			'pond_capacity' => 'Pond Capacity',
			'dimension_width' => 'Dimension Width',
			'dimension_height' => 'Dimension Height',
			'dimension_depth' => 'Dimension Depth',
			'acquisition_cost' => 'Acquisition Cost',
			'construction_cost' => 'Construction Cost',
			'primary_source_document_number_id' => 'Primary Source Document Number',
			'is_acquisition_approved' => 'Is Acquisition Approved',
			'date_acquired' => 'Date Acquired',
			'acquisition_approved_date' => 'Acquisition Approved Date',
			'update_time' => 'Update Time',
			'acquisition_approved_id' => 'Acquisition Approved',
			'acquisition_enterred_by_id' => 'Acquisition Enterred By',
			'transaction_type_id' => 'Transaction Type',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('pond_batch_id',$this->pond_batch_id,true);
		$criteria->compare('pond_unique_number',$this->pond_unique_number);
		$criteria->compare('number_of_ponds',$this->number_of_ponds);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('accounting_preference',$this->accounting_preference,true);
		$criteria->compare('method_of_acquisition',$this->method_of_acquisition,true);
		$criteria->compare('acquired_from',$this->acquired_from,true);
		$criteria->compare('property_pond_gl_id',$this->property_pond_gl_id);
		$criteria->compare('pond_type',$this->pond_type,true);
		$criteria->compare('pond_technology_type',$this->pond_technology_type,true);
		$criteria->compare('pond_location',$this->pond_location,true);
		$criteria->compare('pond_capacity',$this->pond_capacity);
		$criteria->compare('dimension_width',$this->dimension_width);
		$criteria->compare('dimension_height',$this->dimension_height);
		$criteria->compare('dimension_depth',$this->dimension_depth);
		$criteria->compare('acquisition_cost',$this->acquisition_cost);
		$criteria->compare('construction_cost',$this->construction_cost);
		$criteria->compare('primary_source_document_number_id',$this->primary_source_document_number_id);
		$criteria->compare('is_acquisition_approved',$this->is_acquisition_approved);
		$criteria->compare('date_acquired',$this->date_acquired,true);
		$criteria->compare('acquisition_approved_date',$this->acquisition_approved_date,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('acquisition_approved_id',$this->acquisition_approved_id);
		$criteria->compare('acquisition_enterred_by_id',$this->acquisition_enterred_by_id);
		$criteria->compare('transaction_type_id',$this->transaction_type_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AgrantPropertyPondAsset the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
