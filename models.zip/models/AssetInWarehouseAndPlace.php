<?php

/**
 * This is the model class for table "asset_in_warehouse_and_place".
 *
 * The followings are the available columns in table 'asset_in_warehouse_and_place':
 * @property string $id
 * @property string $description
 * @property string $warehouse_and_place_allocation_id
 * @property integer $production_asset_id
 * @property integer $series_id
 * @property integer $slot_id
 * @property double $allocated_storage_capacity_in_cubic_feet
 * @property double $quantity_of_assets_in_capacity
 * @property double $warehousing_allocation_cost
 * @property integer $warehousing_duration_in_weeks
 * @property string $date_initiated
 * @property string $date_approved
 * @property integer $initiated_by_id
 * @property integer $approved_by_id
 * @property integer $is_approved
 * @property integer $is_modification_approved
 * @property integer $is_deleted
 * @property integer $is_rejected
 *
 * The followings are the available model relations:
 * @property AllocateWarehouseStorageSpace $warehouseAndPlaceAllocation
 * @property AssetOnRequisition[] $assetOnRequisitions
 */
class AssetInWarehouseAndPlace extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'asset_in_warehouse_and_place';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('warehouse_and_place_allocation_id', 'required'),
			array('production_asset_id, series_id, slot_id, warehousing_duration_in_weeks, initiated_by_id, approved_by_id, is_approved, is_modification_approved, is_deleted, is_rejected', 'numerical', 'integerOnly'=>true),
			array('allocated_storage_capacity_in_cubic_feet, quantity_of_assets_in_capacity, warehousing_allocation_cost', 'numerical'),
			array('warehouse_and_place_allocation_id', 'length', 'max'=>10),
			array('description, date_initiated, date_approved', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, description, warehouse_and_place_allocation_id, production_asset_id, series_id, slot_id, allocated_storage_capacity_in_cubic_feet, quantity_of_assets_in_capacity, warehousing_allocation_cost, warehousing_duration_in_weeks, date_initiated, date_approved, initiated_by_id, approved_by_id, is_approved, is_modification_approved, is_deleted, is_rejected', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'warehouseAndPlaceAllocation' => array(self::BELONGS_TO, 'AllocateWarehouseStorageSpace', 'warehouse_and_place_allocation_id'),
			'assetOnRequisitions' => array(self::HAS_MANY, 'AssetOnRequisition', 'asset_in_warehouse_and_place_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'description' => 'Description',
			'warehouse_and_place_allocation_id' => 'Warehouse And Place Allocation',
			'production_asset_id' => 'Production Asset',
			'series_id' => 'Series',
			'slot_id' => 'Slot',
			'allocated_storage_capacity_in_cubic_feet' => 'Allocated Storage Capacity In Cubic Feet',
			'quantity_of_assets_in_capacity' => 'Quantity Of Assets In Capacity',
			'warehousing_allocation_cost' => 'Warehousing Allocation Cost',
			'warehousing_duration_in_weeks' => 'Warehousing Duration In Weeks',
			'date_initiated' => 'Date Initiated',
			'date_approved' => 'Date Approved',
			'initiated_by_id' => 'Initiated By',
			'approved_by_id' => 'Approved By',
			'is_approved' => 'Is Approved',
			'is_modification_approved' => 'Is Modification Approved',
			'is_deleted' => 'Is Deleted',
			'is_rejected' => 'Is Rejected',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('warehouse_and_place_allocation_id',$this->warehouse_and_place_allocation_id,true);
		$criteria->compare('production_asset_id',$this->production_asset_id);
		$criteria->compare('series_id',$this->series_id);
		$criteria->compare('slot_id',$this->slot_id);
		$criteria->compare('allocated_storage_capacity_in_cubic_feet',$this->allocated_storage_capacity_in_cubic_feet);
		$criteria->compare('quantity_of_assets_in_capacity',$this->quantity_of_assets_in_capacity);
		$criteria->compare('warehousing_allocation_cost',$this->warehousing_allocation_cost);
		$criteria->compare('warehousing_duration_in_weeks',$this->warehousing_duration_in_weeks);
		$criteria->compare('date_initiated',$this->date_initiated,true);
		$criteria->compare('date_approved',$this->date_approved,true);
		$criteria->compare('initiated_by_id',$this->initiated_by_id);
		$criteria->compare('approved_by_id',$this->approved_by_id);
		$criteria->compare('is_approved',$this->is_approved);
		$criteria->compare('is_modification_approved',$this->is_modification_approved);
		$criteria->compare('is_deleted',$this->is_deleted);
		$criteria->compare('is_rejected',$this->is_rejected);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AssetInWarehouseAndPlace the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * this is the function that updates the stock quantity assigned to a warehouse
         */
        public function updateItemQuantityInWarehouseAndPlace($asset_in_warehouse_and_place_id,$requested_quantity,$quantity_in_stockt){
            $id = $asset_in_warehouse_and_place_id;
            
           $model= AssetInWarehouseAndPlace::model()->findByPk($id);
           
           $new_quantity = $quantity_in_stockt - $requested_quantity;
           
           $model->quantity_of_assets_in_capacity = $new_quantity;
           
           if($model->save()){
               
               return true;
           }else{
               return false;
           }
            
        }
}
