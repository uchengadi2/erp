<?php

/**
 * This is the model class for table "fm_transport_station_asset_series_slot".
 *
 * The followings are the available columns in table 'fm_transport_station_asset_series_slot':
 * @property string $id
 * @property string $asset_series_id
 * @property string $slot_unique_number
 * @property integer $number_of_sections
 * @property string $slot_name
 * @property string $short_description
 * @property string $section_type
 * @property string $other_section_type
 * @property string $description
 * @property integer $slot_gl_id
 * @property integer $contract_duration_in_months
 * @property double $average_contract_cost_per_section
 *
 * The followings are the available model relations:
 * @property FmTransportStationAssetSeries $assetSeries
 */
class FmTransportStationAssetSeriesSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'fm_transport_station_asset_series_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('asset_series_id', 'required'),
			array('number_of_sections, slot_gl_id, contract_duration_in_months', 'numerical', 'integerOnly'=>true),
			array('average_contract_cost_per_section', 'numerical'),
			array('asset_series_id', 'length', 'max'=>10),
			array('slot_unique_number, slot_name, short_description, other_section_type', 'length', 'max'=>250),
			array('section_type', 'length', 'max'=>17),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, asset_series_id, slot_unique_number, number_of_sections, slot_name, short_description, section_type, other_section_type, description, slot_gl_id, contract_duration_in_months, average_contract_cost_per_section', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'assetSeries' => array(self::BELONGS_TO, 'FmTransportStationAssetSeries', 'asset_series_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'asset_series_id' => 'Asset Series',
			'slot_unique_number' => 'Slot Unique Number',
			'number_of_sections' => 'Number Of Sections',
			'slot_name' => 'Slot Name',
			'short_description' => 'Short Description',
			'section_type' => 'Section Type',
			'other_section_type' => 'Other Section Type',
			'description' => 'Description',
			'slot_gl_id' => 'Slot Gl',
			'contract_duration_in_months' => 'Contract Duration In Months',
			'average_contract_cost_per_section' => 'Average Contract Cost Per Section',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('asset_series_id',$this->asset_series_id,true);
		$criteria->compare('slot_unique_number',$this->slot_unique_number,true);
		$criteria->compare('number_of_sections',$this->number_of_sections);
		$criteria->compare('slot_name',$this->slot_name,true);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('section_type',$this->section_type,true);
		$criteria->compare('other_section_type',$this->other_section_type,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('slot_gl_id',$this->slot_gl_id);
		$criteria->compare('contract_duration_in_months',$this->contract_duration_in_months);
		$criteria->compare('average_contract_cost_per_section',$this->average_contract_cost_per_section);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FmTransportStationAssetSeriesSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($asset_series_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('fm_transport_station_asset_series_slot')
                    ->where("asset_series_id=$asset_series_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= FmTransportStationAssetSeriesSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
