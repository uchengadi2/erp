<?php

/**
 * This is the model class for table "agrant_inventory_batched_livestock_asset".
 *
 * The followings are the available columns in table 'agrant_inventory_batched_livestock_asset':
 * @property string $id
 * @property string $production_asset_id
 * @property string $sol_id
 * @property integer $inventory_batch_livestock_unique_number
 * @property integer $total_number_of_inventory_livestock
 * @property string $short_description
 * @property string $description
 * @property string $inventory_livestock_type
 * @property string $accounting_preference
 * @property string $method_of_acquisition
 * @property string $other_acquisition_method
 * @property string $acquired_from
 * @property integer $inventory_livestock_gl_id
 * @property integer $number_to_split_batch
 * @property string $batch_split_parameter
 * @property string $other_batch_split_parameter
 * @property double $total_cost
 * @property double $average_cost_per_unit
 * @property double $delivery_cost
 * @property double $loading_cost
 * @property integer $primary_source_document_number_id
 * @property integer $is_acquisition_approved
 * @property string $date_acquired
 * @property string $acquisition_approved_date
 * @property string $update_time
 * @property integer $acquisition_approved_id
 * @property integer $acquisition_enterred_by_id
 * @property integer $transaction_type_id
 * @property double $average_weight_in_kg
 * @property integer $update_user_id
 * @property string $create_time
 *
 * The followings are the available model relations:
 * @property ServiceOutlet $sol
 * @property ProductionAssets $productionAsset
 * @property AgrantInventoryLivestockAssetSlot[] $agrantInventoryLivestockAssetSlots
 */
class AgrantInventoryBatchedLivestockAsset extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'agrant_inventory_batched_livestock_asset';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('production_asset_id, sol_id, inventory_livestock_type, accounting_preference, method_of_acquisition', 'required'),
			array('total_number_of_inventory_livestock, inventory_livestock_gl_id, number_to_split_batch, primary_source_document_number_id, is_acquisition_approved, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('total_cost, average_cost_per_unit, delivery_cost, loading_cost, average_weight_in_kg', 'numerical'),
			array('production_asset_id, sol_id', 'length', 'max'=>10),
			array('inventory_batch_livestock_unique_number,short_description, other_acquisition_method, acquired_from, other_batch_split_parameter', 'length', 'max'=>250),
			array('inventory_livestock_type, batch_split_parameter', 'length', 'max'=>6),
			array('accounting_preference', 'length', 'max'=>11),
			array('method_of_acquisition', 'length', 'max'=>9),
			array('description, date_acquired, acquisition_approved_date, update_time, create_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, production_asset_id, sol_id, inventory_batch_livestock_unique_number, total_number_of_inventory_livestock, short_description, description, inventory_livestock_type, accounting_preference, method_of_acquisition, other_acquisition_method, acquired_from, inventory_livestock_gl_id, number_to_split_batch, batch_split_parameter, other_batch_split_parameter, total_cost, average_cost_per_unit, delivery_cost, loading_cost, primary_source_document_number_id, is_acquisition_approved, date_acquired, acquisition_approved_date, update_time, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id, average_weight_in_kg, update_user_id, create_time', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'sol' => array(self::BELONGS_TO, 'ServiceOutlet', 'sol_id'),
			'productionAsset' => array(self::BELONGS_TO, 'ProductionAssets', 'production_asset_id'),
			'agrantInventoryLivestockAssetSlots' => array(self::HAS_MANY, 'AgrantInventoryLivestockAssetSlot', 'inventory_livestock_batch_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'production_asset_id' => 'Production Asset',
			'sol_id' => 'Sol',
			'inventory_batch_livestock_unique_number' => 'Inventory Batch Livestock Unique Number',
			'total_number_of_inventory_livestock' => 'Total Number Of Inventory Livestock',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'inventory_livestock_type' => 'Inventory Livestock Type',
			'accounting_preference' => 'Accounting Preference',
			'method_of_acquisition' => 'Method Of Acquisition',
			'other_acquisition_method' => 'Other Acquisition Method',
			'acquired_from' => 'Acquired From',
			'inventory_livestock_gl_id' => 'Inventory Livestock Gl',
			'number_to_split_batch' => 'Number To Split Batch',
			'batch_split_parameter' => 'Batch Split Parameter',
			'other_batch_split_parameter' => 'Other Batch Split Parameter',
			'total_cost' => 'Total Cost',
			'average_cost_per_unit' => 'Average Cost Per Unit',
			'delivery_cost' => 'Delivery Cost',
			'loading_cost' => 'Loading Cost',
			'primary_source_document_number_id' => 'Primary Source Document Number',
			'is_acquisition_approved' => 'Is Acquisition Approved',
			'date_acquired' => 'Date Acquired',
			'acquisition_approved_date' => 'Acquisition Approved Date',
			'update_time' => 'Update Time',
			'acquisition_approved_id' => 'Acquisition Approved',
			'acquisition_enterred_by_id' => 'Acquisition Enterred By',
			'transaction_type_id' => 'Transaction Type',
			'average_weight_in_kg' => 'Average Weight In Kg',
			'update_user_id' => 'Update User',
			'create_time' => 'Create Time',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('production_asset_id',$this->production_asset_id,true);
		$criteria->compare('sol_id',$this->sol_id,true);
		$criteria->compare('inventory_batch_livestock_unique_number',$this->inventory_batch_livestock_unique_number);
		$criteria->compare('total_number_of_inventory_livestock',$this->total_number_of_inventory_livestock);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('inventory_livestock_type',$this->inventory_livestock_type,true);
		$criteria->compare('accounting_preference',$this->accounting_preference,true);
		$criteria->compare('method_of_acquisition',$this->method_of_acquisition,true);
		$criteria->compare('other_acquisition_method',$this->other_acquisition_method,true);
		$criteria->compare('acquired_from',$this->acquired_from,true);
		$criteria->compare('inventory_livestock_gl_id',$this->inventory_livestock_gl_id);
		$criteria->compare('number_to_split_batch',$this->number_to_split_batch);
		$criteria->compare('batch_split_parameter',$this->batch_split_parameter,true);
		$criteria->compare('other_batch_split_parameter',$this->other_batch_split_parameter,true);
		$criteria->compare('total_cost',$this->total_cost);
		$criteria->compare('average_cost_per_unit',$this->average_cost_per_unit);
		$criteria->compare('delivery_cost',$this->delivery_cost);
		$criteria->compare('loading_cost',$this->loading_cost);
		$criteria->compare('primary_source_document_number_id',$this->primary_source_document_number_id);
		$criteria->compare('is_acquisition_approved',$this->is_acquisition_approved);
		$criteria->compare('date_acquired',$this->date_acquired,true);
		$criteria->compare('acquisition_approved_date',$this->acquisition_approved_date,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('acquisition_approved_id',$this->acquisition_approved_id);
		$criteria->compare('acquisition_enterred_by_id',$this->acquisition_enterred_by_id);
		$criteria->compare('transaction_type_id',$this->transaction_type_id);
		$criteria->compare('average_weight_in_kg',$this->average_weight_in_kg);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('create_time',$this->create_time,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AgrantInventoryBatchedLivestockAsset the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
        /**
         * This is the function that generate an asset batch series number
         */
        public function generateTheSDSAssetBatchSeriesUniqueNumber(){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = "IL" . $next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = "IL" . $nextplus;
            }
            
            return $code;
        }
        
        
        /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= AgrantInventoryBatchedLivestockAsset::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['batch_series_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
        
        
         /**
         * This is the function that reduces the remaining number of batch series
         */
        public function reduceTheRemainNumberOfBatchSeries($id){
            
             $criteria = new CDbCriteria();
            $criteria->select = '*';
           $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $asset= AgrantInventoryBatchedLivestockAsset::model()->find($criteria);
            
            $new_batch_series_remaining_slot = (int)$asset['batch_series_remaining_slot'] - 1;
            
            
          $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('agrant_inventory_batched_livestock_asset',
                                  array(
                                    'batch_series_remaining_slot'=>$new_batch_series_remaining_slot
                                   
                               
		
                            ),
                     ("id=$id"));
            
            return $new_batch_series_remaining_slot;
           
           
        }
        
        
        
         /**
         * This is the function that retrieves the remaining number of batch series
         */
        public function retrieveTheRemainingBatchSlot($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $asset= AgrantInventoryBatchedLivestockAsset::model()->find($criteria);
            
            return $asset['batch_series_remaining_slot'];
        }
}
