<?php

/**
 * This is the model class for table "agrant_charcoal_asset_slot".
 *
 * The followings are the available columns in table 'agrant_charcoal_asset_slot':
 * @property string $id
 * @property string $charcoal_batch_id
 * @property integer $charcoal_unique_number
 * @property double $quantity_in_kg
 * @property string $short_description
 * @property string $description
 * @property string $slot_name
 * @property string $charcoal_type
 * @property integer $slot_gl_id
 * @property double $total_slots_cost
 * @property double $delivery_cost
 * @property double $loading_cost
 * @property double $bagging_cost
 * @property integer $is_certified
 * @property string $certification_method
 * @property string $certification_by
 * @property integer $is_charcoal_packed
 *
 * The followings are the available model relations:
 * @property AgrantBatchCharcoalAsset $charcoalBatch
 */
class AgrantCharcoalAssetSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'agrant_charcoal_asset_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('charcoal_batch_id', 'required'),
			array('slot_gl_id, is_certified, is_charcoal_packed', 'numerical', 'integerOnly'=>true),
			array('quantity_in_kg, total_slots_cost, delivery_cost, loading_cost, bagging_cost', 'numerical'),
			array('charcoal_batch_id', 'length', 'max'=>10),
			array('charcoal_unique_number,short_description, slot_name, charcoal_type, certification_method, certification_by', 'length', 'max'=>250),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, charcoal_batch_id, charcoal_unique_number, quantity_in_kg, short_description, description, slot_name, charcoal_type, slot_gl_id, total_slots_cost, delivery_cost, loading_cost, bagging_cost, is_certified, certification_method, certification_by, is_charcoal_packed', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'charcoalBatch' => array(self::BELONGS_TO, 'AgrantBatchCharcoalAsset', 'charcoal_batch_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'charcoal_batch_id' => 'Charcoal Batch',
			'charcoal_unique_number' => 'Charcoal Unique Number',
			'quantity_in_kg' => 'Quantity In Kg',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'slot_name' => 'Slot Name',
			'charcoal_type' => 'Charcoal Type',
			'slot_gl_id' => 'Slot Gl',
			'total_slots_cost' => 'Total Slots Cost',
			'delivery_cost' => 'Delivery Cost',
			'loading_cost' => 'Loading Cost',
			'bagging_cost' => 'Bagging Cost',
			'is_certified' => 'Is Certified',
			'certification_method' => 'Certification Method',
			'certification_by' => 'Certification By',
			'is_charcoal_packed' => 'Is Charcoal Packed',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('charcoal_batch_id',$this->charcoal_batch_id,true);
		$criteria->compare('charcoal_unique_number',$this->charcoal_unique_number);
		$criteria->compare('quantity_in_kg',$this->quantity_in_kg);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('slot_name',$this->slot_name,true);
		$criteria->compare('charcoal_type',$this->charcoal_type,true);
		$criteria->compare('slot_gl_id',$this->slot_gl_id);
		$criteria->compare('total_slots_cost',$this->total_slots_cost);
		$criteria->compare('delivery_cost',$this->delivery_cost);
		$criteria->compare('loading_cost',$this->loading_cost);
		$criteria->compare('bagging_cost',$this->bagging_cost);
		$criteria->compare('is_certified',$this->is_certified);
		$criteria->compare('certification_method',$this->certification_method,true);
		$criteria->compare('certification_by',$this->certification_by,true);
		$criteria->compare('is_charcoal_packed',$this->is_charcoal_packed);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AgrantCharcoalAssetSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
         /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($asset_series_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('agrant_charcoal_asset_slot')
                    ->where("charcoal_batch_id=$asset_series_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= AgrantCharcoalAssetSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
