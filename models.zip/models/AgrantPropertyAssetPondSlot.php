<?php

/**
 * This is the model class for table "agrant_property_asset_pond_slot".
 *
 * The followings are the available columns in table 'agrant_property_asset_pond_slot':
 * @property string $id
 * @property string $pond_batch_id
 * @property integer $pond_unique_number
 * @property integer $number_of_ponds
 * @property string $short_description
 * @property string $description
 * @property string $slot_name
 * @property integer $slot_gl_id
 * @property string $pond_type
 * @property string $pond_technology_type
 * @property string $pond_location
 * @property integer $pond_capacity
 * @property double $dimension_width
 * @property double $dimension_height
 * @property double $dimension_depth
 * @property double $acquisition_cost
 * @property double $construction_cost
 *
 * The followings are the available model relations:
 * @property AgrantPropertyBatchedPondsAsset $pondBatch
 */
class AgrantPropertyAssetPondSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'agrant_property_asset_pond_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('pond_batch_id, pond_unique_number', 'required'),
			array('pond_unique_number, number_of_ponds, slot_gl_id, pond_capacity', 'numerical', 'integerOnly'=>true),
			array('dimension_width, dimension_height, dimension_depth, acquisition_cost, construction_cost', 'numerical'),
			array('pond_batch_id', 'length', 'max'=>10),
			array('short_description, slot_name, pond_type, pond_technology_type, pond_location', 'length', 'max'=>250),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, pond_batch_id, pond_unique_number, number_of_ponds, short_description, description, slot_name, slot_gl_id, pond_type, pond_technology_type, pond_location, pond_capacity, dimension_width, dimension_height, dimension_depth, acquisition_cost, construction_cost', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'pondBatch' => array(self::BELONGS_TO, 'AgrantPropertyBatchedPondsAsset', 'pond_batch_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'pond_batch_id' => 'Pond Batch',
			'pond_unique_number' => 'Pond Unique Number',
			'number_of_ponds' => 'Number Of Ponds',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'slot_name' => 'Slot Name',
			'slot_gl_id' => 'Slot Gl',
			'pond_type' => 'Pond Type',
			'pond_technology_type' => 'Pond Technology Type',
			'pond_location' => 'Pond Location',
			'pond_capacity' => 'Pond Capacity',
			'dimension_width' => 'Dimension Width',
			'dimension_height' => 'Dimension Height',
			'dimension_depth' => 'Dimension Depth',
			'acquisition_cost' => 'Acquisition Cost',
			'construction_cost' => 'Construction Cost',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('pond_batch_id',$this->pond_batch_id,true);
		$criteria->compare('pond_unique_number',$this->pond_unique_number);
		$criteria->compare('number_of_ponds',$this->number_of_ponds);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('slot_name',$this->slot_name,true);
		$criteria->compare('slot_gl_id',$this->slot_gl_id);
		$criteria->compare('pond_type',$this->pond_type,true);
		$criteria->compare('pond_technology_type',$this->pond_technology_type,true);
		$criteria->compare('pond_location',$this->pond_location,true);
		$criteria->compare('pond_capacity',$this->pond_capacity);
		$criteria->compare('dimension_width',$this->dimension_width);
		$criteria->compare('dimension_height',$this->dimension_height);
		$criteria->compare('dimension_depth',$this->dimension_depth);
		$criteria->compare('acquisition_cost',$this->acquisition_cost);
		$criteria->compare('construction_cost',$this->construction_cost);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AgrantPropertyAssetPondSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
