<?php

/**
 * This is the model class for table "release_deallocated_asset_in_project".
 *
 * The followings are the available columns in table 'release_deallocated_asset_in_project':
 * @property string $id
 * @property string $deallocated_asset_for_project_id
 * @property string $description
 * @property double $quantity_for_release
 * @property string $measurement_unit
 * @property integer $released_to_warehouse_and_place_id
 * @property string $other_released_location
 * @property string $date_asset_released
 * @property integer $release_user_id
 * @property integer $update_user_id
 * @property integer $is_approved
 * @property integer $is_deleted
 * @property integer $is_rejected
 * @property integer $is_modification_approved
 *
 * The followings are the available model relations:
 * @property DeallocatedAssetForProject $deallocatedAssetForProject
 */
class ReleaseDeallocatedAssetInProject extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'release_deallocated_asset_in_project';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('deallocated_asset_for_project_id', 'required'),
			array('released_to_warehouse_and_place_id, release_user_id, update_user_id, is_approved, is_deleted, is_rejected, is_modification_approved', 'numerical', 'integerOnly'=>true),
			array('quantity_for_release', 'numerical'),
			array('deallocated_asset_for_project_id', 'length', 'max'=>10),
			array('measurement_unit, other_released_location', 'length', 'max'=>250),
			array('description, date_asset_released', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, deallocated_asset_for_project_id, description, quantity_for_release, measurement_unit, released_to_warehouse_and_place_id, other_released_location, date_asset_released, release_user_id, update_user_id, is_approved, is_deleted, is_rejected, is_modification_approved', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'deallocatedAssetForProject' => array(self::BELONGS_TO, 'DeallocatedAssetForProject', 'deallocated_asset_for_project_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'deallocated_asset_for_project_id' => 'Deallocated Asset For Project',
			'description' => 'Description',
			'quantity_for_release' => 'Quantity For Release',
			'measurement_unit' => 'Measurement Unit',
			'released_to_warehouse_and_place_id' => 'Released To Warehouse And Place',
			'other_released_location' => 'Other Released Location',
			'date_asset_released' => 'Date Asset Released',
			'release_user_id' => 'Release User',
			'update_user_id' => 'Update User',
			'is_approved' => 'Is Approved',
			'is_deleted' => 'Is Deleted',
			'is_rejected' => 'Is Rejected',
			'is_modification_approved' => 'Is Modification Approved',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('deallocated_asset_for_project_id',$this->deallocated_asset_for_project_id,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('quantity_for_release',$this->quantity_for_release);
		$criteria->compare('measurement_unit',$this->measurement_unit,true);
		$criteria->compare('released_to_warehouse_and_place_id',$this->released_to_warehouse_and_place_id);
		$criteria->compare('other_released_location',$this->other_released_location,true);
		$criteria->compare('date_asset_released',$this->date_asset_released,true);
		$criteria->compare('release_user_id',$this->release_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('is_approved',$this->is_approved);
		$criteria->compare('is_deleted',$this->is_deleted);
		$criteria->compare('is_rejected',$this->is_rejected);
		$criteria->compare('is_modification_approved',$this->is_modification_approved);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ReleaseDeallocatedAssetInProject the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
