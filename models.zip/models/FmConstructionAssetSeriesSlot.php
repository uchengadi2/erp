<?php

/**
 * This is the model class for table "fm_construction_asset_series_slot".
 *
 * The followings are the available columns in table 'fm_construction_asset_series_slot':
 * @property string $id
 * @property string $asset_series_id
 * @property string $slot_unique_number
 * @property integer $number_of_stocks
 * @property string $slot_name
 * @property string $short_description
 * @property string $activity
 * @property string $other_activity
 * @property string $stock_type
 * @property string $stock_name
 * @property string $stock_model
 * @property string $stock_manufacturer
 * @property string $description
 * @property integer $slot_gl_id
 * @property integer $contract_duration_in_months
 * @property string $location
 * @property double $total_slot_cost
 * @property double $delivery_cost
 * @property string $method_of_acquisition
 * @property string $other_acquisition_method
 * @property string $acquired_from
 * @property integer $series_slot_incrementer
 * @property string $date_acquired
 * @property string $stock_brand
 * @property double $average_contract_cost_per_stock
 *
 * The followings are the available model relations:
 * @property FmConstructionAssetSeries $assetSeries
 */
class FmConstructionAssetSeriesSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'fm_construction_asset_series_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('asset_series_id, method_of_acquisition', 'required'),
			array('number_of_stocks, slot_gl_id, contract_duration_in_months, series_slot_incrementer', 'numerical', 'integerOnly'=>true),
			array('total_slot_cost, delivery_cost, average_contract_cost_per_stock', 'numerical'),
			array('asset_series_id', 'length', 'max'=>10),
			array('slot_unique_number, slot_name, short_description, activity, other_activity, stock_type, stock_name, stock_model, stock_manufacturer, location, other_acquisition_method, acquired_from, stock_brand', 'length', 'max'=>250),
			array('method_of_acquisition', 'length', 'max'=>9),
			array('description, date_acquired', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, asset_series_id, slot_unique_number, number_of_stocks, slot_name, short_description, activity, other_activity, stock_type, stock_name, stock_model, stock_manufacturer, description, slot_gl_id, contract_duration_in_months, location, total_slot_cost, delivery_cost, method_of_acquisition, other_acquisition_method, acquired_from, series_slot_incrementer, date_acquired, stock_brand, average_contract_cost_per_stock', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'assetSeries' => array(self::BELONGS_TO, 'FmConstructionAssetSeries', 'asset_series_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'asset_series_id' => 'Asset Series',
			'slot_unique_number' => 'Slot Unique Number',
			'number_of_stocks' => 'Number Of Stocks',
			'slot_name' => 'Slot Name',
			'short_description' => 'Short Description',
			'activity' => 'Activity',
			'other_activity' => 'Other Activity',
			'stock_type' => 'Stock Type',
			'stock_name' => 'Stock Name',
			'stock_model' => 'Stock Model',
			'stock_manufacturer' => 'Stock Manufacturer',
			'description' => 'Description',
			'slot_gl_id' => 'Slot Gl',
			'contract_duration_in_months' => 'Contract Duration In Months',
			'location' => 'Location',
			'total_slot_cost' => 'Total Slot Cost',
			'delivery_cost' => 'Delivery Cost',
			'method_of_acquisition' => 'Method Of Acquisition',
			'other_acquisition_method' => 'Other Acquisition Method',
			'acquired_from' => 'Acquired From',
			'series_slot_incrementer' => 'Series Slot Incrementer',
			'date_acquired' => 'Date Acquired',
			'stock_brand' => 'Stock Brand',
			'average_contract_cost_per_stock' => 'Average Contract Cost Per Stock',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('asset_series_id',$this->asset_series_id,true);
		$criteria->compare('slot_unique_number',$this->slot_unique_number,true);
		$criteria->compare('number_of_stocks',$this->number_of_stocks);
		$criteria->compare('slot_name',$this->slot_name,true);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('activity',$this->activity,true);
		$criteria->compare('other_activity',$this->other_activity,true);
		$criteria->compare('stock_type',$this->stock_type,true);
		$criteria->compare('stock_name',$this->stock_name,true);
		$criteria->compare('stock_model',$this->stock_model,true);
		$criteria->compare('stock_manufacturer',$this->stock_manufacturer,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('slot_gl_id',$this->slot_gl_id);
		$criteria->compare('contract_duration_in_months',$this->contract_duration_in_months);
		$criteria->compare('location',$this->location,true);
		$criteria->compare('total_slot_cost',$this->total_slot_cost);
		$criteria->compare('delivery_cost',$this->delivery_cost);
		$criteria->compare('method_of_acquisition',$this->method_of_acquisition,true);
		$criteria->compare('other_acquisition_method',$this->other_acquisition_method,true);
		$criteria->compare('acquired_from',$this->acquired_from,true);
		$criteria->compare('series_slot_incrementer',$this->series_slot_incrementer);
		$criteria->compare('date_acquired',$this->date_acquired,true);
		$criteria->compare('stock_brand',$this->stock_brand,true);
		$criteria->compare('average_contract_cost_per_stock',$this->average_contract_cost_per_stock);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FmConstructionAssetSeriesSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
        /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($asset_series_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('fm_construction_asset_series_slot')
                    ->where("asset_series_id=$asset_series_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= FmConstructionAssetSeriesSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
