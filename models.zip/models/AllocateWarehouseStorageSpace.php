<?php

/**
 * This is the model class for table "allocate_warehouse_storage_space".
 *
 * The followings are the available columns in table 'allocate_warehouse_storage_space':
 * @property string $id
 * @property string $description
 * @property string $warehouse_id
 * @property integer $service_outlet_id
 * @property double $allocated_storage_capacity_in_cubic_feet
 * @property double $allocation_cost
 * @property integer $allocation_duration_in_weeks
 * @property string $allocation_status
 * @property string $date_initiated
 * @property string $date_approved
 * @property integer $initiated_by_id
 * @property integer $approved_by_id
 * @property integer $is_approved
 * @property integer $warehouse_gl_id
 * @property integer $organization_id
 * @property integer $group_id
 *
 * The followings are the available model relations:
 * @property WarehouseAndPlace $warehouse
 */
class AllocateWarehouseStorageSpace extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'allocate_warehouse_storage_space';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('warehouse_id, allocation_status', 'required'),
			array('service_outlet_id, allocation_duration_in_weeks, initiated_by_id, approved_by_id, is_approved, warehouse_gl_id', 'numerical', 'integerOnly'=>true),
			array('allocated_storage_capacity_in_cubic_feet, allocation_cost', 'numerical'),
			array('warehouse_id, allocation_status', 'length', 'max'=>10),
			array('description, date_initiated, date_approved', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, description, warehouse_id, service_outlet_id, allocated_storage_capacity_in_cubic_feet, allocation_cost, allocation_duration_in_weeks, allocation_status, date_initiated, date_approved, initiated_by_id, approved_by_id, is_approved, warehouse_gl_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'warehouse' => array(self::BELONGS_TO, 'WarehouseAndPlace', 'warehouse_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'description' => 'Description',
			'warehouse_id' => 'Warehouse',
			'service_outlet_id' => 'Service Outlet',
			'allocated_storage_capacity_in_cubic_feet' => 'Allocated Storage Capacity In Cubic Feet',
			'allocation_cost' => 'Allocation Cost',
			'allocation_duration_in_weeks' => 'Allocation Duration In Weeks',
			'allocation_status' => 'Allocation Status',
			'date_initiated' => 'Date Initiated',
			'date_approved' => 'Date Approved',
			'initiated_by_id' => 'Initiated By',
			'approved_by_id' => 'Approved By',
			'is_approved' => 'Is Approved',
			'warehouse_gl_id' => 'Warehouse Gl',
			'organization_id' => 'Organization',
			'group_id' => 'Group',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('warehouse_id',$this->warehouse_id,true);
		$criteria->compare('service_outlet_id',$this->service_outlet_id);
		$criteria->compare('allocated_storage_capacity_in_cubic_feet',$this->allocated_storage_capacity_in_cubic_feet);
		$criteria->compare('allocation_cost',$this->allocation_cost);
		$criteria->compare('allocation_duration_in_weeks',$this->allocation_duration_in_weeks);
		$criteria->compare('allocation_status',$this->allocation_status,true);
		$criteria->compare('date_initiated',$this->date_initiated,true);
		$criteria->compare('date_approved',$this->date_approved,true);
		$criteria->compare('initiated_by_id',$this->initiated_by_id);
		$criteria->compare('approved_by_id',$this->approved_by_id);
		$criteria->compare('is_approved',$this->is_approved);
		$criteria->compare('warehouse_gl_id',$this->warehouse_gl_id);
		$criteria->compare('organization_id',$this->organization_id);
		$criteria->compare('group_id',$this->group_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AllocateWarehouseStorageSpace the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if a service outlet already has a warehouse and place allocation
         */
        public function isThisServiceOuletalreadyWithAllocation($warehouse_id,$service_outlet_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('allocate_warehouse_storage_space')
                    ->where("warehouse_id=$warehouse_id and service_outlet_id =$service_outlet_id ");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         public function getTheWarehouseAndPlaceOfThisAllocation($allocation_id){
             $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$allocation_id);
                $allocation= AllocateWarehouseStorageSpace::model()->find($criteria);
                
                return $allocation['warehouse_id'];
            
        }
        
        
        
         /**
         * This is the function that updates the used storage allocated space in a warehouse
         */
        public function updateTheUsedStorageCapacityForThisWarehouseAllocation($allocation_id,$total_of_used_storage_space){
              
            
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('allocate_warehouse_storage_space',
                                  array(
                                    'used_allocated_storage_capacity_in_cubic_feet'=>$total_of_used_storage_space
                                   
                               
		
                            ),
                     ("id=$allocation_id"));
                
                return $result;
        }
        
        
        
        
          /**
         * This is the function that updates the used storage allocated space in a warehouse
         */
        public function modifyTheUsedStorageCapacityForThisWarehouseAllocation($allocation_id,$warehouse_and_place_id,$sol_id,$total_of_used_storage_space){
           
            $_id = $allocation_id;
            $model= AllocateWarehouseStorageSpace::model()->findByPk($_id);
            
            $model->used_allocated_storage_capacity_in_cubic_feet = $total_of_used_storage_space;
            if($model->save()){
                return true;
            }else{
                return false;
            }
            
        }
}
