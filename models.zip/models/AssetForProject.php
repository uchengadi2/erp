<?php

/**
 * This is the model class for table "asset_for_project".
 *
 * The followings are the available columns in table 'asset_for_project':
 * @property string $id
 * @property string $project_id
 * @property string $asset_assignment_id
 * @property string $description
 * @property double $quantity
 * @property string $measurement_unit
 * @property string $date_allocated
 * @property integer $allocation_user_id
 * @property integer $update_user_id
 * @property integer $is_approved
 * @property integer $is_deleted
 * @property integer $is_rejected
 * @property integer $is_modification_approved
 *
 * The followings are the available model relations:
 * @property Project $project
 * @property AssetInWarehouseAndPlace $assetAssignment
 * @property AssetInProjectMaintenance[] $assetInProjectMaintenances
 * @property DeallocatedAssetForProject[] $deallocatedAssetForProjects
 */
class AssetForProject extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'asset_for_project';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('project_id, asset_assignment_id', 'required'),
			array('allocation_user_id, update_user_id, is_approved, is_deleted, is_rejected, is_modification_approved', 'numerical', 'integerOnly'=>true),
			array('quantity', 'numerical'),
			array('project_id, asset_assignment_id', 'length', 'max'=>10),
			array('measurement_unit', 'length', 'max'=>250),
			array('description, date_allocated', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, project_id, asset_assignment_id, description, quantity, measurement_unit, date_allocated, allocation_user_id, update_user_id, is_approved, is_deleted, is_rejected, is_modification_approved', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'project' => array(self::BELONGS_TO, 'Project', 'project_id'),
			'assetAssignment' => array(self::BELONGS_TO, 'AssetInWarehouseAndPlace', 'asset_assignment_id'),
			'assetInProjectMaintenances' => array(self::HAS_MANY, 'AssetInProjectMaintenance', 'asset_for_project_id'),
			'deallocatedAssetForProjects' => array(self::HAS_MANY, 'DeallocatedAssetForProject', 'asset_for_project_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'project_id' => 'Project',
			'asset_assignment_id' => 'Asset Assignment',
			'description' => 'Description',
			'quantity' => 'Quantity',
			'measurement_unit' => 'Measurement Unit',
			'date_allocated' => 'Date Allocated',
			'allocation_user_id' => 'Allocation User',
			'update_user_id' => 'Update User',
			'is_approved' => 'Is Approved',
			'is_deleted' => 'Is Deleted',
			'is_rejected' => 'Is Rejected',
			'is_modification_approved' => 'Is Modification Approved',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('project_id',$this->project_id,true);
		$criteria->compare('asset_assignment_id',$this->asset_assignment_id,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('quantity',$this->quantity);
		$criteria->compare('measurement_unit',$this->measurement_unit,true);
		$criteria->compare('date_allocated',$this->date_allocated,true);
		$criteria->compare('allocation_user_id',$this->allocation_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('is_approved',$this->is_approved);
		$criteria->compare('is_deleted',$this->is_deleted);
		$criteria->compare('is_rejected',$this->is_rejected);
		$criteria->compare('is_modification_approved',$this->is_modification_approved);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AssetForProject the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that generates the resource allocation reference code for a project
         */
        public function getTheResourceAllocationRefForThisProject($project_id,$sol_id,$incrementer){
            $model = new ServiceOutlet;
            
            $sol_code = $model->getTheServiceOutletCode($sol_id);
            
            //get this project number
            $project_number = $this->getThisProjectNumber($project_id);
            
            //generate a random number
                $random_number = $this->generateTheRandomNumber();
            
            $resource_allocation_code = $sol_code.$project_number.$random_number.$incrementer;
            
            return $resource_allocation_code;
            
        }
        
        
        /**
         * This is the function that gets a projects number
         */
        public function getThisProjectNumber($project_id){
            
            $model = new Project;
            return $model->getThisProjectNumber($project_id);
        }
        
        
         /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
        
               
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $allocations= AssetForProject::model()->findAll($criteria);
            
            foreach($allocations as $allot){
                $data[] = $allot['incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
        
        
        /**
         * This is the function that updates the quantity of assets in a project
         */
        public function updateTheQuantityOfAssetsInTheProject($id,$quantity){
            
             $model= AssetForProject::model()->findByPk($id);
            
            $new_quantity = $model->quantity - $quantity;
            
            $model->quantity = $new_quantity;
            
            if($model->save()){
                return true;
            }else{
                return false;
            }
            
        }
}
