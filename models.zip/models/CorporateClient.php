<?php

/**
 * This is the model class for table "corporate_client".
 *
 * The followings are the available columns in table 'corporate_client':
 * @property string $id
 * @property string $name
 * @property string $sector_id
 * @property string $email
 * @property string $address
 * @property string $phone_number
 * @property string $tax_identification_pin
 * @property string $vat_number
 * @property string $contact_person_name
 * @property string $contact_person_mobile_number
 * @property string $contact_person_email
 * @property string $clientid
 * @property string $description
 * @property string $code
 * @property integer $code_numbering
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Sector $sector
 */
class CorporateClient extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'corporate_client';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, sector_id, email, contact_person_name, contact_person_email', 'required'),
			array('code_numbering, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('name, email, address, contact_person_name, contact_person_email, code', 'length', 'max'=>250),
			array('sector_id', 'length', 'max'=>10),
			array('phone_number, tax_identification_pin, vat_number, contact_person_mobile_number', 'length', 'max'=>100),
			array('clientid', 'length', 'max'=>30),
			array('description, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, sector_id, email, address, phone_number, tax_identification_pin, vat_number, contact_person_name, contact_person_mobile_number, contact_person_email, clientid, description, code, code_numbering, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'sector' => array(self::BELONGS_TO, 'Sector', 'sector_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'sector_id' => 'Sector',
			'email' => 'Email',
			'address' => 'Address',
			'phone_number' => 'Phone Number',
			'tax_identification_pin' => 'Tax Identification Pin',
			'vat_number' => 'Vat Number',
			'contact_person_name' => 'Contact Person Name',
			'contact_person_mobile_number' => 'Contact Person Mobile Number',
			'contact_person_email' => 'Contact Person Email',
			'clientid' => 'Clientid',
			'description' => 'Description',
			'code' => 'Code',
			'code_numbering' => 'Code Numbering',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('sector_id',$this->sector_id,true);
		$criteria->compare('email',$this->email,true);
		$criteria->compare('address',$this->address,true);
		$criteria->compare('phone_number',$this->phone_number,true);
		$criteria->compare('tax_identification_pin',$this->tax_identification_pin,true);
		$criteria->compare('vat_number',$this->vat_number,true);
		$criteria->compare('contact_person_name',$this->contact_person_name,true);
		$criteria->compare('contact_person_mobile_number',$this->contact_person_mobile_number,true);
		$criteria->compare('contact_person_email',$this->contact_person_email,true);
		$criteria->compare('clientid',$this->clientid,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('code_numbering',$this->code_numbering);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CorporateClient the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
        /**
         * This is the function that generates the client id
         */
        public function generateThisClientID(){
             //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
                $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                $day = $today['mday'];
                $month = $today['mon'];
                $contractor_id = "$day$month$random_number";
                return $contractor_id;
        }
        
        
         /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
}
