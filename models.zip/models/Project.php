<?php

/**
 * This is the model class for table "project".
 *
 * The followings are the available columns in table 'project':
 * @property string $id
 * @property string $name
 * @property string $description
 * @property string $service_outlet_id
 * @property string $commencement_date
 * @property string $objective
 * @property string $date_created
 * @property integer $project_gl_id
 * @property integer $create_user_id
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property AssetForProject[] $assetForProjects
 * @property ServiceOutlet $serviceOutlet
 * @property ProjectExecution[] $projectExecutions
 * @property ProjectLogisticsAndTransportation[] $projectLogisticsAndTransportations
 * @property ProjectTerminationAndSuspension[] $projectTerminationAndSuspensions
 */
class Project extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'project';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, service_outlet_id', 'required'),
			array('project_gl_id, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('name, objective', 'length', 'max'=>250),
			array('service_outlet_id', 'length', 'max'=>10),
			array('description, commencement_date, date_created', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, description, service_outlet_id, commencement_date, objective, date_created, project_gl_id, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'assetForProjects' => array(self::HAS_MANY, 'AssetForProject', 'project_id'),
			'serviceOutlet' => array(self::BELONGS_TO, 'ServiceOutlet', 'service_outlet_id'),
			'projectExecutions' => array(self::HAS_MANY, 'ProjectExecution', 'project_id'),
			'projectLogisticsAndTransportations' => array(self::HAS_MANY, 'ProjectLogisticsAndTransportation', 'project_id'),
			'projectTerminationAndSuspensions' => array(self::HAS_MANY, 'ProjectTerminationAndSuspension', 'project_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'service_outlet_id' => 'Service Outlet',
			'commencement_date' => 'Commencement Date',
			'objective' => 'Objective',
			'date_created' => 'Date Created',
			'project_gl_id' => 'Project Gl',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('service_outlet_id',$this->service_outlet_id,true);
		$criteria->compare('commencement_date',$this->commencement_date,true);
		$criteria->compare('objective',$this->objective,true);
		$criteria->compare('date_created',$this->date_created,true);
		$criteria->compare('project_gl_id',$this->project_gl_id);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Project the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that gets a projects number
         */
        public function getThisProjectNumber($id){
            
            $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $project= Project::model()->find($criteria);
                
                return $project['project_number'];
        }
}
