<?php

/**
 * This is the model class for table "fm_shoppingmail_asset_series".
 *
 * The followings are the available columns in table 'fm_shoppingmail_asset_series':
 * @property string $id
 * @property string $production_asset_id
 * @property string $sol_id
 * @property string $series_unique_number
 * @property integer $number_of_sections
 * @property string $asset_series_name
 * @property string $short_description
 * @property string $description
 * @property string $accounting_preference
 * @property string $method_of_acquisition
 * @property string $other_acquisition_method
 * @property string $acquired_from
 * @property integer $series_gl_id
 * @property integer $number_to_split_batch
 * @property string $batch_split_parameter
 * @property string $other_batch_split_parameter
 * @property double $total_contract_cost
 * @property double $average_contract_cost_per_floor
 * @property integer $primary_source_document_number_id
 * @property integer $is_acquisition_approved
 * @property string $date_acquired
 * @property string $acquisition_approved_date
 * @property string $update_time
 * @property integer $update_user_id
 * @property string $create_time
 * @property integer $acquisition_approved_id
 * @property integer $acquisition_enterred_by_id
 * @property integer $transaction_type_id
 * @property string $location
 * @property integer $is_deleted
 * @property integer $batch_series_remaining_slot
 * @property integer $is_closed
 * @property integer $batch_series_incrementer
 *
 * The followings are the available model relations:
 * @property ServiceOutlet $sol
 * @property ProductionAssets $productionAsset
 * @property FmShoppingmailAssetSeriesSlot[] $fmShoppingmailAssetSeriesSlots
 */
class FmShoppingmailAssetSeries extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'fm_shoppingmail_asset_series';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('production_asset_id, sol_id, accounting_preference, method_of_acquisition', 'required'),
			array('number_of_sections, series_gl_id, number_to_split_batch, primary_source_document_number_id, is_acquisition_approved, update_user_id, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id, is_deleted, batch_series_remaining_slot, is_closed, batch_series_incrementer', 'numerical', 'integerOnly'=>true),
			array('total_contract_cost, average_contract_cost_per_section', 'numerical'),
			array('production_asset_id, sol_id, method_of_acquisition', 'length', 'max'=>10),
			array('series_unique_number, asset_series_name, short_description, other_acquisition_method, acquired_from, other_batch_split_parameter, location', 'length', 'max'=>250),
			array('accounting_preference', 'length', 'max'=>11),
			array('batch_split_parameter', 'length', 'max'=>9),
			array('description, date_acquired, acquisition_approved_date, update_time, create_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, production_asset_id, sol_id, series_unique_number, number_of_sections, asset_series_name, short_description, description, accounting_preference, method_of_acquisition, other_acquisition_method, acquired_from, series_gl_id, number_to_split_batch, batch_split_parameter, other_batch_split_parameter, total_contract_cost, average_contract_cost_per_section, primary_source_document_number_id, is_acquisition_approved, date_acquired, acquisition_approved_date, update_time, update_user_id, create_time, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id, location, is_deleted, batch_series_remaining_slot, is_closed, batch_series_incrementer', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'sol' => array(self::BELONGS_TO, 'ServiceOutlet', 'sol_id'),
			'productionAsset' => array(self::BELONGS_TO, 'ProductionAssets', 'production_asset_id'),
			'fmShoppingmailAssetSeriesSlots' => array(self::HAS_MANY, 'FmShoppingmailAssetSeriesSlot', 'asset_series_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'production_asset_id' => 'Production Asset',
			'sol_id' => 'Sol',
			'series_unique_number' => 'Series Unique Number',
			'number_of_sections' => 'Number Of Sections',
			'asset_series_name' => 'Asset Series Name',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'accounting_preference' => 'Accounting Preference',
			'method_of_acquisition' => 'Method Of Acquisition',
			'other_acquisition_method' => 'Other Acquisition Method',
			'acquired_from' => 'Acquired From',
			'series_gl_id' => 'Series Gl',
			'number_to_split_batch' => 'Number To Split Batch',
			'batch_split_parameter' => 'Batch Split Parameter',
			'other_batch_split_parameter' => 'Other Batch Split Parameter',
			'total_contract_cost' => 'Total Contract Cost',
			'average_contract_cost_per_floor' => 'Average Contract Cost Per Floor',
			'primary_source_document_number_id' => 'Primary Source Document Number',
			'is_acquisition_approved' => 'Is Acquisition Approved',
			'date_acquired' => 'Date Acquired',
			'acquisition_approved_date' => 'Acquisition Approved Date',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
			'create_time' => 'Create Time',
			'acquisition_approved_id' => 'Acquisition Approved',
			'acquisition_enterred_by_id' => 'Acquisition Enterred By',
			'transaction_type_id' => 'Transaction Type',
			'location' => 'Location',
			'is_deleted' => 'Is Deleted',
			'batch_series_remaining_slot' => 'Batch Series Remaining Slot',
			'is_closed' => 'Is Closed',
			'batch_series_incrementer' => 'Batch Series Incrementer',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('production_asset_id',$this->production_asset_id,true);
		$criteria->compare('sol_id',$this->sol_id,true);
		$criteria->compare('series_unique_number',$this->series_unique_number,true);
		$criteria->compare('number_of_sections',$this->number_of_sections);
		$criteria->compare('asset_series_name',$this->asset_series_name,true);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('accounting_preference',$this->accounting_preference,true);
		$criteria->compare('method_of_acquisition',$this->method_of_acquisition,true);
		$criteria->compare('other_acquisition_method',$this->other_acquisition_method,true);
		$criteria->compare('acquired_from',$this->acquired_from,true);
		$criteria->compare('series_gl_id',$this->series_gl_id);
		$criteria->compare('number_to_split_batch',$this->number_to_split_batch);
		$criteria->compare('batch_split_parameter',$this->batch_split_parameter,true);
		$criteria->compare('other_batch_split_parameter',$this->other_batch_split_parameter,true);
		$criteria->compare('total_contract_cost',$this->total_contract_cost);
		$criteria->compare('average_contract_cost_per_floor',$this->average_contract_cost_per_floor);
		$criteria->compare('primary_source_document_number_id',$this->primary_source_document_number_id);
		$criteria->compare('is_acquisition_approved',$this->is_acquisition_approved);
		$criteria->compare('date_acquired',$this->date_acquired,true);
		$criteria->compare('acquisition_approved_date',$this->acquisition_approved_date,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('acquisition_approved_id',$this->acquisition_approved_id);
		$criteria->compare('acquisition_enterred_by_id',$this->acquisition_enterred_by_id);
		$criteria->compare('transaction_type_id',$this->transaction_type_id);
		$criteria->compare('location',$this->location,true);
		$criteria->compare('is_deleted',$this->is_deleted);
		$criteria->compare('batch_series_remaining_slot',$this->batch_series_remaining_slot);
		$criteria->compare('is_closed',$this->is_closed);
		$criteria->compare('batch_series_incrementer',$this->batch_series_incrementer);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FmShoppingmailAssetSeries the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that generate an asset batch series number
         */
        public function generateTheAssetBatchSeriesUniqueNumber(){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = "SM" . $next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = "SM" . $nextplus;
            }
            
            return $code;
        }
        
        
        /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= FmShoppingmailAssetSeries::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['batch_series_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
        
        
         /**
         * This is the function that reduces the remaining number of batch series
         */
        public function reduceTheRemainNumberOfBatchSeries($id){
            
           $criteria = new CDbCriteria();
            $criteria->select = '*';
           $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $asset= FmShoppingmailAssetSeries::model()->find($criteria);
            
            $new_batch_series_remaining_slot = (int)$asset['batch_series_remaining_slot'] - 1;
            
            
          $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('fm_shoppingmail_asset_series',
                                  array(
                                    'batch_series_remaining_slot'=>$new_batch_series_remaining_slot
                                   
                               
		
                            ),
                     ("id=$id"));
            
            return $new_batch_series_remaining_slot;
           
           
        }
        
        
        
         /**
         * This is the function that retrieves the remaining number of batch series
         */
        public function retrieveTheRemainingBatchSlot($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $asset= FmShoppingmailAssetSeries::model()->find($criteria);
            
            return $asset['batch_series_remaining_slot'];
        }
}
