<?php

/**
 * This is the model class for table "agrant_inventory_livestock_asset_slot".
 *
 * The followings are the available columns in table 'agrant_inventory_livestock_asset_slot':
 * @property string $id
 * @property string $inventory_livestock_batch_id
 * @property integer $inventory_livestock_unique_number
 * @property integer $number_of_inventory_livestock
 * @property string $short_description
 * @property string $description
 * @property string $slot_name
 * @property string $inventory_livestock
 * @property integer $slot_gl_id
 * @property double $total_slots_cost
 * @property double $delivery_cost
 * @property double $loading_cost
 * @property double $average_weight_in_kg
 * @property string $inventory_livestock_type
 * @property string $inventory_livestock_breed
 * @property string $inventory_livestock_colour
 * @property string $inventory_livestock_gender
 * @property string $inventory_livestock_variant
 * @property integer $average_inventory_livestock_age_in_days
 *
 * The followings are the available model relations:
 * @property AgrantInventoryBatchedLivestockAsset $inventoryLivestockBatch
 */
class AgrantInventoryLivestockAssetSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'agrant_inventory_livestock_asset_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('inventory_livestock_batch_id, inventory_livestock_unique_number', 'required'),
			array('number_of_inventory_livestock, slot_gl_id, average_inventory_livestock_age_in_days', 'numerical', 'integerOnly'=>true),
			array('total_slots_cost, delivery_cost, loading_cost, average_weight_in_kg', 'numerical'),
			array('inventory_livestock_batch_id', 'length', 'max'=>10),
			array('inventory_livestock_unique_number,short_description, slot_name, inventory_livestock, inventory_livestock_type, inventory_livestock_breed, inventory_livestock_colour, inventory_livestock_gender, inventory_livestock_variant', 'length', 'max'=>250),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, inventory_livestock_batch_id, inventory_livestock_unique_number, number_of_inventory_livestock, short_description, description, slot_name, inventory_livestock, slot_gl_id, total_slots_cost, delivery_cost, loading_cost, average_weight_in_kg, inventory_livestock_type, inventory_livestock_breed, inventory_livestock_colour, inventory_livestock_gender, inventory_livestock_variant, average_inventory_livestock_age_in_days', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'inventoryLivestockBatch' => array(self::BELONGS_TO, 'AgrantInventoryBatchedLivestockAsset', 'inventory_livestock_batch_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'inventory_livestock_batch_id' => 'Inventory Livestock Batch',
			'inventory_livestock_unique_number' => 'Inventory Livestock Unique Number',
			'number_of_inventory_livestock' => 'Number Of Inventory Livestock',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'slot_name' => 'Slot Name',
			'inventory_livestock' => 'Inventory Livestock',
			'slot_gl_id' => 'Slot Gl',
			'total_slots_cost' => 'Total Slots Cost',
			'delivery_cost' => 'Delivery Cost',
			'loading_cost' => 'Loading Cost',
			'average_weight_in_kg' => 'Average Weight In Kg',
			'inventory_livestock_type' => 'Inventory Livestock Type',
			'inventory_livestock_breed' => 'Inventory Livestock Breed',
			'inventory_livestock_colour' => 'Inventory Livestock Colour',
			'inventory_livestock_gender' => 'Inventory Livestock Gender',
			'inventory_livestock_variant' => 'Inventory Livestock Variant',
			'average_inventory_livestock_age_in_days' => 'Average Inventory Livestock Age In Days',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('inventory_livestock_batch_id',$this->inventory_livestock_batch_id,true);
		$criteria->compare('inventory_livestock_unique_number',$this->inventory_livestock_unique_number);
		$criteria->compare('number_of_inventory_livestock',$this->number_of_inventory_livestock);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('slot_name',$this->slot_name,true);
		$criteria->compare('inventory_livestock',$this->inventory_livestock,true);
		$criteria->compare('slot_gl_id',$this->slot_gl_id);
		$criteria->compare('total_slots_cost',$this->total_slots_cost);
		$criteria->compare('delivery_cost',$this->delivery_cost);
		$criteria->compare('loading_cost',$this->loading_cost);
		$criteria->compare('average_weight_in_kg',$this->average_weight_in_kg);
		$criteria->compare('inventory_livestock_type',$this->inventory_livestock_type,true);
		$criteria->compare('inventory_livestock_breed',$this->inventory_livestock_breed,true);
		$criteria->compare('inventory_livestock_colour',$this->inventory_livestock_colour,true);
		$criteria->compare('inventory_livestock_gender',$this->inventory_livestock_gender,true);
		$criteria->compare('inventory_livestock_variant',$this->inventory_livestock_variant,true);
		$criteria->compare('average_inventory_livestock_age_in_days',$this->average_inventory_livestock_age_in_days);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AgrantInventoryLivestockAssetSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
         /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($asset_series_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('agrant_inventory_livestock_asset_slot')
                    ->where("inventory_livestock_batch_id=$asset_series_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= AgrantInventoryLivestockAssetSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
