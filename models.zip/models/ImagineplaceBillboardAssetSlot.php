<?php

/**
 * This is the model class for table "imagineplace_billboard_asset_slot".
 *
 * The followings are the available columns in table 'imagineplace_billboard_asset_slot':
 * @property string $id
 * @property string $billboard_batch_id
 * @property string $billboard_unique_number
 * @property integer $number_of_billboards
 * @property string $billboard_condition
 * @property string $billboard_type
 * @property string $series_slot_name
 * @property string $version
 * @property integer $year_manufactured
 * @property double $average_weight_in_kg
 * @property double $average_storage_capacity_in_megabyte
 * @property string $brand
 * @property string $model
 * @property string $technology_type
 * @property string $operating_system
 * @property string $powered_by
 * @property string $other_power_source
 * @property string $short_description
 * @property string $description
 * @property double $dimension_height
 * @property double $dimension_width
 * @property integer $series_slot_incrementer
 * @property integer $billboard_gl_id
 * @property double $total_cost
 * @property double $delivery_cost
 * @property double $average_cost_per_unit
 *
 * The followings are the available model relations:
 * @property ImagineplaceBatchBillboardAsset $billboardBatch
 */
class ImagineplaceBillboardAssetSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'imagineplace_billboard_asset_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('billboard_batch_id, billboard_condition', 'required'),
			array('number_of_billboards, year_manufactured, series_slot_incrementer, billboard_gl_id', 'numerical', 'integerOnly'=>true),
			array('average_weight_in_kg, average_storage_capacity_in_megabyte, dimension_height, dimension_width, total_cost, delivery_cost, average_cost_per_unit', 'numerical'),
			array('billboard_batch_id', 'length', 'max'=>10),
			array('billboard_unique_number, series_slot_name, version, brand, model, technology_type, operating_system, other_power_source, short_description', 'length', 'max'=>250),
			array('billboard_condition', 'length', 'max'=>4),
			array('billboard_type', 'length', 'max'=>12),
			array('powered_by', 'length', 'max'=>15),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, billboard_batch_id, billboard_unique_number, number_of_billboards, billboard_condition, billboard_type, series_slot_name, version, year_manufactured, average_weight_in_kg, average_storage_capacity_in_megabyte, brand, model, technology_type, operating_system, powered_by, other_power_source, short_description, description, dimension_height, dimension_width, series_slot_incrementer, billboard_gl_id, total_cost, delivery_cost, average_cost_per_unit', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'billboardBatch' => array(self::BELONGS_TO, 'ImagineplaceBatchBillboardAsset', 'billboard_batch_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'billboard_batch_id' => 'Billboard Batch',
			'billboard_unique_number' => 'Billboard Unique Number',
			'number_of_billboards' => 'Number Of Billboards',
			'billboard_condition' => 'Billboard Condition',
			'billboard_type' => 'Billboard Type',
			'series_slot_name' => 'Series Slot Name',
			'version' => 'Version',
			'year_manufactured' => 'Year Manufactured',
			'average_weight_in_kg' => 'Average Weight In Kg',
			'average_storage_capacity_in_megabyte' => 'Average Storage Capacity In Megabyte',
			'brand' => 'Brand',
			'model' => 'Model',
			'technology_type' => 'Technology Type',
			'operating_system' => 'Operating System',
			'powered_by' => 'Powered By',
			'other_power_source' => 'Other Power Source',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'dimension_height' => 'Dimension Height',
			'dimension_width' => 'Dimension Width',
			'series_slot_incrementer' => 'Series Slot Incrementer',
			'billboard_gl_id' => 'Billboard Gl',
			'total_cost' => 'Total Cost',
			'delivery_cost' => 'Delivery Cost',
			'average_cost_per_unit' => 'Average Cost Per Unit',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('billboard_batch_id',$this->billboard_batch_id,true);
		$criteria->compare('billboard_unique_number',$this->billboard_unique_number,true);
		$criteria->compare('number_of_billboards',$this->number_of_billboards);
		$criteria->compare('billboard_condition',$this->billboard_condition,true);
		$criteria->compare('billboard_type',$this->billboard_type,true);
		$criteria->compare('series_slot_name',$this->series_slot_name,true);
		$criteria->compare('version',$this->version,true);
		$criteria->compare('year_manufactured',$this->year_manufactured);
		$criteria->compare('average_weight_in_kg',$this->average_weight_in_kg);
		$criteria->compare('average_storage_capacity_in_megabyte',$this->average_storage_capacity_in_megabyte);
		$criteria->compare('brand',$this->brand,true);
		$criteria->compare('model',$this->model,true);
		$criteria->compare('technology_type',$this->technology_type,true);
		$criteria->compare('operating_system',$this->operating_system,true);
		$criteria->compare('powered_by',$this->powered_by,true);
		$criteria->compare('other_power_source',$this->other_power_source,true);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('dimension_height',$this->dimension_height);
		$criteria->compare('dimension_width',$this->dimension_width);
		$criteria->compare('series_slot_incrementer',$this->series_slot_incrementer);
		$criteria->compare('billboard_gl_id',$this->billboard_gl_id);
		$criteria->compare('total_cost',$this->total_cost);
		$criteria->compare('delivery_cost',$this->delivery_cost);
		$criteria->compare('average_cost_per_unit',$this->average_cost_per_unit);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ImagineplaceBillboardAssetSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
          /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($asset_series_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('imagineplace_billboard_asset_slot')
                    ->where("billboard_batch_id=$asset_series_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($batched_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $batched_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $batched_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= ImagineplaceBillboardAssetSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
