<?php

/**
 * This is the model class for table "imagineplace_advert_property_asset_slot".
 *
 * The followings are the available columns in table 'imagineplace_advert_property_asset_slot':
 * @property string $id
 * @property string $batch_property_asset_id
 * @property string $advert_property_unique_number
 * @property integer $quantity
 * @property string $property_type
 * @property string $short_description
 * @property string $description
 * @property integer $dimension_height
 * @property integer $dimension_width
 *
 * The followings are the available model relations:
 * @property ImagineplaceAdvertBatchPropertyAsset $batchPropertyAsset
 */
class ImagineplaceAdvertPropertyAssetSlot extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'imagineplace_advert_property_asset_slot';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('batch_property_asset_id, property_type', 'required'),
			array('quantity', 'numerical', 'integerOnly'=>true),
                        array('dimension_height,dimension_width', 'numerical'),
			array('batch_property_asset_id', 'length', 'max'=>10),
			array('advert_property_unique_number, short_description', 'length', 'max'=>250),
			array('property_type', 'length', 'max'=>8),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, batch_property_asset_id, advert_property_unique_number, quantity, property_type, short_description, description, dimension_height, dimension_width', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'batchPropertyAsset' => array(self::BELONGS_TO, 'ImagineplaceAdvertBatchPropertyAsset', 'batch_property_asset_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'batch_property_asset_id' => 'Batch Property Asset',
			'advert_property_unique_number' => 'Advert Property Unique Number',
			'quantity' => 'Quantity',
			'property_type' => 'Property Type',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'dimension_height' => 'Dimension Height',
			'dimension_width' => 'Dimension Width',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('batch_property_asset_id',$this->batch_property_asset_id,true);
		$criteria->compare('advert_property_unique_number',$this->advert_property_unique_number,true);
		$criteria->compare('quantity',$this->quantity);
		$criteria->compare('property_type',$this->property_type,true);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('dimension_height',$this->dimension_height);
		$criteria->compare('dimension_width',$this->dimension_width);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ImagineplaceAdvertPropertyAssetSlot the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that confirms if assets are already added to a batch series
         */
        public function isThisBatchSeriesWithAssets($batch_property_asset_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('imagineplace_advert_property_asset_slot')
                    ->where("batch_property_asset_id=$batch_property_asset_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that generate an asset series slot number
         */
        public function generateThisSlotUniqueNumber($advert_property_unique_number){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = $advert_property_unique_number.$next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = $advert_property_unique_number.$nextplus;
            }
            
            return $code;
        }
        
        
        
         /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= ImagineplaceAdvertPropertyAssetSlot::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['series_slot_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
}
