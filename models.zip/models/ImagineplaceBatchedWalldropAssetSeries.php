<?php

/**
 * This is the model class for table "imagineplace_batched_walldrop_asset_series".
 *
 * The followings are the available columns in table 'imagineplace_batched_walldrop_asset_series':
 * @property string $id
 * @property string $production_asset_id
 * @property string $sol_id
 * @property string $batched_walldrop_unique_number
 * @property integer $total_quantity
 * @property string $short_description
 * @property string $description
 * @property string $property_type
 * @property string $accounting_preference
 * @property string $method_of_acquisition
 * @property string $other_acquisition_method
 * @property string $batch_split_parameter
 * @property string $other_batch_split_parameter
 * @property integer $number_to_split_batch
 * @property string $acquired_from
 * @property integer $walldrop_gl_id
 * @property double $total_cost
 * @property double $average_cost_per_unit
 * @property integer $primary_source_document_number_id
 * @property integer $is_acquisition_approved
 * @property string $date_acquired
 * @property string $acquisition_approved_date
 * @property string $update_time
 * @property integer $acquisition_approved_id
 * @property integer $acquisition_enterred_by_id
 * @property integer $transaction_type_id
 * @property string $property_location
 * @property integer $property_acquisition_duration_in_days
 *
 * The followings are the available model relations:
 * @property ProductionAssets $productionAsset
 * @property ServiceOutlet $sol
 * @property ImagineplaceWalldropAssetSlot[] $imagineplaceWalldropAssetSlots
 */
class ImagineplaceBatchedWalldropAssetSeries extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'imagineplace_batched_walldrop_asset_series';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('production_asset_id, sol_id, accounting_preference, method_of_acquisition, property_location', 'required'),
			array('total_quantity, number_to_split_batch, walldrop_gl_id, primary_source_document_number_id, is_acquisition_approved, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id, property_acquisition_duration_in_days', 'numerical', 'integerOnly'=>true),
			array('total_cost, average_cost_per_unit', 'numerical'),
			array('production_asset_id, sol_id', 'length', 'max'=>10),
			array('batched_walldrop_unique_number, short_description, other_acquisition_method, other_batch_split_parameter, acquired_from, property_location', 'length', 'max'=>250),
			array('property_type', 'length', 'max'=>8),
			array('accounting_preference', 'length', 'max'=>11),
			array('method_of_acquisition', 'length', 'max'=>9),
			array('batch_split_parameter', 'length', 'max'=>6),
			array('description, date_acquired, acquisition_approved_date, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, production_asset_id, sol_id, batched_walldrop_unique_number, total_quantity, short_description, description, property_type, accounting_preference, method_of_acquisition, other_acquisition_method, batch_split_parameter, other_batch_split_parameter, number_to_split_batch, acquired_from, walldrop_gl_id, total_cost, average_cost_per_unit, primary_source_document_number_id, is_acquisition_approved, date_acquired, acquisition_approved_date, update_time, acquisition_approved_id, acquisition_enterred_by_id, transaction_type_id, property_location, property_acquisition_duration_in_days', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'productionAsset' => array(self::BELONGS_TO, 'ProductionAssets', 'production_asset_id'),
			'sol' => array(self::BELONGS_TO, 'ServiceOutlet', 'sol_id'),
			'imagineplaceWalldropAssetSlots' => array(self::HAS_MANY, 'ImagineplaceWalldropAssetSlot', 'batch_walldrop_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'production_asset_id' => 'Production Asset',
			'sol_id' => 'Sol',
			'batched_walldrop_unique_number' => 'Batched Walldrop Unique Number',
			'total_quantity' => 'Total Quantity',
			'short_description' => 'Short Description',
			'description' => 'Description',
			'property_type' => 'Property Type',
			'accounting_preference' => 'Accounting Preference',
			'method_of_acquisition' => 'Method Of Acquisition',
			'other_acquisition_method' => 'Other Acquisition Method',
			'batch_split_parameter' => 'Batch Split Parameter',
			'other_batch_split_parameter' => 'Other Batch Split Parameter',
			'number_to_split_batch' => 'Number To Split Batch',
			'acquired_from' => 'Acquired From',
			'walldrop_gl_id' => 'Walldrop Gl',
			'total_cost' => 'Total Cost',
			'average_cost_per_unit' => 'Average Cost Per Unit',
			'primary_source_document_number_id' => 'Primary Source Document Number',
			'is_acquisition_approved' => 'Is Acquisition Approved',
			'date_acquired' => 'Date Acquired',
			'acquisition_approved_date' => 'Acquisition Approved Date',
			'update_time' => 'Update Time',
			'acquisition_approved_id' => 'Acquisition Approved',
			'acquisition_enterred_by_id' => 'Acquisition Enterred By',
			'transaction_type_id' => 'Transaction Type',
			'property_location' => 'Property Location',
			'property_acquisition_duration_in_days' => 'Property Acquisition Duration In Days',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('production_asset_id',$this->production_asset_id,true);
		$criteria->compare('sol_id',$this->sol_id,true);
		$criteria->compare('batched_walldrop_unique_number',$this->batched_walldrop_unique_number,true);
		$criteria->compare('total_quantity',$this->total_quantity);
		$criteria->compare('short_description',$this->short_description,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('property_type',$this->property_type,true);
		$criteria->compare('accounting_preference',$this->accounting_preference,true);
		$criteria->compare('method_of_acquisition',$this->method_of_acquisition,true);
		$criteria->compare('other_acquisition_method',$this->other_acquisition_method,true);
		$criteria->compare('batch_split_parameter',$this->batch_split_parameter,true);
		$criteria->compare('other_batch_split_parameter',$this->other_batch_split_parameter,true);
		$criteria->compare('number_to_split_batch',$this->number_to_split_batch);
		$criteria->compare('acquired_from',$this->acquired_from,true);
		$criteria->compare('walldrop_gl_id',$this->walldrop_gl_id);
		$criteria->compare('total_cost',$this->total_cost);
		$criteria->compare('average_cost_per_unit',$this->average_cost_per_unit);
		$criteria->compare('primary_source_document_number_id',$this->primary_source_document_number_id);
		$criteria->compare('is_acquisition_approved',$this->is_acquisition_approved);
		$criteria->compare('date_acquired',$this->date_acquired,true);
		$criteria->compare('acquisition_approved_date',$this->acquisition_approved_date,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('acquisition_approved_id',$this->acquisition_approved_id);
		$criteria->compare('acquisition_enterred_by_id',$this->acquisition_enterred_by_id);
		$criteria->compare('transaction_type_id',$this->transaction_type_id);
		$criteria->compare('property_location',$this->property_location,true);
		$criteria->compare('property_acquisition_duration_in_days',$this->property_acquisition_duration_in_days);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ImagineplaceBatchedWalldropAssetSeries the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
        /**
         * This is the function that generate an asset batch series number
         */
        public function generateTheWallDripAssetBatchSeriesUniqueNumber(){
            $current = $this->getTheCurrentIncrementedNumber();
            $next = (int)$current + 1;
            if(strlen("$next")>4){
                $code = "WD" . $next;
            }else{
                $nextplus = str_pad($next, 4,"0",STR_PAD_LEFT);
                $code = "WD" . $nextplus;
            }
            
            return $code;
        }
        
        
        /**
         * This is the function that retrieves the current increment value
         */
        public function getTheCurrentIncrementedNumber(){
           
            $data = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $assets= ImagineplaceBatchedWalldropAssetSeries::model()->findAll($criteria);
            
            foreach($assets as $asset){
                $data[] = $asset['batch_series_incrementer'];
            }
            if(empty($data) == false){
                return max($data);
            }else{
                return 0;
            }
            
        }
        
        
         /**
         * This is the function that reduces the remaining number of batch series
         */
        public function reduceTheRemainNumberOfBatchSeries($id){
            
             $criteria = new CDbCriteria();
            $criteria->select = '*';
           $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $asset= ImagineplaceBatchedWalldropAssetSeries::model()->find($criteria);
            
            $new_batch_series_remaining_slot = (int)$asset['batch_series_remaining_slot'] - 1;
            
            
          $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('imagineplace_batched_walldrop_asset_series',
                                  array(
                                    'batch_series_remaining_slot'=>$new_batch_series_remaining_slot
                                   
                               
		
                            ),
                     ("id=$id"));
            
            return $new_batch_series_remaining_slot;
           
           
        }
        
        
        
         /**
         * This is the function that retrieves the remaining number of batch series
         */
        public function retrieveTheRemainingBatchSlot($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $asset= ImagineplaceBatchedWalldropAssetSeries::model()->find($criteria);
            
            return $asset['batch_series_remaining_slot'];
        }
        
}
