<?php

/**
 * This is the model class for table "asset_on_requisition".
 *
 * The followings are the available columns in table 'asset_on_requisition':
 * @property string $id
 * @property string $description
 * @property string $asset_in_warehouse_and_place_id
 * @property string $requisition_status
 * @property string $requisition_type
 * @property string $requisition_purpose
 * @property double $quantity
 * @property string $measurement_unit
 * @property string $date_requested
 * @property string $date_approved
 * @property integer $initiated_by_id
 * @property integer $approved_by_id
 * @property integer $is_approved
 * @property integer $is_deleted
 * @property integer $is_rejected
 * @property integer $is_modification_approved
 *
 * The followings are the available model relations:
 * @property AssetInWarehouseAndPlace $assetInWarehouseAndPlace
 */
class AssetOnRequisition extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'asset_on_requisition';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('asset_in_warehouse_and_place_id, requisition_status', 'required'),
			array('initiated_by_id, approved_by_id, is_approved, is_deleted, is_rejected, is_modification_approved', 'numerical', 'integerOnly'=>true),
			array('quantity', 'numerical'),
			array('asset_in_warehouse_and_place_id', 'length', 'max'=>10),
			array('requisition_status', 'length', 'max'=>8),
			array('requisition_type, requisition_purpose, measurement_unit', 'length', 'max'=>250),
			array('description, date_requested, date_approved', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, description, asset_in_warehouse_and_place_id, requisition_status, requisition_type, requisition_purpose, quantity, measurement_unit, date_requested, date_approved, initiated_by_id, approved_by_id, is_approved, is_deleted, is_rejected, is_modification_approved', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'assetInWarehouseAndPlace' => array(self::BELONGS_TO, 'AssetInWarehouseAndPlace', 'asset_in_warehouse_and_place_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'description' => 'Description',
			'asset_in_warehouse_and_place_id' => 'Asset In Warehouse And Place',
			'requisition_status' => 'Requisition Status',
			'requisition_type' => 'Requisition Type',
			'requisition_purpose' => 'Requisition Purpose',
			'quantity' => 'Quantity',
			'measurement_unit' => 'Measurement Unit',
			'date_requested' => 'Date Requested',
			'date_approved' => 'Date Approved',
			'initiated_by_id' => 'Initiated By',
			'approved_by_id' => 'Approved By',
			'is_approved' => 'Is Approved',
			'is_deleted' => 'Is Deleted',
			'is_rejected' => 'Is Rejected',
			'is_modification_approved' => 'Is Modification Approved',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('asset_in_warehouse_and_place_id',$this->asset_in_warehouse_and_place_id,true);
		$criteria->compare('requisition_status',$this->requisition_status,true);
		$criteria->compare('requisition_type',$this->requisition_type,true);
		$criteria->compare('requisition_purpose',$this->requisition_purpose,true);
		$criteria->compare('quantity',$this->quantity);
		$criteria->compare('measurement_unit',$this->measurement_unit,true);
		$criteria->compare('date_requested',$this->date_requested,true);
		$criteria->compare('date_approved',$this->date_approved,true);
		$criteria->compare('initiated_by_id',$this->initiated_by_id);
		$criteria->compare('approved_by_id',$this->approved_by_id);
		$criteria->compare('is_approved',$this->is_approved);
		$criteria->compare('is_deleted',$this->is_deleted);
		$criteria->compare('is_rejected',$this->is_rejected);
		$criteria->compare('is_modification_approved',$this->is_modification_approved);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AssetOnRequisition the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
