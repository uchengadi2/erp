# ext-theme-neptune-d774458c-d367-40c4-b12b-7e4a11bfbd81/resources

This folder contains static resources (typically an `"images"` folder as well).
