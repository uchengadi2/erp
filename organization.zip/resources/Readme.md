# ext-theme-neptune-e82e8a6f-a912-4922-8905-490b4701e512/resources

This folder contains static resources (typically an `"images"` folder as well).
