# ext-theme-neptune-445258c1-003d-46c4-be97-cdd8b97b3ba6/resources

This folder contains static resources (typically an `"images"` folder as well).
