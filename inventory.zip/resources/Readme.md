# ext-theme-neptune-b3af73ac-1a3f-4788-813f-18c0ef79a261/resources

This folder contains static resources (typically an `"images"` folder as well).
