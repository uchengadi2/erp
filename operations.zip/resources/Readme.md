# ext-theme-neptune-f9260720-87ec-47d4-b6e1-de56b66b7d99/resources

This folder contains static resources (typically an `"images"` folder as well).
