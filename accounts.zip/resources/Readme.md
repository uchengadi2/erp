# ext-theme-neptune-92dfa904-270e-417a-ba00-8354c43d8a3c/resources

This folder contains static resources (typically an `"images"` folder as well).
